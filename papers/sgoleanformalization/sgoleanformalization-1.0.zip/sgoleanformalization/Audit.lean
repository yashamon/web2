/- Audit.lean — the verification certificate.

   Run:
     lake env lean Audit.lean

   Expected output, exactly:
     'lem_onestage_final' depends on axioms: [propext, Classical.choice, Quot.sound]
     'SgoThm.thm52' depends on axioms: [propext, Classical.choice, Quot.sound]
     'SgoThm.spectrum_full' depends on axioms: [propext, Classical.choice, Quot.sound]
     'SgoKWit.not_faithful_kp1' depends on axioms: [propext, Classical.choice, Quot.sound]

   Those three are the standard axioms of classical reasoning in Lean's
   core library. What must NOT appear:
     - sorryAx            — would mean an incomplete proof;
     - Lean.ofReduceBool  — would mean a native_decide dependence
                            (trusting the compiler, a larger base).
   Neither occurs in the theorem's cone. The separate 3×3
   exhaustive artifact (Exhaust.lean) does use native_decide, and its
   audit line shows Lean.ofReduceBool — that artifact is independent
   of the general theorem.

   `lem_onestage_final` (Step8) is the one-stage resolution lemma;
   `SgoThm.thm52` is theorem 5.2 in full (side ≥ 5): Go's symmetry and
   the SGo / DSGo / k-DSGo simultaneizations realizing faithfulness
   radii 0, ∞, and exactly k; `spectrum_full` is the ℕ ⊔ {∞} spectrum
   corollary; `not_faithful_kp1` is the k-DSGo not-within-(k+1) witness. -/
import Step8
import SgoThm

#print axioms lem_onestage_final
#print axioms SgoThm.thm52
#print axioms SgoThm.spectrum_full
#print axioms SgoKWit.not_faithful_kp1
