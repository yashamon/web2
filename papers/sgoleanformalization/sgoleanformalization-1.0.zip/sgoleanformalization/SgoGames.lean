/- SgoGames.lean — theorem 5.2, the abstract game layer, on his
   option-C ruling: a sequential game with a pass HAS, BY DEFINITION,
   a pass bit in its states.

   A sequential game is presented by its core: core states, the
   real-move action, the initial core, and the ended-by-play positions
   (king capture for chess; empty for Go). Its live states are, by
   definition, Z2 × Z2 BIGRADED — S(G) = ⊔ S_{i,j}(G), the first
   grading the turn, the second the pass grading — plus finals
   (PState: live c i j / done c i). The pass maps S_{i,0} to
   S_{i+1,1} and ends the game from S_{i,1}; a real move of the
   turn's color lands in S_{i+1,0} (or a final, at an ended-by-play
   core). The printed def_sequential's properties (1)-(6) hold by
   construction. The position normal form N — a live state to the
   S_{0,0} state of its core, finals to themselves — is definable
   outright, and replaces the printed grading normalization in P,
   def_semiclassical (commuting = both composites defined with a
   common normal form), and the branch identification. ("Fresh" is
   NOT used here: it is already coined for the turn's new stones.)

   Design notes for the statement audit:
   - Moves are shared by both game structures (prop_2 by construction).
   - Branch sets are predicates (BSet); finiteness not carried.
   - bar is computed structurally (no choice); # as printed.
   - Radius claims in explicit form; scoring partition and alphabet
     finiteness not carried (unused by 5.2's clauses).
   - The simultaneous side (SimulGame/SimOK/SimSym) is unchanged from
     before the ruling. -/
import SgoDelta

namespace SgoGames

attribute [local instance] Classical.propDecidable

/-- A Z2 graded move alphabet with the pseudo pass move (multi graded). -/
structure Moves where
  M : Type
  deg0 : M → Prop
  deg1 : M → Prop
  pass : M
  pass_deg0 : deg0 pass
  pass_deg1 : deg1 pass
  pass_unique : ∀ m, deg0 m → deg1 m → m = pass

/-- Branch sets: subsets of a state type, as predicates. -/
def BSet (α : Type) : Type := α → Prop

def BSet.single {α} (x : α) : BSet α := fun y => y = x
def BSet.pair {α} (x y : α) : BSet α := fun z => z = x ∨ z = y
def BSet.sub {α} (A B : BSet α) : Prop := ∀ x, A x → B x
def BSet.eqv {α} (A B : BSet α) : Prop := ∀ x, A x ↔ B x

variable {Mv : Moves}

/-- The core presentation of a sequential game with a pass. -/
structure SeqGame (Mv : Moves) where
  C : Type
  mv : C → Mv.M → Option C
  q0 : C
  endMove : C → Prop

/-- The states: by definition, a live core with its bigrading — the
    turn grading g and the pass grading j — or a final, carrying its
    core and turn grading. -/
inductive PState (C : Type) where
  | live (c : C) (g : Bool) (j : Bool)
  | done (c : C) (g : Bool)

def PState.coreOf {C} : PState C → C
  | .live c _ _ => c
  | .done c _ => c

def SeqGame.S (G : SeqGame Mv) : Type := PState G.C

def sInit (G : SeqGame Mv) : G.S := PState.live G.q0 false false

def sdeg (G : SeqGame Mv) : G.S → Bool
  | .live _ g _ => g
  | .done _ g => g

def sfinal (G : SeqGame Mv) : G.S → Prop
  | .live _ _ _ => False
  | .done _ _ => True

/-- The evolution. A pass: flip the turn, raise the pass grading;
    from pass grading 1 the game ends. A real move of the turn's
    color: act on the core, flip the turn, land at pass grading 0;
    at an ended-by-play core the game ends. Finals evolve nowhere. -/
noncomputable def sE (G : SeqGame Mv) : G.S → Mv.M → Option G.S
  | .live c g b, m =>
    if m = Mv.pass then
      if b then some (.done c (!g)) else some (.live c (!g) true)
    else if (g = false ∧ Mv.deg0 m) ∨ (g = true ∧ Mv.deg1 m) then
      (G.mv c m).map fun c' =>
        if G.endMove c' then .done c' (!g) else .live c' (!g) false
    else none
  | .done _ _, _ => none

/-- Legally obtainable states. -/
inductive SeqReach (G : SeqGame Mv) : G.S → Prop
  | init : SeqReach G (sInit G)
  | step {s s' m} : SeqReach G s → sE G s m = some s' → SeqReach G s'

/-- The bar of the printed # machinery, computed: the pass
    predecessor when one exists (pass grading 1, or final), else a
    pass forward. -/
def sBar {C : Type} : PState C → PState C
  | .live c g false => .live c (!g) true
  | .live c g true  => .live c (!g) false
  | .done c g       => .live c (!g) true

/-- The # operation: the move at a, else at bar a. -/
noncomputable def hashOp (G : SeqGame Mv) (a : G.S) (m : Mv.M) :
    Option G.S :=
  match sE G a m with
  | some b => some b
  | none => sE G (sBar a) m

/-- The position normal form (option C, definable): a live state to
    the S_{0,0} state of its core; finals to themselves. -/
def sN {C : Type} : PState C → PState C
  | .live c _ _ => .live c false false
  | .done c g => .done c g

noncomputable def hash2 (G : SeqGame Mv) (a : G.S) (m0 m1 : Mv.M) :
    Option G.S :=
  (hashOp G a m0).bind fun b => hashOp G b m1

/-- The serialization map P: the four priority cases, each term
    replaced by its position normal form. -/
noncomputable def Pmap (G : SeqGame Mv) (a : G.S) (m0 m1 : Mv.M) :
    Option (BSet G.S) :=
  match hash2 G a m0 m1, hash2 G a m1 m0 with
  | some x, some y => some (BSet.pair (sN x) (sN y))
  | some x, none =>
    match hashOp G a m1 with
    | some y => some (BSet.pair (sN x) (sN y))
    | none => none
  | none, some y =>
    match hashOp G a m0 with
    | some x => some (BSet.pair (sN x) (sN y))
    | none => none
  | none, none =>
    match hashOp G a m0, hashOp G a m1 with
    | some x, some y => some (BSet.pair (sN x) (sN y))
    | _, _ => none

/-- Sim(G): single-move definedness at a branch set. -/
def simDef1 (G : SeqGame Mv) (A : BSet G.S) (m : Mv.M) : Prop :=
  ∀ a, A a → ¬sfinal G a ∧ (hashOp G a m).isSome

/-- Sim(G): pair definedness — every branch's P defined. -/
def simDefP (G : SeqGame Mv) (A : BSet G.S) (m0 m1 : Mv.M) : Prop :=
  ∀ a, A a → ¬sfinal G a ∧ (Pmap G a m0 m1).isSome

/-- Sim(G): the pair value — the union of the branch P's. -/
noncomputable def simVal (G : SeqGame Mv) (A : BSet G.S)
    (m0 m1 : Mv.M) : BSet G.S :=
  fun z => ∃ a, A a ∧ ∃ P, Pmap G a m0 m1 = some P ∧ P z

/-- Sim(G) finality: some branch final. -/
def simFinal (G : SeqGame Mv) (A : BSet G.S) : Prop :=
  ∃ a, A a ∧ sfinal G a

/-- def_simultaneous: the data of a combinatorial simultaneous game,
    as before the ruling. -/
structure SimulGame (Mv : Moves) where
  B : Type
  avail : B → Mv.M → Prop
  pairE : B → Mv.M → Mv.M → Option B
  q0 : B
  final : B → Prop

inductive SimReach (G : SimulGame Mv) : G.B → Prop
  | init : SimReach G G.q0
  | step {s s' m0 m1} : SimReach G s → G.pairE s m0 m1 = some s' →
      SimReach G s'

structure SimOK (G : SimulGame Mv) : Prop where
  final_nomove : ∀ {s m}, SimReach G s → G.final s → ¬G.avail s m
  pass_available : ∀ {s}, SimReach G s → ¬G.final s → G.avail s Mv.pass
  pair_of_avail : ∀ {s m0 m1}, SimReach G s → Mv.deg0 m0 → Mv.deg1 m1 →
    G.avail s m0 → G.avail s m1 → (G.pairE s m0 m1).isSome
  avail_of_pair : ∀ {s m0 m1}, SimReach G s →
    (G.pairE s m0 m1).isSome → G.avail s m0 ∧ G.avail s m1
  final_exists : ∃ s, G.final s

/-- A relation lifted to Option: none ~ none, some ~ some via rel,
    a defined and an undefined side never related. -/
def OptBRel {Mv : Moves} (G : SimulGame Mv) (rel : G.B → G.B → Prop) :
    Option G.B → Option G.B → Prop
  | none, none => True
  | some a, some b => rel a b
  | _, _ => False

/-- def_symmetric on the branch semantics. The paper's state space of
    a simultaneization is a SET of branches, and its evolution is a
    UNION over that set (lem_symmetric); so states are compared up to
    the branch-equivalence `rel` (entanglement-set equality here). The
    swap operators A/R are exact involutions fixing q0; the evolution
    commutes with them up to `rel`, matching R̃∘⋃ = ⋃. -/
structure SimSym (G : SimulGame Mv) (rel : G.B → G.B → Prop) : Prop where
  exA : ∃ A : Mv.M → Mv.M, ∃ R : G.B → G.B,
    (∀ m, A (A m) = m) ∧ A Mv.pass = Mv.pass ∧
    (∀ m, Mv.deg0 m ↔ Mv.deg1 (A m)) ∧
    (∀ s, R (R s) = s) ∧ R G.q0 = G.q0 ∧
    (∀ s m0 m1, OptBRel G rel (Option.map R (G.pairE (R s) (A m1) (A m0)))
      (G.pairE s m0 m1))

/-- The symmetry of a sequential game, on the core presentation:
    a color swap on moves and cores intertwining the action. -/
structure SeqSym (G : SeqGame Mv) : Prop where
  exA : ∃ A : Mv.M → Mv.M, ∃ R : G.C → G.C,
    (∀ m, A (A m) = m) ∧ A Mv.pass = Mv.pass ∧
    (∀ m, Mv.deg0 m ↔ Mv.deg1 (A m)) ∧
    (∀ c, R (R c) = c) ∧ R G.q0 = G.q0 ∧
    (∀ c, G.endMove (R c) ↔ G.endMove c) ∧
    (∀ c m, Option.map R (G.mv (R c) (A m)) = G.mv c m)

section Symmetrization

variable (G0 : SeqGame Mv) (G1 : SimulGame Mv)

/-- Commuting at a (def_semiclassical, option C): both composites
    defined, with a common position normal form. -/
def CommuteAt (a : G0.S) (m0 m1 : Mv.M) : Prop :=
  ∃ x y, hash2 G0 a m0 m1 = some x ∧ hash2 G0 a m1 m0 = some y ∧
    sN x = sN y

/-- The associated state: the common position normal form. -/
noncomputable def assocOf (a : G0.S) (m0 m1 : Mv.M) : G0.S :=
  sN ((hash2 G0 a m0 m1).getD a)

/-- def_semiclassical: the recursion. -/
inductive SemiC : G1.B → G0.S → Prop
  | init : SemiC G1.q0 (sInit G0)
  | step {s a s' m0 m1} : SemiC s a → CommuteAt G0 a m0 m1 →
      G1.pairE s m0 m1 = some s' → SemiC s' (assocOf G0 a m0 m1)

/-- def_symmetrization, conditions 3 and 4, for the branch semantics. -/
structure IsSimultaneization (ρ : G1.B → BSet G0.S) : Prop where
  rho_init : BSet.eqv (ρ G1.q0) (BSet.single (sInit G0))
  nat_defined : ∀ {s m0 m1}, SimReach G1 s →
    (G1.pairE s m0 m1).isSome → simDefP G0 (ρ s) m0 m1
  nat_incl : ∀ {s s' m0 m1}, SimReach G1 s →
    G1.pairE s m0 m1 = some s' →
    BSet.sub (ρ s') (simVal G0 (ρ s) m0 m1)
  semiclassical : ∀ {s a}, SemiC G0 G1 s a →
    BSet.eqv (ρ s) (BSet.single a)

/-- The interface of a sequential state. -/
def Interface0 (a : G0.S) (m : Mv.M) : Prop := (hashOp G0 a m).isSome

/-- The interface of a simultaneous state. -/
def Interface1 (s : G1.B) (m : Mv.M) : Prop := G1.avail s m

/-- def_faithful at a state (finality clause as printed — intact
    under option C). -/
def FaithfulAt (ρ : G1.B → BSet G0.S) (s : G1.B) : Prop :=
  (∃ a, (ρ s) a) ∧
  (G1.final s → simFinal G0 (ρ s)) ∧
  (¬G1.final s → ∀ m,
    Interface1 G1 s m ↔ ∀ a, (ρ s) a → Interface0 G0 a m)

inductive WithinD (ρ : G1.B → BSet G0.S) : Nat → G1.B → Prop
  | base {s a} : SemiC G0 G1 s a → WithinD ρ 0 s
  | ofLe {d s} : WithinD ρ d s → WithinD ρ (d+1) s
  | step {d s s' m0 m1} : WithinD ρ d s → G1.pairE s m0 m1 = some s' →
      WithinD ρ (d+1) s'

def FaithfulWithin (ρ : G1.B → BSet G0.S) (d : Nat) : Prop :=
  ∀ s, WithinD G0 G1 ρ d s → FaithfulAt G0 G1 ρ s

/-- def_simplesymmetrization. -/
def IsSimple : Prop :=
  ∀ s, SimReach G1 s → ¬G1.final s →
    (∃ m, m ≠ Mv.pass ∧ G1.avail s m) →
    ∃ a, SeqReach G0 a ∧
      ∀ m, Interface0 G0 a m ↔ Interface1 G1 s m

end Symmetrization

end SgoGames
