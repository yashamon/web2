# sgoz: the experiments of Section 2.1

The depth ladder (Table 1) and the play of strong networks (Table 2) of the
paper, on the 9×9 board, for SGo (the printed rules) and for Go.

## Contents

- `code/` — the trainer.
  - `csrc/sgo.cpp` is the paper's rules engine (its scratch state made per
    thread).
  - `csrc/sgoz.cpp` plays many games at once: the search, the input planes,
    the Monte Carlo agents, the game statistics.
  - `sgoz/` holds the network (`model.py`: 10 residual blocks of 128
    channels with global pooling), the training (`train.py`) and the bridge
    to the C++ library (`lib.py`).
  - `run.py` trains, `ladder.py` plays a ladder, `stats.py` the strong play,
    and `fit_paper.py` refits the ladder as printed.
  - `nets/g35.bin` is an older small net. It is a rung of the SGo ladder,
    left out of Table 1. `tests/` holds its reference outputs.
  - `README.txt` holds the setup notes.
- `sgo/` and `go/` — the two work folders.
  - `config.json`: the settings.
  - `models/g48.pt`, `g56.pt`: the networks of generations 48 and 56.
  - `runs/log.txt`, `runs/eval.txt`: the training log and the match after
    each generation.
  - `runs/ladder_o4/`: every game of Table 1, one file per pair (the scores).
    `runs/ladder_o4.txt` is the trainer's own fit, with the random agent as
    the zero.
  - `runs/stats_g48_match.*`: Table 2, per game.
  - `runs/ladder/` holds an earlier ladder without the varied openings. It is
    not used: its games largely repeated each other.

## Conventions

- Time is counted in ticks: one move by both players. In SGo a tick is a
  turn; in Go a move of Black and then one of White.
- SGo: the rules of the paper, cap 200 ticks. Go: area scoring, Komi 7.5,
  positional superko, cap 150 ticks (300 moves).
- A network searches 100 simulations a move. In the first four ticks it
  draws its move from the visit counts; later it plays its most visited
  move. In SGo it draws again when the display, stamps aside, repeats.
- The Monte Carlo agent `mcN` draws a menu of 5 moves and plays N random
  playouts after each, about 5N a move: `mc26`, `mc205`, `mc3277` are the
  128, 1024 and 16384 playouts of the paper; `mc0` is the random agent.
- Ladder: each rung plays the next one 96 games and the one after 32,
  colors alternating. Bradley–Terry by maximum likelihood, a draw half a
  win, `mc26` the zero, errors by 400 bootstrap resamplings of the games.

## The tables from the hosted games (Python 3 and numpy; minutes)

    python3 code/fit_paper.py sgo/runs/ladder_o4 go/runs/ladder_o4
    python3 code/stats.py --table sgo/runs/stats_g48_match.json go/runs/stats_g48_match.json

## Replaying the experiments

Linux or WSL, g++ with OpenMP, Python 3 with PyTorch and numpy, and an
NVIDIA GPU (on a CPU it runs, very slowly). The engine compiles itself on
first use. Times are on one RTX 4070 Ti.

    python code/run.py --work sgo --data ~/sgo_data                # train SGo; Ctrl-C stops, the same command resumes
    python code/run.py --work go --game go --data ~/go_data        # train Go
    python code/ladder.py --work sgo --open 4 --tag _o4            # Table 1, SGo (about 4 hours)
    python code/ladder.py --work go --open 4 --tag _o4             # Table 1, Go
    python code/stats.py --work sgo --net g48 --games 400          # Table 2 (about 10 minutes each)
    python code/stats.py --work go --net g48 --games 400

Training stops when you stop it; the paper uses generations 0 to 56 (about
a quarter of an hour each). The ladder needs the networks of all its rungs,
so it needs a training run first. A ladder keeps the games already in its
folder and plays only the missing pairs; give a new `--tag` for a fresh one. The statistics run with the hosted
generation 48. A new run gives other networks and other numbers, within the
printed errors.
