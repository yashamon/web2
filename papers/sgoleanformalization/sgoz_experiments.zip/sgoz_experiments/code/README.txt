sgoz: SGo self-play training on the GPU (a fresh, bigger net; rule D, 9x9)

What it is
  - The paper's C++ engine (csrc/sgo.cpp, unchanged except that its scratch state is per thread) plays many games at
    once on the CPU threads (csrc/sgoz.cpp).  Every position that needs the net goes to the GPU in one batch.
  - The net (sgoz/model.py): a residual tower, 10 blocks of 128 channels by default, with KataGo's global pooling;
    fully convolutional, so the same code takes any board side.  Two policy heads (Black's and White's move), the
    value (Black's result) and the final ownership of every point (an auxiliary target).
  - Self-play (KataGo's recipe where it applies): 25% of the moves get a full 600-simulation search and are recorded
    for training, the rest a quick 100-simulation search; root noise scaled to the legal moves; first-play-urgency
    reduction; move temperature 0.8 decaying to 0.2.  The leaf value starts as half net, half one random playout
    (this got the old line off the ground) and goes to pure net over 20 generations.
  - Training: a growing window of recent samples, random symmetry and color swap, SGD with momentum.
  - After every generation the new net plays the previous one; every 2nd the old champion g35 (the 500-search line,
    100 simulations each side); every 4th the Monte Carlo agent mc3277.  Results in runs/eval.txt.

One-time setup (in the Ubuntu window of WSL)
    sudo apt update && sudo apt install -y g++ python3-venv
    python3 -m venv ~/sgo_env && source ~/sgo_env/bin/activate
    pip install torch numpy

Check (builds the engine, compares the old net in torch with the C++ outputs, times the GPU)
    source ~/sgo_env/bin/activate
    cd /mnt/c/Users/yasha/OneDrive/Documents/SGo/sgoz
    python run.py --check

Train (Ctrl-C stops; the same command resumes)
    python run.py --data ~/sgoz_data

    models/g<k>.pt   the nets            runs/log.txt   progress           runs/eval.txt   the matches
    config.json      the settings (written on the first run; edit between runs: e.g. slots, games_per_gen, sims)
    --data puts the game records in WSL's own disk, so OneDrive does not sync them.

Later: Go
    The net and the training do not care which game it is.  Go needs a Go game in csrc/sgoz.cpp (the engine already
    has it: goTurn, superko, komi), a sequential search (one mover per node, its head read), a Go feature set, and its
    color swap.  Nothing in sgoz/model.py changes.

Go (added 2026-11-17)
    The same pipeline plays 9x9 Go: area scoring, komi 7.5, positional superko in the games (simple ko inside the
    searches and playouts), cap 300 plies.  The nets choose among the Monte Carlo agents' moves (no suicide, no own-eye
    fill) and the pass.  Same net, same recipe, same evaluation; a separate work folder:
        python run.py --game go --work /mnt/c/Users/yasha/OneDrive/Documents/SGo/sgoz_go --data ~/sgoz_go_data
        python ladder.py --work /mnt/c/Users/yasha/OneDrive/Documents/SGo/sgoz_go
