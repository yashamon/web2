// sgoz: the SGo engine (sgo.cpp, unchanged) as a shared library for a Python/PyTorch trainer.
//
// A Pool runs many games at once.  Each game's tree search stops whenever it needs the net, and the requests of all
// games are handed to Python in one batch per net (sz_pending / sz_feed); Monte Carlo agents and random playouts run
// here.  The search is the decoupled PUCT of sgonet.cpp (simultaneous moves: per-player statistics at each node,
// joint-action children), with the additions of the KataGo paper (Wu 2019): playout cap randomization (full searches
// on a fraction of the moves, only those recorded), first-play urgency reduction, root Dirichlet noise scaled to the
// number of legal moves, a decaying move temperature, and an ownership target recorded with every sample.
//
// Threads: sz_step and sz_feed run the games on OpenMP threads (the engine's scratch state is thread_local in this
// copy of sgo.cpp); one process, one GPU context, large batches.
//
// Feature sets: 0 = the 8 planes of sgonet.cpp (9x9 only; for the old nets g1..g35), 1 = the planes below (any side).
// Values are Black's: +1 Black wins.  Moves: 0..N-1 points, N = pass.  Single process, not thread safe (the engine
// keeps scratch state in thread_local statics): one pool at a time per process.
//
// Build: g++ -O3 -march=native -std=c++17 -fopenmp -shared -fPIC -o libsgoz.so sgoz.cpp
#define main engine_main
#include "sgo.cpp"
#undef main
#include <vector>
#include <unordered_map>
#include <unordered_set>
#include <memory>
#include <cmath>
#include <omp.h>

namespace sz {

static std::unique_ptr<Board> g_board; static Opts g_opts; static int g_N = 81, g_NA = 82, g_side = 9;

// ---------- features ----------
static const int FS1_C = 22;
// 0 black, 1 white, 2 q, 3 empty, 4-6 b/w/q placed last turn, 7-9 two turns ago, 10-12 three turns ago,
// 13/14 b/w chains with no liberty, 15/16 b/w chains with one, 17/18 b/w chains with two, 19 q chains with at most one,
// 20 ones, 21 turn / cap.  The color swap exchanges 0/1, 4/5, 7/8, 10/11, 13/14, 15/16, 17/18.
static int nplanes(int fs) { return fs == 0 ? 8 : fs == 1 ? FS1_C : 15; }
static void libCounts(const Board& bd, const Pos& P, std::vector<int>& lib) {
  lib.assign(bd.N, 0); int seen[4];
  for (int e = 0; e < bd.N; e++) { if (P.D.kind[e] != EMPTY) continue; int ns = 0;
    for (int a = 0; a < bd.nnb[e]; a++) { int q = bd.nbr[e][a]; if (P.D.kind[q] == EMPTY) continue; int r = P.cid[q]; bool dup = false;
      for (int s = 0; s < ns; s++) if (seen[s] == r) dup = true; if (!dup) { seen[ns++] = r; lib[r]++; } } }
}
static void features(const SGoGame& g, int fs, float* x) {
  const Board& bd = *g_board; int N = bd.N, t = g.next; const Display& D = g.P.D;
  std::fill(x, x + nplanes(fs) * N, 0.0f);
  if (fs == 0) {
    for (int p = 0; p < N; p++) { int k = D.kind[p], st = D.stamp[p];
      if (k == B) x[0 * N + p] = 1; if (k == W) x[1 * N + p] = 1; if (k == R) x[2 * N + p] = 1;
      if (k == B && st == t - 1) x[3 * N + p] = 1; if (k == W && st == t - 1) x[4 * N + p] = 1; if (k == R && st == t - 1) x[5 * N + p] = 1;
      if (k == EMPTY) x[6 * N + p] = 1; x[7 * N + p] = 1; }
    return;
  }
  std::vector<int> lib; libCounts(bd, g.P, lib);
  float tf = (float)t / (float)g_opts.cap;
  for (int p = 0; p < N; p++) { int k = D.kind[p], st = D.stamp[p];
    if (k == EMPTY) x[3 * N + p] = 1;
    else { int ki = k == B ? 0 : k == W ? 1 : 2; x[ki * N + p] = 1;
      for (int ago = 1; ago <= 3; ago++) if (st == t - ago) x[(4 + 3 * (ago - 1) + ki) * N + p] = 1;
      int l = lib[g.P.cid[p]];
      if (ki < 2) { if (l == 0) x[(13 + ki) * N + p] = 1; else if (l == 1) x[(15 + ki) * N + p] = 1; else if (l == 2) x[(17 + ki) * N + p] = 1; }
      else if (l <= 1) x[19 * N + p] = 1; }
    x[20 * N + p] = 1; x[21 * N + p] = tf; }
}
// final ownership: +1 a black stone or an empty region touching black only, -1 likewise white, 0 otherwise
static void ownership(const Display& D, float* own) {
  const Board& bd = *g_board; int N = bd.N; std::vector<int> reg(N, -1); std::vector<int> st;
  for (int p = 0; p < N; p++) own[p] = D.kind[p] == B ? 1.f : D.kind[p] == W ? -1.f : 0.f;
  for (int p = 0; p < N; p++) { if (D.kind[p] != EMPTY || reg[p] >= 0) continue;
    std::vector<int> cells; bool tb = false, tw = false; st.clear(); st.push_back(p); reg[p] = p;
    while (!st.empty()) { int u = st.back(); st.pop_back(); cells.push_back(u);
      for (int a = 0; a < bd.nnb[u]; a++) { int q = bd.nbr[u][a]; int k = D.kind[q];
        if (k == EMPTY) { if (reg[q] < 0) { reg[q] = p; st.push_back(q); } } else if (k == B) tb = true; else if (k == W) tw = true; } }
    float v = tb && !tw ? 1.f : tw && !tb ? -1.f : 0.f; for (int u : cells) own[u] = v; }
}

// ---------- search ----------
struct Node {
  SGoGame g; bool terminal = false, expanded = false; float value = 0;
  std::vector<int16_t> legal; std::vector<float> P[2], W[2]; std::vector<int> Nc[2]; int Ntot = 0;
  std::unordered_map<int, int> child;
};
struct Params { float cpuct = 1.5f, fpu = 0.2f, mix = 0.f; };
struct Tree {
  std::vector<Node> nodes; int root = -1; int sims = 0, target = 0; bool noise = false;
  std::vector<std::array<int, 3>> path; int pending = -1; // node awaiting the net
  void reset(const SGoGame& g, int target_, bool noise_) { nodes.clear(); nodes.reserve(target_ + 2); root = newNode(g); sims = 0; target = target_; noise = noise_; path.clear(); pending = -1; }
  int newNode(const SGoGame& g) { nodes.emplace_back(); Node& nd = nodes.back(); nd.g = g; nd.terminal = g.ended || g.next > g_opts.cap;
    if (nd.terminal) { int m = areaMargin(*g_board, g.P.D); nd.value = m > 0 ? 1.f : m < 0 ? -1.f : 0.f; } return (int)nodes.size() - 1; }
  int select(const Node& nd, int c, const Params& pr, bool atRoot) const {
    int L = nd.legal.size(); float sq = std::sqrt((float)nd.Ntot + 1); float best = -1e30f; int bi = 0;
    float sw = 0, pexp = 0; for (int i = 0; i < L; i++) { sw += nd.W[c][i]; if (nd.Nc[c][i]) pexp += nd.P[c][i]; }
    float parent = nd.Ntot ? sw / nd.Ntot : (c == 0 ? nd.value : -nd.value);
    float fpu = parent - ((atRoot && noise) ? 0.f : pr.fpu * std::sqrt(pexp)); // KataGo's first-play urgency reduction
    for (int i = 0; i < L; i++) { float q = nd.Nc[c][i] ? nd.W[c][i] / nd.Nc[c][i] : fpu; float s = q + pr.cpuct * nd.P[c][i] * sq / (1 + nd.Nc[c][i]);
      if (s > best) { best = s; bi = i; } }
    return bi;
  }
  // descend until the net is needed (returns 1, pending set) or a simulation completed (returns 0)
  int descend(const Params& pr) {
    path.clear(); int ni = root;
    while (true) {
      Node& nd = nodes[ni];
      if (nd.terminal) { backup(nd.value); return 0; }
      if (!nd.expanded) { pending = ni; return 1; }
      int iB = select(nd, 0, pr, ni == root), iW = select(nd, 1, pr, ni == root); int key = iB * (int)nd.legal.size() + iW;
      path.push_back({ni, iB, iW});
      auto it = nd.child.find(key);
      if (it == nd.child.end()) { SGoGame g2 = nd.g; int mB = nd.legal[iB], mW = nd.legal[iW];
        sgoTurn(*g_board, g_opts, g2, mB == g_N ? -1 : mB, mW == g_N ? -1 : mW); int ci = newNode(g2); nodes[ni].child[key] = ci; ni = ci; }
      else ni = it->second;
    }
  }
  void backup(float v) { for (auto& s : path) { Node& nd = nodes[s[0]]; nd.Nc[0][s[1]]++; nd.W[0][s[1]] += v; nd.Nc[1][s[2]]++; nd.W[1][s[2]] -= v; nd.Ntot++; } sims++; }
  // the net's answer for the pending node: logits (2 x NA, Black then White) and value (Black's)
  void expand(const float* lB, const float* lW, float v, const Params& pr, Rng& rng) {
    Node& nd = nodes[pending]; bool isRoot = pending == root;
    nd.legal.clear(); for (int p = 0; p < g_N; p++) if (nd.g.P.D.kind[p] == EMPTY) nd.legal.push_back(p); nd.legal.push_back(g_N);
    int L = nd.legal.size();
    if (pr.mix > 0) { int m = sgoPlayout(*g_board, g_opts, nd.g, rng); float z = m > 0 ? 1.f : m < 0 ? -1.f : 0.f; v = (1 - pr.mix) * v + pr.mix * z; }
    nd.value = v;
    for (int c = 0; c < 2; c++) { const float* l = c == 0 ? lB : lW; nd.P[c].assign(L, 0); nd.W[c].assign(L, 0); nd.Nc[c].assign(L, 0);
      float mx = -1e30f; for (int i = 0; i < L; i++) mx = std::max(mx, l[nd.legal[i]]);
      float s = 0; for (int i = 0; i < L; i++) { nd.P[c][i] = std::exp(l[nd.legal[i]] - mx); s += nd.P[c][i]; }
      for (int i = 0; i < L; i++) nd.P[c][i] /= s; }
    if (isRoot && noise) { // Dirichlet noise, alpha = 0.03 * 361 / |legal| (AlphaZero's Go value scaled to the legal moves, as KataGo)
      std::gamma_distribution<float> gd(10.83f / L, 1.0f); std::mt19937_64 r(rng.g());
      for (int c = 0; c < 2; c++) { std::vector<float> d(L); float s = 0; for (int i = 0; i < L; i++) { d[i] = gd(r); s += d[i]; }
        if (s > 0) for (int i = 0; i < L; i++) nd.P[c][i] = 0.75f * nd.P[c][i] + 0.25f * d[i] / s; } }
    nd.expanded = true; pending = -1;
    backup(v);
  }
  // visit distributions at the root over all NA moves
  void policy(float* pB, float* pW) const { const Node& nd = nodes[root]; std::fill(pB, pB + g_NA, 0.f); std::fill(pW, pW + g_NA, 0.f);
    int L = nd.legal.size(); float t = std::max(1, nd.Ntot); for (int i = 0; i < L; i++) { pB[nd.legal[i]] = nd.Nc[0][i] / t; pW[nd.legal[i]] = nd.Nc[1][i] / t; } }
};

// ---------- Go (9x9 by default): positional superko in the games, simple ko inside the search and the playouts ----------
static int g_game = 0; // 0 SGo, 1 Go
static const int FS2_C = 15;
// Go features: 0 black, 1 white, 2 empty, 3 the last move, 4 the move before, 5 the simple-ko point, 6/7 b/w chains with
// one liberty, 8/9 with two, 10/11 with three, 12 black to move, 13 ones, 14 ply / cap.  Color swap: 0/1, 6/7, 8/9,
// 10/11 exchanged, 12 inverted.
struct GState { GoGame g; int last1 = -1, last2 = -1; };
static void goApply(GState& s, int m) { s.last2 = s.last1; s.last1 = m; goTurn(*g_board, g_opts, s.g, (m < 0 || m == g_N) ? -1 : m); }
static void featuresGo(const GState& s, float* x) {
  const Board& bd = *g_board; int N = bd.N; const Display& D = s.g.P.D; std::fill(x, x + FS2_C * N, 0.0f);
  std::vector<int> lib; libCounts(bd, s.g.P, lib); float tf = (float)s.g.turns / (float)g_opts.cap;
  for (int p = 0; p < N; p++) { int k = D.kind[p];
    if (k == EMPTY) x[2 * N + p] = 1;
    else { int ki = k == B ? 0 : 1; x[ki * N + p] = 1; int l = lib[s.g.P.cid[p]]; if (l >= 1 && l <= 3) x[(6 + 2 * (l - 1) + ki) * N + p] = 1; }
    if (s.g.toMove == B) x[12 * N + p] = 1; x[13 * N + p] = 1; x[14 * N + p] = tf; }
  if (s.last1 >= 0 && s.last1 < N) x[3 * N + s.last1] = 1; if (s.last2 >= 0 && s.last2 < N) x[4 * N + s.last2] = 1; if (s.g.ko >= 0) x[5 * N + s.g.ko] = 1;
}
static float goZ(const Display& D) { double m = goMarginB(*g_board, g_opts, D); return m > 0 ? 1.f : m < 0 ? -1.f : 0.f; }
// the moves a net may choose: the playout move set (no suicide, no own-eye fill unless a chain's last liberty, not the
// simple-ko point) and the pass; at the root of a game also no position seen before (positional superko)
static void goLegal(const GState& s, std::vector<int16_t>& out, const std::unordered_set<uint64_t>* hist) {
  int mv[MAXC]; int k = policyMovesF(*g_board, s.g.P, s.g.toMove, s.g.ko, mv); out.clear();
  for (int i = 0; i < k; i++) { if (hist) { GState t = s; goApply(t, mv[i]); if (hist->count(t.g.P.hash)) continue; } out.push_back(mv[i]); }
  out.push_back(g_N);
}
struct GNode { GState s; bool terminal = false, expanded = false; float value = 0; std::vector<int16_t> legal; std::vector<float> P, W; std::vector<int> Nc; int Ntot = 0; std::unordered_map<int, int> child; };
struct GoTree {
  std::vector<GNode> nodes; int root = -1, sims = 0, target = 0; bool noise = false; std::vector<std::array<int, 2>> path; int pending = -1;
  const std::unordered_set<uint64_t>* hist = nullptr;
  void reset(const GState& st, int target_, bool noise_, const std::unordered_set<uint64_t>* h) { nodes.clear(); nodes.reserve(target_ + 2); hist = h; root = newNode(st); sims = 0; target = target_; noise = noise_; path.clear(); pending = -1; }
  int newNode(const GState& st) { nodes.emplace_back(); GNode& nd = nodes.back(); nd.s = st; nd.terminal = st.g.ended; if (nd.terminal) nd.value = goZ(st.g.P.D); return (int)nodes.size() - 1; }
  int select(const GNode& nd, const Params& pr, bool atRoot) const {
    float sign = nd.s.g.toMove == B ? 1.f : -1.f; int L = nd.legal.size(); float sq = std::sqrt((float)nd.Ntot + 1), best = -1e30f; int bi = 0;
    float sw = 0, pexp = 0; for (int i = 0; i < L; i++) { sw += nd.W[i]; if (nd.Nc[i]) pexp += nd.P[i]; }
    float parent = sign * (nd.Ntot ? sw / nd.Ntot : nd.value), fpu = parent - ((atRoot && noise) ? 0.f : pr.fpu * std::sqrt(pexp));
    for (int i = 0; i < L; i++) { float q = nd.Nc[i] ? sign * nd.W[i] / nd.Nc[i] : fpu; float sc = q + pr.cpuct * nd.P[i] * sq / (1 + nd.Nc[i]); if (sc > best) { best = sc; bi = i; } }
    return bi;
  }
  int descend(const Params& pr) {
    path.clear(); int ni = root;
    while (true) { GNode& nd = nodes[ni];
      if (nd.terminal) { backup(nd.value); return 0; }
      if (!nd.expanded) { pending = ni; return 1; }
      int i = select(nd, pr, ni == root); path.push_back({ni, i});
      auto it = nd.child.find(i);
      if (it == nd.child.end()) { GState t = nd.s; goApply(t, nd.legal[i]); int ci = newNode(t); nodes[ni].child[i] = ci; ni = ci; } else ni = it->second; }
  }
  void backup(float v) { for (auto& q : path) { GNode& nd = nodes[q[0]]; nd.W[q[1]] += v; nd.Nc[q[1]]++; nd.Ntot++; } sims++; }
  void expand(const float* lB, const float* lW, float v, const Params& pr, Rng& rng) {
    GNode& nd = nodes[pending]; bool isRoot = pending == root; goLegal(nd.s, nd.legal, isRoot ? hist : nullptr); int L = nd.legal.size();
    if (pr.mix > 0) { double m = goPlayout(*g_board, g_opts, nd.s.g, rng); float z = m > 0 ? 1.f : m < 0 ? -1.f : 0.f; v = (1 - pr.mix) * v + pr.mix * z; }
    nd.value = v; const float* l = nd.s.g.toMove == B ? lB : lW; nd.P.assign(L, 0); nd.W.assign(L, 0); nd.Nc.assign(L, 0);
    float mx = -1e30f; for (int i = 0; i < L; i++) mx = std::max(mx, l[nd.legal[i]]); float sm = 0;
    for (int i = 0; i < L; i++) { nd.P[i] = std::exp(l[nd.legal[i]] - mx); sm += nd.P[i]; } for (int i = 0; i < L; i++) nd.P[i] /= sm;
    if (isRoot && noise) { std::gamma_distribution<float> gd(10.83f / L, 1.0f); std::mt19937_64 r(rng.g()); std::vector<float> d(L); float t = 0;
      for (int i = 0; i < L; i++) { d[i] = gd(r); t += d[i]; } if (t > 0) for (int i = 0; i < L; i++) nd.P[i] = 0.75f * nd.P[i] + 0.25f * d[i] / t; }
    nd.expanded = true; pending = -1; backup(v);
  }
  void policy(float* pol) const { const GNode& nd = nodes[root]; std::fill(pol, pol + g_NA, 0.f); float t = std::max(1, nd.Ntot); for (size_t i = 0; i < nd.legal.size(); i++) pol[nd.legal[i]] = nd.Nc[i] / t; }
};

// ---------- players, games, the pool ----------
struct Player { int kind = 0; int net = 0; int fs = 1; int sims = 100; int budget = 0; Params pr; }; // kind 0 net, 1 Monte Carlo
struct Sample { std::vector<uint8_t> x; float tf; std::vector<float> pB, pW; };
struct Slot {
  bool active = false; int game = -1; SGoGame g; Tree tree; int phase = 0; // selfplay: 0 search; arena: 0 Black's search, 1 White's
  int mB = -1, mW = -1; bool full = false; std::vector<Sample> recs; std::unordered_set<uint64_t> seen; bool rep = false;
  std::unique_ptr<Rng> rng;
  int qc = 0, peak = 0, peakInner = 0, peakBr = 1; // SGo: q-stones created in the game's turns, the largest recursion depth of a turn
  // (stages that removed a stone), the largest number of removing basic capture reductions within a stage, the most branches
  Ent ent; // SGo: the entanglement (branch counts), kept only when g_entStats is on
  GState gs; GoTree gt; std::unordered_set<uint64_t> hist; // Go: the game, its tree, the positions so far (superko)
};
struct Request { int slot; };
struct Pool {
  int mode = 0; // 0 self-play, 1 arena
  int games = 0, started = 0, finished = 0; std::vector<Slot> slots; uint64_t seed = 1;
  // self-play
  Player self; int simsFull = 600, simsFast = 100; float pFull = 0.25f; float tempHi = 0.8f, tempLo = 0.2f, tempHalf = 9.f;
  // arena
  Player pl[2]; // pl[0] = A, pl[1] = B; A plays Black in even games
  // outputs
  std::vector<uint8_t> outX; std::vector<float> outPB, outPW, outZ, outOwn, outMargin; std::vector<float> outTF; int outN = 0;
  std::vector<int> res; // arena: per finished game: game index, margin, A black (1/0), turns
  std::vector<int> gst; // every finished game (both modes), GST ints each: game, Black's margin (Go: twice, komi included), A black (-1 in self play), turns, q-stones created, q-stones on the final display, peak recursion depth (stages), peak basic capture reductions in a stage, peak branches, final branches (-1 when not kept)
  std::vector<std::vector<int>> pend; // per net id: slots awaiting it
};

static const int GST = 10, BRCAP = 20000; static bool g_entStats = false;
static int g_openSample = 0; // sz_open_sample(k): in the arena the first k turns (Go: 2k plies) sample the move from the visits (T = 1)
// a display repeats when its kinds repeat (the stamps differ on every turn, so the position hash never repeats in a cycle)
static uint64_t kindsHash(const Display& D, int N) { uint64_t h = 1469598103934665603ULL; for (int i = 0; i < N; i++) h = mix64(h ^ ((uint64_t)D.kind[i] << 8 | (uint64_t)i)); return h; } // sz_stat_branches(1): keep the entanglement in every game
static Player& playerOf(Pool& P, Slot& s, int color) { // color 0 Black, 1 White
  if (P.mode == 0) return P.self; bool aBlack = s.game % 2 == 0; return P.pl[(color == 0) == aBlack ? 0 : 1]; }

static float temperature(const Pool& P, int turn) { return P.tempLo + (P.tempHi - P.tempLo) * std::pow(0.5f, (turn - 1) / P.tempHalf); }
static int sampleT(const float* pol, float T, Rng& rng) {
  double w[MAXC + 1], s = 0; for (int a = 0; a < g_NA; a++) { w[a] = pol[a] > 0 ? std::pow((double)pol[a], 1.0 / T) : 0; s += w[a]; }
  if (s <= 0) return g_N; double u = (rng.g() % 1000000007ULL) / 1000000007.0 * s, acc = 0; for (int a = 0; a < g_NA; a++) { acc += w[a]; if (u < acc) return a; } return g_N;
}
static int argmaxPol(const float* pol, Rng& rng) { float best = -1; int bi = g_N; for (int a = 0; a < g_NA; a++) if (pol[a] > best + 1e-9f || (std::fabs(pol[a] - best) <= 1e-9f && rng.below(2))) { best = pol[a]; bi = a; } return bi; }

static bool startGame(Pool& P, Slot& s) { // claims the next game, if any
  int gi = -1;
#pragma omp critical(sz_start)
  { if (P.started < P.games) gi = P.started++; }
  if (gi < 0) return false;
  s.active = true; s.game = gi; s.qc = 0; s.peak = 0; s.peakInner = 0; s.peakBr = 1; if (g_entStats) entInit(s.ent, g_board->N); s.g.init(g_board->N); s.phase = 0; s.recs.clear(); s.seen.clear(); s.rep = false;
  s.rng.reset(new Rng(mix64(P.seed * 1000003ULL + 17 + 7919ULL * s.game)));
  if (g_game == 1) { s.gs = GState(); s.gs.g.init(g_board->N); s.hist.clear(); s.hist.insert(s.gs.g.P.hash); }
  return true;
}
static int moverOf(const Slot& s) { return s.gs.g.toMove == B ? 0 : 1; }
static void beginSearch(Pool& P, Slot& s) {
  if (g_game == 1) {
    if (P.mode == 0) { s.full = (s.rng->g() % 10000) < (uint64_t)(P.pFull * 10000); s.gt.reset(s.gs, s.full ? P.simsFull : P.simsFast, s.full, &s.hist); }
    else { Player& pp = playerOf(P, s, moverOf(s)); s.gt.reset(s.gs, pp.sims, false, &s.hist); }
    return;
  }
  if (P.mode == 0) { s.full = (s.rng->g() % 10000) < (uint64_t)(P.pFull * 10000); s.tree.reset(s.g, s.full ? P.simsFull : P.simsFast, s.full); }
  else { Player& pp = playerOf(P, s, s.phase); s.tree.reset(s.g, pp.sims, false); }
}
static void finishGameGo(Pool& P, Slot& s) {
  double md = goMarginB(*g_board, g_opts, s.gs.g.P.D); float z = md > 0 ? 1.f : md < 0 ? -1.f : 0.f; int N = g_board->N;
#pragma omp critical(sz_out)
  {
  if (P.mode == 0) { std::vector<float> own(N); ownership(s.gs.g.P.D, own.data()); int C = FS2_C;
    for (auto& r : s.recs) { P.outX.insert(P.outX.end(), r.x.begin(), r.x.end()); P.outTF.push_back(r.tf);
      P.outPB.insert(P.outPB.end(), r.pB.begin(), r.pB.end()); P.outPW.insert(P.outPW.end(), r.pW.begin(), r.pW.end());
      P.outZ.push_back(z); P.outMargin.push_back((float)md); P.outOwn.insert(P.outOwn.end(), own.begin(), own.end()); P.outN++; }
    (void)C; s.recs.clear(); }
  else { P.res.push_back(s.game); P.res.push_back((int)std::lround(2 * md)); P.res.push_back(s.game % 2 == 0 ? 1 : 0); P.res.push_back(s.gs.g.turns); }
  { int st[GST] = {s.game, (int)std::lround(2 * md), P.mode == 0 ? -1 : (s.game % 2 == 0 ? 1 : 0), s.gs.g.turns, 0, 0, 0, 0, -1, -1}; P.gst.insert(P.gst.end(), st, st + GST); }
  P.finished++;
  }
  s.active = false;
}
static void finishGame(Pool& P, Slot& s) {
  if (g_game == 1) { finishGameGo(P, s); return; }
  int m = areaMargin(*g_board, s.g.P.D); float z = m > 0 ? 1.f : m < 0 ? -1.f : 0.f; int N = g_board->N;
#pragma omp critical(sz_out)
  {
  if (P.mode == 0) { std::vector<float> own(N); ownership(s.g.P.D, own.data()); int C = nplanes(1);
    for (auto& r : s.recs) { for (int i = 0; i < C * N; i++) P.outX.push_back(r.x[i]); P.outTF.push_back(r.tf);
      P.outPB.insert(P.outPB.end(), r.pB.begin(), r.pB.end()); P.outPW.insert(P.outPW.end(), r.pW.begin(), r.pW.end());
      P.outZ.push_back(z); P.outMargin.push_back((float)m); P.outOwn.insert(P.outOwn.end(), own.begin(), own.end()); P.outN++; }
    s.recs.clear(); }
  else { P.res.push_back(s.game); P.res.push_back(m); P.res.push_back(s.game % 2 == 0 ? 1 : 0); P.res.push_back(s.g.next - 1); }
  { int qf = 0; for (int q = 0; q < N; q++) if (s.g.P.D.kind[q] == R) qf++;
    int st[GST] = {s.game, m, P.mode == 0 ? -1 : (s.game % 2 == 0 ? 1 : 0), s.g.next - 1, s.qc, qf, s.peak, s.peakInner, g_entStats ? s.peakBr : -1, !g_entStats ? -1 : s.ent.defined ? (int)s.ent.b.size() : -2};
    P.gst.insert(P.gst.end(), st, st + GST); }
  P.finished++;
  }
  s.active = false;
}
// the moves are known: play the turn
static void arenaMove(Pool& P, Slot& s);
static void playTurn(Pool& P, Slot& s) {
  s.seen.insert(kindsHash(s.g.P.D, g_N));
  int q0 = g_qCreated;
  int m0 = s.mB == g_N ? -1 : s.mB, m1 = s.mW == g_N ? -1 : s.mW;
  sgoTurn(*g_board, g_opts, s.g, m0, m1);
  s.qc += g_qCreated - q0; if (g_depth > s.peak) s.peak = g_depth; if (g_inner > s.peakInner) s.peakInner = g_inner; // the engine's per-thread counters, read right after the game's own turn
  if (g_entStats && s.ent.defined) { entStep(*g_board, s.ent, s.g.P.D, m0, m1); if ((int)s.ent.b.size() > s.peakBr) s.peakBr = (int)s.ent.b.size();
    if ((int)s.ent.b.size() > BRCAP) { s.ent.defined = false; s.peakBr = BRCAP + 1; } } // too many to follow: reported as BRCAP + 1, the final count as -2
  if (s.g.ended || s.g.next > g_opts.cap) finishGame(P, s);
  else { s.phase = 0; if (P.mode == 0) beginSearch(P, s); else arenaMove(P, s); }
}
// a finished search: choose the move(s)
static void arenaMove(Pool& P, Slot& s);
static void searchDone(Pool& P, Slot& s) {
  float pB[MAXC + 1], pW[MAXC + 1]; s.tree.policy(pB, pW);
  if (P.mode == 0) {
    if (s.full) { Sample r; int C = nplanes(1), N = g_board->N; std::vector<float> x(C * N); features(s.g, 1, x.data());
      for (int q = 0; q < N; q++) x[21 * N + q] = 0; // the turn plane is rebuilt from tf
      r.x.resize(C * N); for (int i = 0; i < C * N; i++) r.x[i] = (uint8_t)(x[i] > 0.5f ? 1 : 0); r.tf = (float)s.g.next / g_opts.cap;
      r.pB.assign(pB, pB + g_NA); r.pW.assign(pW, pW + g_NA); s.recs.push_back(std::move(r)); }
    float T = temperature(P, s.g.next); s.mB = sampleT(pB, T, *s.rng); s.mW = sampleT(pW, T, *s.rng);
    playTurn(P, s);
  } else {
    bool repeat = s.seen.count(kindsHash(s.g.P.D, g_N)) > 0; // a display (kinds) seen before in this game: sample from the visits (breaks loops)
    bool open = s.g.next <= g_openSample; // the opening of a varied ladder game
    const float* pol = s.phase == 0 ? pB : pW; int m = (repeat || open) ? sampleT(pol, 1.f, *s.rng) : argmaxPol(pol, *s.rng);
    if (s.phase == 0) { s.mB = m; s.phase = 1; arenaMove(P, s); } else { s.mW = m; playTurn(P, s); }
  }
}
// arena: the player of the current phase moves: a net starts its search (run by sz_step), a Monte Carlo agent moves at once
static void arenaMove(Pool& P, Slot& s) {
  while (s.active) {
    Player& pp = playerOf(P, s, s.phase);
    if (pp.kind == 0) { beginSearch(P, s); return; }
    int c = s.phase == 0 ? B : W; int m = sgoAgent(*g_board, g_opts, s.g, c, pp.budget, *s.rng); m = m < 0 ? g_N : m;
    if (s.phase == 0) { s.mB = m; s.phase = 1; continue; }
    s.mW = m; playTurn(P, s); return;
  }
}

// Go: the mover of the ply moves; a Monte Carlo agent at once (with superko), a net through its search
static void goArenaMove(Pool& P, Slot& s);
static void goPlay(Pool& P, Slot& s, int m) {
  goApply(s.gs, m); s.hist.insert(s.gs.g.P.hash);
  if (s.gs.g.ended) finishGame(P, s);
  else if (P.mode == 0) beginSearch(P, s); else goArenaMove(P, s);
}
static void goArenaMove(Pool& P, Slot& s) {
  if (!s.active) return;
  Player& pp = playerOf(P, s, moverOf(s));
  if (pp.kind == 0) { beginSearch(P, s); return; }
  int m = goAgent(*g_board, g_opts, s.gs.g, pp.budget, *s.rng, &s.hist); goPlay(P, s, m < 0 ? g_N : m);
}
static void searchDoneGo(Pool& P, Slot& s) {
  float pol[MAXC + 1]; s.gt.policy(pol); int c = moverOf(s);
  if (P.mode == 0) {
    if (s.full) { Sample r; int N = g_board->N; std::vector<float> x(FS2_C * N); featuresGo(s.gs, x.data()); for (int q = 0; q < N; q++) x[14 * N + q] = 0;
      r.x.resize(FS2_C * N); for (int i = 0; i < FS2_C * N; i++) r.x[i] = (uint8_t)(x[i] > 0.5f ? 1 : 0); r.tf = (float)s.gs.g.turns / g_opts.cap;
      r.pB.assign(g_NA, 0.f); r.pW.assign(g_NA, 0.f); (c == 0 ? r.pB : r.pW).assign(pol, pol + g_NA); s.recs.push_back(std::move(r)); }
    goPlay(P, s, sampleT(pol, temperature(P, s.gs.g.turns + 1), *s.rng));
  } else goPlay(P, s, s.gs.g.turns < 2 * g_openSample ? sampleT(pol, 1.f, *s.rng) : argmaxPol(pol, *s.rng));
}

} // namespace sz
using namespace sz;

extern "C" {
// rules and board: side n, placement rule (4 = the paper's), orphan route (1 = rule D), eye defense in playouts, turn cap
void sz_config(int n, int place, int orphan, int eyedef, int cap) {
  g_n = n; g_place = place; g_orphan = orphan != 0; g_eyedef = eyedef != 0; g_check = false;
  g_board.reset(new Board(n)); g_opts = Opts(); g_opts.n = n; g_opts.ko = false; g_opts.cap = cap; g_opts.pdepth = 0;
  g_side = n; g_N = n * n; g_NA = g_N + 1;
}
int sz_nplanes(int fs) { return nplanes(fs); }
// the game: 0 SGo (default), 1 Go with komi (simple ko inside searches and playouts, positional superko in the games)
void sz_set_game(int game, double komi) { g_game = game; g_opts.ko = game == 1; g_opts.komi = game == 1 ? komi : 0.0; }
int sz_game_fs() { return g_game == 1 ? 2 : 1; }
// the planes the color swap inverts (Go: black to move); returns how many
int sz_swap_invert(int* inv) { if (g_game == 1) { inv[0] = 12; return 1; } return 0; }
// the color swap of feature set 1: perm[i] = the plane that plane i becomes
void sz_swap_perm(int* perm) {
  if (g_game == 1) { for (int i = 0; i < FS2_C; i++) perm[i] = i; int pg[][2] = {{0, 1}, {6, 7}, {8, 9}, {10, 11}}; for (auto& q : pg) { perm[q[0]] = q[1]; perm[q[1]] = q[0]; } return; }
  for (int i = 0; i < FS1_C; i++) perm[i] = i; int pr[][2] = {{0, 1}, {4, 5}, {7, 8}, {10, 11}, {13, 14}, {15, 16}, {17, 18}};
  for (auto& q : pr) { perm[q[0]] = q[1]; perm[q[1]] = q[0]; } }
void* sz_selfplay(int games, int slots, uint64_t seed, int simsFull, int simsFast, float pFull, float cpuct, float fpu, float mix) {
  Pool* P = new Pool(); P->mode = 0; P->games = games; P->seed = seed; P->simsFull = simsFull; P->simsFast = simsFast; P->pFull = pFull;
  P->self.kind = 0; P->self.net = 0; P->self.fs = g_game == 1 ? 2 : 1; if (g_game == 1) P->tempHalf = 18.f; // Go: the half-life in plies (9 moves a side, as in SGo) P->self.pr.cpuct = cpuct; P->self.pr.fpu = fpu; P->self.pr.mix = mix;
  P->slots.resize(std::min(slots, games)); P->pend.resize(2); return P;
}
// arena: player = net (kind 0: net id, feature set, sims, mix) or Monte Carlo (kind 1: budget); A is Black in even games
void* sz_arena(int games, int slots, uint64_t seed, int kA, int netA, int fsA, int simsA, float mixA, int budgetA,
               int kB, int netB, int fsB, int simsB, float mixB, int budgetB, float cpuct, float fpu) {
  Pool* P = new Pool(); P->mode = 1; P->games = games; P->seed = seed;
  P->pl[0].kind = kA; P->pl[0].net = netA; P->pl[0].fs = fsA; P->pl[0].sims = simsA; P->pl[0].pr.mix = mixA; P->pl[0].budget = budgetA;
  P->pl[1].kind = kB; P->pl[1].net = netB; P->pl[1].fs = fsB; P->pl[1].sims = simsB; P->pl[1].pr.mix = mixB; P->pl[1].budget = budgetB;
  for (int i = 0; i < 2; i++) { P->pl[i].pr.cpuct = cpuct; P->pl[i].pr.fpu = fpu; }
  P->slots.resize(std::min(slots, games)); P->pend.resize(2); return P;
}
void sz_free(void* p) { delete (Pool*)p; }
// advance every game to its next request for a net; returns the number of games still running
void sz_threads(int n) { if (n > 0) omp_set_num_threads(n); }
int sz_step(void* p) {
  Pool& P = *(Pool*)p; for (auto& q : P.pend) q.clear(); int S = (int)P.slots.size();
#pragma omp parallel for schedule(dynamic, 1)
  for (int i = 0; i < S; i++) { Slot& s = P.slots[i];
    if (g_game == 1) {
      while (true) {
        if (!s.active) { if (!startGame(P, s)) break; if (P.mode == 0) beginSearch(P, s); else goArenaMove(P, s); continue; }
        if (s.gt.pending >= 0) break;
        if (s.gt.sims >= s.gt.target) { searchDoneGo(P, s); continue; }
        if (s.gt.descend(playerOf(P, s, P.mode == 0 ? 0 : moverOf(s)).pr)) break;
      }
      continue;
    }
    while (true) {
      if (!s.active) { if (!startGame(P, s)) break; if (P.mode == 0) beginSearch(P, s); else arenaMove(P, s); continue; }
      if (s.tree.pending >= 0) break;
      if (s.tree.sims >= s.tree.target) { searchDone(P, s); continue; }
      Player& pp = playerOf(P, s, P.mode == 0 ? 0 : s.phase);
      if (s.tree.descend(pp.pr)) break; // waits for the net
    }
  }
  int running = 0;
  for (int i = 0; i < S; i++) { Slot& s = P.slots[i]; if (!s.active) continue; running++;
    if (g_game == 1) { if (s.gt.pending >= 0) P.pend[playerOf(P, s, P.mode == 0 ? 0 : moverOf(s)).net].push_back(i); }
    else if (s.tree.pending >= 0) P.pend[playerOf(P, s, P.mode == 0 ? 0 : s.phase).net].push_back(i); }
  return running;
}
int sz_pending(void* p, int net) { return (int)((Pool*)p)->pend[net].size(); }
int sz_pending_fs(void* p, int net) { Pool& P = *(Pool*)p; if (g_game == 1) return 2; return P.mode == 0 ? P.self.fs : (P.pl[0].net == net && P.pl[0].kind == 0 ? P.pl[0].fs : P.pl[1].fs); }
// the features of the requests for one net, in order: [count][planes][N]
void sz_pending_features(void* p, int net, float* out) {
  Pool& P = *(Pool*)p; int fs = sz_pending_fs(p, net), C = nplanes(fs), N = g_board->N;
  int K = (int)P.pend[net].size();
#pragma omp parallel for schedule(static)
  for (int j = 0; j < K; j++) { Slot& s = P.slots[P.pend[net][j]];
    if (g_game == 1) featuresGo(s.gt.nodes[s.gt.pending].s, out + (size_t)j * C * N); else features(s.tree.nodes[s.tree.pending].g, fs, out + (size_t)j * C * N); }
}
// the net's answers, same order: logits [count][2][NA] (Black, White), values [count] (Black's, in [-1, 1])
void sz_feed(void* p, int net, const float* logits, const float* values) {
  Pool& P = *(Pool*)p;
  int K = (int)P.pend[net].size();
#pragma omp parallel for schedule(dynamic, 4)
  for (int j = 0; j < K; j++) { Slot& s = P.slots[P.pend[net][j]];
    if (g_game == 1) { Player& pg = playerOf(P, s, P.mode == 0 ? 0 : moverOf(s)); s.gt.expand(logits + (size_t)j * 2 * g_NA, logits + (size_t)j * 2 * g_NA + g_NA, values[j], pg.pr, *s.rng); continue; }
    Player& pp = playerOf(P, s, P.mode == 0 ? 0 : s.phase);
    s.tree.expand(logits + (size_t)j * 2 * g_NA, logits + (size_t)j * 2 * g_NA + g_NA, values[j], pp.pr, *s.rng); }
  P.pend[net].clear();
}
int sz_finished(void* p) { return ((Pool*)p)->finished; }
int sz_samples(void* p) { return ((Pool*)p)->outN; }
// self-play samples since the last call: x [n][planes][N] (0/1, the turn plane left 0), tf [n], pB/pW [n][NA], z [n], margin [n], own [n][N]
void sz_take_samples(void* p, uint8_t* x, float* tf, float* pB, float* pW, float* z, float* margin, float* own) {
  Pool& P = *(Pool*)p; std::copy(P.outTF.begin(), P.outTF.end(), tf); for (size_t i = 0; i < P.outX.size(); i++) x[i] = (uint8_t)P.outX[i];
  std::copy(P.outPB.begin(), P.outPB.end(), pB); std::copy(P.outPW.begin(), P.outPW.end(), pW); std::copy(P.outZ.begin(), P.outZ.end(), z);
  std::copy(P.outMargin.begin(), P.outMargin.end(), margin); std::copy(P.outOwn.begin(), P.outOwn.end(), own);
  P.outX.clear(); P.outTF.clear(); P.outPB.clear(); P.outPW.clear(); P.outZ.clear(); P.outMargin.clear(); P.outOwn.clear(); P.outN = 0;
}
// arena results so far: 4 ints per finished game (game, Black's margin, A black, turns); returns the count
int sz_gstats(void* p, int* out) { Pool& P = *(Pool*)p; std::copy(P.gst.begin(), P.gst.end(), out); return (int)P.gst.size() / GST; }
int sz_gst_width() { return GST; }
void sz_stat_branches(int on) { g_entStats = on != 0; }
void sz_open_sample(int k) { g_openSample = k < 0 ? 0 : k; }
int sz_results(void* p, int* out) { Pool& P = *(Pool*)p; std::copy(P.res.begin(), P.res.end(), out); return (int)P.res.size() / 4; }
}
