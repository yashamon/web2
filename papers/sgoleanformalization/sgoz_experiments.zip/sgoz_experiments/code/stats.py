#!/usr/bin/env python3
"""Statistics of strong play: one net against itself, for the paper's table of Section 2 (the random play columns) and
its informed play counterpart.

  python stats.py --work <folder> --net g48                       400 games, the net v itself, 100 simulations a move,
                                                                  the first 4 turns drawn from the visits, then the most
                                                                  visited move (the conditions of the ladder_o4 ladders)
  python stats.py --work <folder> --net g48 --mode selfplay       the training games' conditions instead (600/100
                                                                  simulations, root noise, temperature): more varied
  python stats.py --table <sgo .json> <go .json>                   the two runs side by side, as the paper's table
Writes runs/stats_<net>_<mode>.txt and .json in the work folder.  SGo games also keep the entanglement (branch counts).
Per game (lib.gstats): game, margin, A black, turns, q-stones created, q-stones on the final display, peak recursion
depth (stages of the objective reduction R^k that removed a stone), peak number of removing basic capture reductions
within one stage (the iterations of Cap~ in Cap_n), peak and final number of branches."""
import argparse, json, math, os, sys, time
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import run


def summarize(st, cfg, R, name):
    go = cfg.get('game') == 'go'; n = len(st)
    m = st[:, 1] / (2.0 if go else 1.0); turns = st[:, 3]
    capped = turns >= R.cap; own = ~capped
    se = lambda x: x.std(ddof=1) / math.sqrt(len(x)) if len(x) > 1 else 0.0
    distinct = len({tuple(r[1:]) for r in st.tolist()})
    L = [f'{name}: {n} games ({distinct} distinct by margin, length and q-stone counts)',
         f'  mean |margin|               {np.abs(m).mean():.1f}' + ('  (Go: area difference after komi 7.5)' if go else ''),
         f'  draws                       {100 * np.mean(m == 0):.1f}%',
         f'  games ending on their own   {100 * own.mean():.1f}%  (cap {R.cap} {"plies" if go else "turns"})',
         f'  mean length                 {turns[own].mean() if own.any() else float("nan"):.1f} {"plies" if go else "turns"} (games that ended)',
         f'  signed margin for Black     {m.mean():+.2f} +- {se(m):.2f}',
         f'  Black wins                  {100 * np.mean(m > 0):.1f}%']
    if not go:
        L += [f'  q-stones created per game   {st[:, 4].mean():.2f}',
              f'  q-stones on the final board {st[:, 5].mean():.2f}',
              f'  peak recursion depth        mean {st[:, 6].mean():.2f}, max {st[:, 6].max()}  (stages R^k that removed a stone)',
              f'  peak capture iterations     mean {st[:, 7].mean():.2f}, max {st[:, 7].max()}  (removing basic capture reductions in one stage)']
        if (st[:, 8] >= 0).all():
            over = int((st[:, 9] == -2).sum()); fin = st[st[:, 9] >= 0, 9]
            L += [f'  peak number of branches     median {np.median(st[:, 8]):.0f}, mean {st[:, 8].mean():.1f}, max {st[:, 8].max()}' + (f'  ({over} games passed 20000 and stopped being followed)' if over else ''),
                  f'  final number of branches    median {np.median(fin) if len(fin) else float("nan"):.0f}, mean {fin.mean() if len(fin) else float("nan"):.1f}']
    return '\n'.join(L)


def table(fs, fg):
    """The paper's table: strong play, SGo and Go columns (rows as in Section 2.2)."""
    S = np.array(json.load(open(fs))); G = np.array(json.load(open(fg))); ms = S[:, 1].astype(float); mg = G[:, 1] / 2.0
    cs, cg = json.load(open(fs[:-5] + '.cap')) if os.path.exists(fs[:-5] + '.cap') else 200, json.load(open(fg[:-5] + '.cap')) if os.path.exists(fg[:-5] + '.cap') else 300
    row = lambda name, a, b: print(f'{name:<34} & {a} & {b} \\\\')
    print(f'% {len(S)} SGo games, {len(G)} Go games')
    row('mean margin', f'${np.abs(ms).mean():.1f}$', f'${np.abs(mg).mean():.1f}$')
    row('draws', f'${100 * np.mean(ms == 0):.1f}\\%$', f'${100 * np.mean(mg == 0):.1f}\\%$')
    row('Black wins', f'${100 * np.mean(ms > 0):.0f}\\%$', f'${100 * np.mean(mg > 0):.0f}\\%$')
    row('games ending on their own', f'${100 * np.mean(S[:, 3] < cs):.1f}\\%$', f'${100 * np.mean(G[:, 3] < cg):.1f}\\%$')
    row('mean length in ticks', f'${S[:, 3].mean():.1f}$', f'${G[:, 3].mean() / 2:.1f}$')  # a tick: one move by both players (Go: two moves)
    row('q-stones created per game', f'${S[:, 4].mean():.1f}$', '--')
    row('q-stones on the final display', f'${S[:, 5].mean():.1f}$', '--')
    row('peak recursion depth', f'${S[:, 6].mean():.2f}$ (max ${S[:, 6].max()}$)', '--')
    row('peak iteration count', f'${S[:, 7].mean():.2f}$ (max ${S[:, 7].max()}$)', '--')
    if (S[:, 8] >= 0).all():
        fin = S[S[:, 9] >= 0, 9]; over = int((S[:, 9] == -2).sum())
        row('peak number of branches', f'${S[:, 8].mean():.1f}$ (median ${np.median(S[:, 8]):.0f}$, max ${S[:, 8].max()}$)', '--')
        row('final number of branches', f'${fin.mean():.1f}$ (median ${np.median(fin):.0f}$)', '--')
        if over: print(f'% {over} SGo games passed 20000 branches and stopped being followed (counted at 20001, left out of the final row)')


def main():
    if len(sys.argv) == 4 and sys.argv[1] == '--table':
        table(sys.argv[2], sys.argv[3]); return
    ap = argparse.ArgumentParser(); ap.add_argument('--work', default=HERE); ap.add_argument('--net', required=True)
    ap.add_argument('--games', type=int, default=400); ap.add_argument('--mode', choices=['match', 'selfplay'], default='match')
    ap.add_argument('--open', type=int, default=4, help='match mode: the first k turns (Go: 2k plies) draw the move from the visits, as the ladder_o4 ladders')
    ap.add_argument('--test', action='store_true', help='no torch: a uniform stand-in for the net (checks the plumbing)'); a = ap.parse_args()
    cfg = dict(run.DEFAULT); cfg.update(json.load(open(os.path.join(a.work, 'config.json')))); cfg['work'] = a.work
    from sgoz import lib as L
    R = run.rules(cfg); spec = os.path.join(a.work, 'models', a.net + '.pt')
    if a.test:
        ev = lambda x: (np.zeros((x.shape[0], 2, R.NA), np.float32), np.zeros(x.shape[0], np.float32)); evs = lambda: ev
    else:
        import torch
        from sgoz.model import load, Evaluator
        dev = 'cuda' if torch.cuda.is_available() else 'cpu'; model = load(spec, dev)
        evs = lambda: Evaluator(model, dev, seed=int(time.time()) % 100000)
    if cfg.get('game') != 'go': L.lib().sz_stat_branches(1)
    L.lib().sz_open_sample(a.open if a.mode == 'match' else 0)
    t = time.time(); g = int(a.net[1:]) if a.net[1:].isdigit() else 999
    if a.mode == 'match':
        pA = run.player(cfg, spec, 0); pB = run.player(cfg, spec, 1)
        pool = L.lib().sz_arena(a.games, min(a.games, cfg['slots']), 31337, *pA, *pB, cfg['cpuct'], cfg['fpu'])
        L.run_pool(pool, {0: evs(), 1: evs()}, R)
    else:
        pool = L.lib().sz_selfplay(a.games, min(a.games, cfg['slots']), 4242, cfg['sims_full'], cfg['sims_fast'], cfg['p_full'], cfg['cpuct'], cfg['fpu'], run.mix_of(cfg, g))
        L.run_pool(pool, {0: evs()}, R); L.take_samples(pool, R)
    st = L.gstats(pool, a.games); L.lib().sz_free(pool)
    name = f'{cfg.get("game", "sgo")} {a.net} v itself, {a.mode}{" open " + str(a.open) if a.mode == "match" else ""} ({time.time() - t:.0f} s)'
    out = summarize(st, cfg, R, name); print(out)
    if not a.test:
        base = os.path.join(a.work, 'runs', f'stats_{a.net}_{a.mode}')
        open(base + '.txt', 'w').write(out + '\n'); json.dump(st.tolist(), open(base + '.json', 'w')); json.dump(R.cap, open(base + '.cap', 'w'))


if __name__ == '__main__':
    main()
