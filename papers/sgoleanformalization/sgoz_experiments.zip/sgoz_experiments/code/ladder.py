#!/usr/bin/env python3
"""The depth ladder of the GPU line (as in the paper: agents of increasing strength, Elo from their games, random = 0).

  python ladder.py            plays the missing pairs (resumable), then fits and prints the ladder
  python ladder.py --fit      only the fit
  python ladder.py --open 4 --tag _o4   varied games: the first 4 turns (Go: 8 plies) sample the move from the search's
                              visits (T = 1); games and ladder go to runs/ladder_o4/ and runs/ladder_o4.txt
In every ladder a game whose display (stones, without the stamps) repeats samples that turn's move from the visits.

Rungs: the Monte Carlo agents of the paper (mc0 = random policy, mc26, mc205, mc3277), the old champion g35 (old line,
100 simulations), and nets of this line.  Each rung plays its neighbour (96 games) and its second neighbour (32 games);
nets at 100 simulations.  Bradley-Terry fit (draws count half, a small prior keeps all-win pairs finite), bootstrap
errors.  Games: runs/ladder/<A>__<B>.json; ladder: runs/ladder.txt."""
import argparse, json, math, os, sys, time, random
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import run

RUNGS = ['mc0', 'mc26', 'mc205', 'mc3277', 'g0', 'g1', 'g2', 'old35', 'g3', 'g4', 'g6', 'g8', 'g12', 'g16', 'g20', 'g24', 'g32', 'g40', 'g48', 'g56', 'g64', 'g72']  # the later ones only where they exist (Go ran on)
NEAR, FAR = 96, 32


def spec(r, work):
    if r.startswith('mc'): return r
    if r == 'old35': return os.path.join(HERE, 'nets', 'g35.bin')
    return os.path.join(work, 'models', r + '.pt')


def fit(games, names, prior=0.1, boots=300):
    n = len(names); idx = {x: i for i, x in enumerate(names)}
    def bt(G):
        w = [0.0] * n; cnt = {}
        for (a, b), sc in G.items():
            i, j = idx[a], idx[b]; s = sum(sc); w[i] += s + prior / 2; w[j] += len(sc) - s + prior / 2; cnt[(i, j)] = len(sc) + prior
        g = [1.0] * n
        for _ in range(3000):
            new = []
            for i in range(n):
                den = sum(c / (g[i] + g[b if a == i else a]) for (a, b), c in cnt.items() if i in (a, b))
                new.append(w[i] / den if den > 0 else g[i])
            m = sum(math.log(x) for x in new) / n; new = [x / math.exp(m) for x in new]
            done = max(abs(math.log(new[i] / g[i])) for i in range(n)) < 1e-10; g = new
            if done: break
        e = [400 * math.log10(x) for x in g]; return [x - e[0] for x in e]  # random (mc0) = 0
    base = bt(games); random.seed(5); bs = [[] for _ in range(n)]
    for _ in range(boots):
        e = bt({k: [random.choice(v) for _ in v] for k, v in games.items()})
        for i in range(n): bs[i].append(e[i])
    se = [(sum((x - sum(b) / len(b)) ** 2 for x in b) / (len(b) - 1)) ** 0.5 for b in bs]
    return base, se


def main():
    ap = argparse.ArgumentParser(); ap.add_argument('--work', default=HERE); ap.add_argument('--fit', action='store_true')
    ap.add_argument('--open', type=int, default=0); ap.add_argument('--tag', default=''); a = ap.parse_args()
    cfg = dict(run.DEFAULT); cfg.update(json.load(open(os.path.join(a.work, 'config.json')))); cfg['work'] = a.work
    rungs = [r for r in RUNGS if (r.startswith('mc') or os.path.exists(spec(r, a.work))) and not (r == 'old35' and (cfg.get('game') == 'go' or cfg.get('place', 4) != 4 or not cfg.get('orphan', 1)))]  # g35 was trained under rule D
    d = os.path.join(a.work, 'runs', 'ladder' + a.tag); os.makedirs(d, exist_ok=True)
    pairs = [(rungs[i], rungs[i + 1], NEAR) for i in range(len(rungs) - 1)] + [(rungs[i], rungs[i + 2], FAR) for i in range(len(rungs) - 2)]
    if not a.fit:
        import torch
        from sgoz import lib as L
        R = run.rules(cfg); dev = 'cuda' if torch.cuda.is_available() else 'cpu'; L.lib().sz_open_sample(a.open)
        for k, (x, y, ng) in enumerate(pairs):
            f = os.path.join(d, f'{x}__{y}.json')
            if os.path.exists(f): continue
            print(f'{time.strftime("%H:%M")} [{k + 1}/{len(pairs)}] {x} v {y}: playing {ng} games ...', flush=True)
            t = time.time(); sc, n, elo, wdl = run.arena(cfg, R, spec(x, a.work), spec(y, a.work), ng, 90000 + 97 * k, dev)
            w, dr, l = map(int, wdl.split('-'))
            json.dump({'a': x, 'b': y, 'scores': [1.0] * w + [0.5] * dr + [0.0] * l}, open(f, 'w'))
            print(f'{time.strftime("%H:%M")} [{k + 1}/{len(pairs)}] {x} v {y}: {wdl}, {elo:+.0f} Elo, {time.time() - t:.0f} s', flush=True)
    games = {}
    for x, y, _ in pairs:
        f = os.path.join(d, f'{x}__{y}.json')
        if os.path.exists(f): games[(x, y)] = json.load(open(f))['scores']
    names = [r for r in rungs if any(r in k for k in games)]
    e, se = fit(games, names)
    lines = ['rung        Elo     se   step', '']
    for i, r in enumerate(names):
        lines.append(f'{r:>7} {e[i]:+7.0f} {se[i]:6.0f} {e[i] - e[i - 1] if i else 0:+6.0f}')
    lines += ['', 'pairs: ' + ', '.join(f'{x} v {y} {sum(s):g}/{len(s)}' for (x, y), s in games.items())]
    out = '\n'.join(lines); print(out); open(os.path.join(a.work, 'runs', 'ladder' + a.tag + '.txt'), 'w').write(out + '\n')


if __name__ == '__main__':
    main()
