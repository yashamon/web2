#!/usr/bin/env python3
"""The fit of the paper's ladder table (see __main__)."""
import json, glob, math, random, sys, os
def load(d):
    G = {}
    for f in glob.glob(os.path.join(d, '*__*.json')):
        j = json.load(open(f)); G[(j['a'], j['b'])] = j['scores']
    return G
def bt(G, names, anchor, prior=0.1):
    n = len(names); idx = {x: i for i, x in enumerate(names)}; w = [0.0] * n; cnt = {}
    for (a, b), sc in G.items():
        i, j = idx[a], idx[b]; s = sum(sc); w[i] += s + prior / 2; w[j] += len(sc) - s + prior / 2; cnt[(i, j)] = len(sc) + prior
    g = [1.0] * n
    for _ in range(4000):
        new = []
        for i in range(n):
            den = sum(c / (g[i] + g[b if a == i else a]) for (a, b), c in cnt.items() if i in (a, b)); new.append(w[i] / den)
        m = sum(math.log(x) for x in new) / n; new = [x / math.exp(m) for x in new]
        if max(abs(math.log(new[i] / g[i])) for i in range(n)) < 1e-11: g = new; break
        g = new
    e = [400 * math.log10(x) for x in g]; a0 = e[idx[anchor]]; return [x - a0 for x in e]

ORDER = ['mc0','mc26','mc205','mc3277','g0','g1','g2','old35','g3','g4','g6','g8','g12','g16','g20','g24','g32','g40','g48','g56','g64','g72']
def fit(d, top=56, boots=400, seed=3):
    G = {k: v for k, v in load(d).items() if all(not x.startswith('g') or int(x[1:]) <= top for x in k)}
    names = [x for x in ORDER if any(x in k for k in G)]
    base = dict(zip(names, bt(G, names, 'mc26'))); random.seed(seed); B = []
    for _ in range(boots): B.append(dict(zip(names, bt({k: [random.choice(v) for _ in v] for k, v in G.items()}, names, 'mc26'))))
    sd = lambda xs: (sum((x - sum(xs) / len(xs)) ** 2 for x in xs) / (len(xs) - 1)) ** .5
    return base, {x: sd([b[x] for b in B]) for x in names}, sd([b[f'g{top}'] - b['mc3277'] for b in B]), G
if __name__ == '__main__':
    """fit_paper.py <SGo ladder dir> <Go ladder dir>: the ladder table of Section 2.1 (Bradley-Terry, mc26 = 0, the
    ladders cut at generation 56, errors by 400 bootstrap resamplings of the games) and the climb from mc3277."""
    R = {}
    for tag, d in zip(('SGo', 'Go'), sys.argv[1:3]):
        base, se, cse, G = fit(d); R[tag] = (base, se, cse)
        print(f'{tag}: {sum(len(v) for v in G.values())} games, {sum(1 for v in G.values() for s in v if s == 0.5)} draws')
    names = [x for x in ORDER if any(x in R[t][0] for t in R)]
    for x in names: print(f'{x:>7} ' + '  '.join(f'{R[t][0][x]:+6.0f} +-{R[t][1][x]:4.0f}' if x in R[t][0] else ' ' * 13 for t in R))
    c = {t: R[t][0]['g56'] - R[t][0]['mc3277'] for t in R}
    for t in R: print(f'{t}: g56 - mc3277 = {c[t]:+.0f} +- {R[t][2]:.0f}')
    print(f"difference {c['SGo'] - c['Go']:+.0f} +- {(R['SGo'][2] ** 2 + R['Go'][2] ** 2) ** .5:.0f}")
