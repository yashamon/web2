"""The net: a residual tower with global pooling (KataGo, Wu 2019), fully convolutional, so the same code serves any
board side (and later Go).  Outputs: two policy heads (Black's and White's move; in SGo both move every turn, in Go
only the mover's head would be read), the value (Black's expected result, tanh) and the final ownership of every point
(an auxiliary target that speeds up learning, as in KataGo)."""
import torch
import torch.nn as nn
import torch.nn.functional as F


def gpool(x):
    """KataGo's global pooling: mean, mean scaled by board width, max."""
    n = x.shape[-1]; m = x.mean((2, 3))
    return torch.cat([m, m * (n - 14) / 10.0, x.amax((2, 3))], 1)


class Block(nn.Module):
    def __init__(self, ch, gch=0):
        super().__init__()
        self.c1 = nn.Conv2d(ch, ch, 3, padding=1, bias=False); self.b1 = nn.BatchNorm2d(ch)
        self.c2 = nn.Conv2d(ch, ch, 3, padding=1, bias=False); self.b2 = nn.BatchNorm2d(ch)
        nn.init.zeros_(self.b2.weight)  # each block starts as the identity
        self.gch = gch
        if gch:  # a global-pooling block: pooled features of a side branch bias the first convolution's channels
            self.cg = nn.Conv2d(ch, gch, 3, padding=1, bias=False); self.bg = nn.BatchNorm2d(gch); self.fg = nn.Linear(3 * gch, ch)

    def forward(self, x):
        h = F.relu(self.b1(self.c1(x)))
        if self.gch:
            h = h + self.fg(gpool(F.relu(self.bg(self.cg(x)))))[:, :, None, None]
        return F.relu(x + self.b2(self.c2(h)))


class Net(nn.Module):
    def __init__(self, cin, ch=128, blocks=10, gpool_every=3, gch=32, hc=32, vh=128, **_):
        super().__init__()
        self.cfg = dict(cin=cin, ch=ch, blocks=blocks, gpool_every=gpool_every, gch=gch, hc=hc, vh=vh)
        self.stem = nn.Sequential(nn.Conv2d(cin, ch, 3, padding=1, bias=False), nn.BatchNorm2d(ch), nn.ReLU())
        self.tower = nn.Sequential(*[Block(ch, gch if gpool_every and (i + 1) % gpool_every == 0 else 0) for i in range(blocks)])
        self.p1 = nn.Conv2d(ch, hc, 1, bias=False); self.pb = nn.BatchNorm2d(hc); self.pg = nn.Linear(3 * hc, hc)
        self.p2 = nn.Conv2d(hc, 2, 1); self.ppass = nn.Linear(3 * hc, 2)
        self.v1 = nn.Conv2d(ch, hc, 1, bias=False); self.vb = nn.BatchNorm2d(hc)
        self.vf1 = nn.Linear(3 * hc, vh); self.vf2 = nn.Linear(vh, 1); self.own = nn.Conv2d(hc, 1, 1)

    def forward(self, x):
        """x [k, cin, n, n] -> logits [k, 2, n*n + 1] (Black, White; the last entry is the pass), value [k], ownership [k, n, n]"""
        h = self.tower(self.stem(x))
        p = F.relu(self.pb(self.p1(h))); g = gpool(p)
        pt = self.p2(F.relu(p + self.pg(g)[:, :, None, None]))  # [k, 2, n, n]
        logits = torch.cat([pt.flatten(2), self.ppass(g)[:, :, None]], 2)
        v = F.relu(self.vb(self.v1(h)))
        value = torch.tanh(self.vf2(F.relu(self.vf1(gpool(v))))).squeeze(1)
        own = torch.tanh(self.own(v)).squeeze(1)
        return logits, value, own


def save(model, path, extra=None):
    torch.save({'cfg': model.cfg, 'state': model.state_dict(), 'extra': extra or {}}, path + '.tmp')
    import os; os.replace(path + '.tmp', path)


def load(path, device='cpu'):
    d = torch.load(path, map_location=device, weights_only=False)
    m = Net(**d['cfg']); m.load_state_dict(d['state']); return m.to(device)


# ---------- the eight symmetries of the square ----------
def sym(t, s):
    if s & 4: t = t.transpose(-1, -2)
    if s & 1: t = t.flip(-1)
    if s & 2: t = t.flip(-2)
    return t


def unsym(t, s):
    if s & 2: t = t.flip(-2)
    if s & 1: t = t.flip(-1)
    if s & 4: t = t.transpose(-1, -2)
    return t


class Evaluator:
    """Callable for sgoz.lib.run_pool: a batch of features -> (logits, values), on the GPU, under a random symmetry."""
    def __init__(self, model, device, old=False, seed=0, half=True):
        self.m = model.to(device).eval(); self.dev = device; self.old = old
        self.g = torch.Generator().manual_seed(seed); self.half = half and device.startswith('cuda')

    @torch.no_grad()
    def __call__(self, x):
        k, C, n, _ = x.shape
        s = int(torch.randint(8, (1,), generator=self.g))
        t = sym(torch.from_numpy(x).to(self.dev, non_blocking=True), s)
        with torch.autocast('cuda', dtype=torch.float16, enabled=self.half):
            out = self.m(t)
        logits, v = out[0].float(), out[1].float()
        pts = unsym(logits[:, :, :n * n].reshape(k, 2, n, n), s).reshape(k, 2, n * n)
        logits = torch.cat([pts, logits[:, :, n * n:]], 2)
        return logits.cpu().numpy(), v.cpu().numpy()
