"""The C++ engine (csrc/sgoz.cpp, which includes the paper's engine sgo.cpp) through ctypes.  Built on first use."""
import ctypes, os, subprocess
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
CSRC = os.path.join(os.path.dirname(HERE), 'csrc')
BUILD = os.environ.get('SGOZ_BUILD', os.path.join(os.path.expanduser('~'), '.sgoz_build'))


def _build():
    os.makedirs(BUILD, exist_ok=True)
    so = os.path.join(BUILD, 'libsgoz.so')
    srcs = [os.path.join(CSRC, f) for f in ('sgoz.cpp', 'sgo.cpp')]
    if not os.path.exists(so) or any(os.path.getmtime(s) > os.path.getmtime(so) for s in srcs):
        cmd = ['g++', '-O3', '-march=native', '-std=c++17', '-fopenmp', '-shared', '-fPIC', '-o', so + '.tmp', srcs[0]]
        r = subprocess.run(cmd, capture_output=True, text=True)
        if r.returncode != 0:
            raise RuntimeError('building the engine failed:\n' + r.stderr[-3000:])
        os.replace(so + '.tmp', so)
    return so


_L = None
F = ctypes.c_float; I = ctypes.c_int; P = ctypes.c_void_p; U64 = ctypes.c_uint64
fptr = np.ctypeslib.ndpointer(np.float32, flags='C_CONTIGUOUS')
iptr = np.ctypeslib.ndpointer(np.int32, flags='C_CONTIGUOUS')
u8ptr = np.ctypeslib.ndpointer(np.uint8, flags='C_CONTIGUOUS')


def lib():
    global _L
    if _L is None:
        L = ctypes.CDLL(_build())
        L.sz_config.argtypes = [I, I, I, I, I]
        L.sz_threads.argtypes = [I]
        L.sz_set_game.argtypes = [I, ctypes.c_double]; L.sz_game_fs.restype = I
        L.sz_swap_invert.argtypes = [iptr]; L.sz_swap_invert.restype = I
        L.sz_nplanes.argtypes = [I]; L.sz_nplanes.restype = I
        L.sz_swap_perm.argtypes = [iptr]
        L.sz_selfplay.argtypes = [I, I, U64, I, I, F, F, F, F]; L.sz_selfplay.restype = P
        L.sz_arena.argtypes = [I, I, U64, I, I, I, I, F, I, I, I, I, I, F, I, F, F]; L.sz_arena.restype = P
        L.sz_free.argtypes = [P]
        L.sz_step.argtypes = [P]; L.sz_step.restype = I
        L.sz_pending.argtypes = [P, I]; L.sz_pending.restype = I
        L.sz_pending_fs.argtypes = [P, I]; L.sz_pending_fs.restype = I
        L.sz_pending_features.argtypes = [P, I, fptr]
        L.sz_feed.argtypes = [P, I, fptr, fptr]
        L.sz_finished.argtypes = [P]; L.sz_finished.restype = I
        L.sz_samples.argtypes = [P]; L.sz_samples.restype = I
        L.sz_take_samples.argtypes = [P, u8ptr, fptr, fptr, fptr, fptr, fptr, fptr]
        L.sz_results.argtypes = [P, iptr]; L.sz_results.restype = I
        L.sz_gstats.argtypes = [P, iptr]; L.sz_gstats.restype = I; L.sz_gst_width.restype = I; L.sz_stat_branches.argtypes = [I]; L.sz_open_sample.argtypes = [I]
        _L = L
    return _L


class Rules:
    """Board side and rules.  SGo: rule D of the paper = placement 4 with the orphan route; the playouts keep the eye
    defense.  Go: area scoring with komi, positional superko in the games (simple ko inside searches and playouts); the
    cap counts plies."""
    def __init__(self, n=9, place=4, orphan=1, eyedef=1, cap=None, game='sgo', komi=7.5):
        self.n = n; self.N = n * n; self.NA = n * n + 1; self.game = game
        if game == 'go': self.cap = cap or {9: 300, 13: 500, 19: 800}.get(n, 4 * n * n)
        else: self.cap = cap or {5: 60, 7: 120, 9: 200, 11: 250, 13: 300, 19: 500}.get(n, 2 * n * n)
        lib().sz_config(n, place, orphan, eyedef, self.cap); lib().sz_set_game(1 if game == 'go' else 0, komi)
        lib().sz_threads(int(os.environ.get('SGOZ_THREADS', '0')) or max(1, (os.cpu_count() or 2) - 2))
        self.fs = lib().sz_game_fs(); self.C = lib().sz_nplanes(self.fs)
        perm = np.zeros(self.C, np.int32); lib().sz_swap_perm(perm); self.swap = perm
        inv = np.zeros(self.C, np.int32); k = lib().sz_swap_invert(inv); self.invert = inv[:k].tolist()


def run_pool(pool, evals, rules):
    """Drive a pool to the end.  evals: {net id: f(features [k, C, n, n] float32) -> (logits [k, 2, NA], values [k])}."""
    L = lib(); n = rules.n
    while L.sz_step(pool) > 0:
        fed = False
        for net, f in evals.items():
            k = L.sz_pending(pool, net)
            if not k:
                continue
            C = L.sz_nplanes(L.sz_pending_fs(pool, net))
            x = np.empty((k, C, n, n), np.float32); L.sz_pending_features(pool, net, x)
            logits, values = f(x)
            L.sz_feed(pool, net, np.ascontiguousarray(logits, np.float32), np.ascontiguousarray(values, np.float32)); fed = True
        if not fed:
            raise RuntimeError('games wait for a net that has no evaluator')


def take_samples(pool, rules):
    L = lib(); k = L.sz_samples(pool); N, NA, C = rules.N, rules.NA, rules.C
    out = dict(x=np.empty((k, C, rules.n, rules.n), np.uint8), tf=np.empty(k, np.float32), pB=np.empty((k, NA), np.float32),
               pW=np.empty((k, NA), np.float32), z=np.empty(k, np.float32), margin=np.empty(k, np.float32), own=np.empty((k, rules.n, rules.n), np.float32))
    if k:
        L.sz_take_samples(pool, out['x'], out['tf'], out['pB'], out['pW'], out['z'], out['margin'], out['own'])
    return out


def results(pool, games):
    r = np.zeros(4 * games, np.int32); k = lib().sz_results(pool, r)
    return r[:4 * k].reshape(k, 4)  # game, Black's margin, A black, turns


def gstats(pool, games):
    """Every finished game: game, Black's margin (Go: twice it, komi included), A black (-1 in self play), turns,
    q-stones created, q-stones on the final display, peak recursion depth (stages of the objective reduction that
    removed a stone), peak number of removing basic capture reductions within one stage, peak and final number of
    branches (-1 unless lib().sz_stat_branches(1) was set before the pool started; the last six SGo only)."""
    w = lib().sz_gst_width(); r = np.zeros(w * games, np.int32); k = lib().sz_gstats(pool, r)
    return r[:w * k].reshape(k, w)
