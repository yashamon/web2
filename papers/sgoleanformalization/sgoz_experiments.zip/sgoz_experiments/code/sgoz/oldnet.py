"""The nets of sgonet.cpp (g1 ... g35, file format SGN2): 8 input planes, conv3x3 to 32, 4 residual blocks, policy head
(1x1 conv to 2, ReLU, two fully connected maps 162 -> 82), value head (1x1 conv to 1, ReLU, 81 -> 64 ReLU -> 1, tanh).
9x9 only.  A numpy forward (tests, no torch needed) and a torch module (the old nets as opponents on the GPU)."""
import struct
import numpy as np

NP, CF, NBLK, NN, NA, PH, VH = 8, 32, 4, 81, 82, 2, 64
SIZES = [('cin_w', (CF, NP, 3, 3)), ('cin_b', (CF,))]
for k in range(NBLK):
    SIZES += [(f'b1w{k}', (CF, CF, 3, 3)), (f'b1b{k}', (CF,)), (f'b2w{k}', (CF, CF, 3, 3)), (f'b2b{k}', (CF,))]
SIZES += [('pc_w', (PH, CF)), ('pc_b', (PH,)), ('pfB_w', (NA, PH * NN)), ('pfB_b', (NA,)), ('pfW_w', (NA, PH * NN)), ('pfW_b', (NA,)),
          ('vc_w', (1, CF)), ('vc_b', (1,)), ('vf1_w', (VH, NN)), ('vf1_b', (VH,)), ('vf2_w', (1, VH)), ('vf2_b', (1,))]


def load_sgn2(path):
    b = open(path, 'rb').read()
    assert b[:4] == b'SGN2' and struct.unpack('<5i', b[4:24]) == (NP, CF, NBLK, NN, NA), 'not an SGN2 9x9 net'
    off, W = 28, {}
    for name, shape in SIZES:
        n = int(np.prod(shape)); W[name] = np.frombuffer(b, '<f4', n, off).reshape(shape).copy(); off += 12 * n  # w, then Adam's m and v
    assert off == len(b)
    return W


def _conv3(x, w, b):  # x [k, cin, 9, 9], w [cout, cin, 3, 3], zero padding
    k, cin, n, _ = x.shape; xp = np.zeros((k, cin, n + 2, n + 2), np.float32); xp[:, :, 1:-1, 1:-1] = x
    out = np.broadcast_to(b[None, :, None, None], (k, w.shape[0], n, n)).copy()
    for dy in range(3):
        for dx in range(3):
            out += np.einsum('oc,kcyx->koyx', w[:, :, dy, dx], xp[:, :, dy:dy + n, dx:dx + n], optimize=True)
    return out


def forward_np(W, x):
    """x [k, 8, 9, 9] -> logits [k, 2, 82] (Black, White), values [k]"""
    relu = lambda a: np.maximum(a, 0)
    h = relu(_conv3(x, W['cin_w'], W['cin_b']))
    for k in range(NBLK):
        a = relu(_conv3(h, W[f'b1w{k}'], W[f'b1b{k}'])); h = relu(_conv3(a, W[f'b2w{k}'], W[f'b2b{k}']) + h)
    kk = x.shape[0]; hf = h.reshape(kk, CF, NN)
    ph = relu(np.einsum('jc,kcp->kjp', W['pc_w'], hf) + W['pc_b'][None, :, None]).reshape(kk, PH * NN)
    lB = ph @ W['pfB_w'].T + W['pfB_b']; lW = ph @ W['pfW_w'].T + W['pfW_b']
    vh = relu(np.einsum('c,kcp->kp', W['vc_w'][0], hf) + W['vc_b'][0])
    v1 = relu(vh @ W['vf1_w'].T + W['vf1_b']); v = np.tanh(v1 @ W['vf2_w'][0] + W['vf2_b'][0])
    return np.stack([lB, lW], 1), v


def torch_module(path):
    import torch, torch.nn as nn, torch.nn.functional as Fn
    W = {k: torch.tensor(v) for k, v in load_sgn2(path).items()}

    class OldNet(nn.Module):
        def __init__(self):
            super().__init__()
            self.p = nn.ParameterDict({k: nn.Parameter(v, requires_grad=False) for k, v in W.items()})
        def forward(self, x):
            p = self.p; h = Fn.relu(Fn.conv2d(x, p['cin_w'], p['cin_b'], padding=1))
            for k in range(NBLK):
                a = Fn.relu(Fn.conv2d(h, p[f'b1w{k}'], p[f'b1b{k}'], padding=1))
                h = Fn.relu(Fn.conv2d(a, p[f'b2w{k}'], p[f'b2b{k}'], padding=1) + h)
            kk = x.shape[0]; hf = h.reshape(kk, CF, NN)
            ph = Fn.relu(torch.einsum('jc,kcp->kjp', p['pc_w'], hf) + p['pc_b'][None, :, None]).reshape(kk, PH * NN)
            lB = ph @ p['pfB_w'].T + p['pfB_b']; lW = ph @ p['pfW_w'].T + p['pfW_b']
            vh = Fn.relu(torch.einsum('c,kcp->kp', p['vc_w'][0], hf) + p['vc_b'][0])
            v1 = Fn.relu(vh @ p['vf1_w'].T + p['vf1_b']); v = torch.tanh(v1 @ p['vf2_w'][0] + p['vf2_b'][0])
            return torch.stack([lB, lW], 1), v
    return OldNet()
