"""Training on the replay window: random symmetry and color swap per sample; loss = both policy heads (cross-entropy
against the search's visit distributions) + value (squared error against the result) + ownership (squared error)."""
import glob, math, os
import numpy as np
import torch
import torch.nn.functional as F
from .model import sym


def window_size(total, c=60000, alpha=0.75, beta=0.4):
    """KataGo's growing window (c, alpha, beta scaled down for 9x9): all data while young, then a slowly growing tail."""
    if total <= c:
        return total
    return int(c * (1 + beta * ((total / c) ** alpha - 1) / alpha))


def load_window(data_dir, upto_gen):
    files = []
    for g in range(upto_gen, -1, -1):
        files += sorted(glob.glob(os.path.join(data_dir, f'g{g}_*.npz')))
    total = sum(int(np.load(f)['z'].shape[0]) for f in files)
    want, parts, have = window_size(total), [], 0
    for f in files:  # newest first
        if have >= want:
            break
        d = dict(np.load(f)); parts.append(d); have += len(d['z'])
    D = {k: np.concatenate([p[k] for p in parts]) for k in parts[0]}
    return D, total


def train(model, D, swap_perm, steps, device, invert=(), lr=0.02, batch=256, wd=1e-4, warmup=0, log=None, seed=0):
    model.train(); rng = np.random.default_rng(seed)
    opt = torch.optim.SGD(model.parameters(), lr=lr, momentum=0.9, nesterov=True, weight_decay=wd)
    n = D['x'].shape[-1]; Ntot = len(D['z']); perm = torch.as_tensor(swap_perm, dtype=torch.long, device=device)
    acc = np.zeros(4); cnt = 0
    for step in range(steps):
        for gr in opt.param_groups:
            gr['lr'] = lr * min(1.0, (step + 1) / warmup) if warmup else lr
        idx = rng.integers(0, Ntot, batch)
        x = torch.from_numpy(D['x'][idx]).to(device).float()
        x[:, -1] = torch.from_numpy(D['tf'][idx]).to(device)[:, None, None]  # the turn plane is the last one
        pB = torch.from_numpy(D['pB'][idx].astype(np.float32)).to(device); pW = torch.from_numpy(D['pW'][idx].astype(np.float32)).to(device)
        z = torch.from_numpy(D['z'][idx]).to(device); own = torch.from_numpy(D['own'][idx].astype(np.float32)).to(device)
        # color swap for half the batch: the game is symmetric under exchanging the colors (and the two moves)
        sw = torch.from_numpy(rng.random(batch) < 0.5).to(device)
        xs = x[:, perm]
        for c in invert: xs[:, c] = 1 - xs[:, c]  # Go: the side to move flips
        x = torch.where(sw[:, None, None, None], xs, x)
        pB, pW = torch.where(sw[:, None], pW, pB), torch.where(sw[:, None], pB, pW)
        z = torch.where(sw, -z, z); own = torch.where(sw[:, None, None], -own, own)
        # one symmetry of the square for the batch
        s = int(rng.integers(8)); x = sym(x, s); own = sym(own, s)
        def symp(p):
            pts = sym(p[:, :n * n].reshape(-1, n, n), s).reshape(-1, n * n); return torch.cat([pts, p[:, n * n:]], 1)
        pB, pW = symp(pB), symp(pW)
        with torch.autocast('cuda', dtype=torch.bfloat16, enabled=device.startswith('cuda')):
            logits, v, o = model(x)
        logits, v, o = logits.float(), v.float(), o.float()
        lp = -(pB * F.log_softmax(logits[:, 0], 1)).sum(1).mean() - (pW * F.log_softmax(logits[:, 1], 1)).sum(1).mean()
        lv = ((v - z) ** 2).mean(); lo = ((o - own) ** 2).mean()
        loss = lp + 1.5 * lv + 1.5 * lo
        opt.zero_grad(set_to_none=True); loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0); opt.step()
        acc += [loss.item(), lp.item(), lv.item(), lo.item()]; cnt += 1
        if log and ((step + 1) % 200 == 0 or step + 1 == steps):
            a = acc / cnt; log(f'  step {step + 1}/{steps}  loss {a[0]:.4f}  policy {a[1]:.4f}  value {a[2]:.4f}  ownership {a[3]:.4f}'); acc[:] = 0; cnt = 0
    model.eval()
    return model
