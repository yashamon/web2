#!/usr/bin/env python3
"""SGo self-play training on the GPU (rule D, 9x9 by default).  Resumable: run it again and it continues.

  python run.py                 the loop: self-play -> train -> evaluate, one generation after another, until Ctrl-C
  python run.py --gens 5        stop after five more generations
  python run.py --check         the self-test only (engine, the old nets' port, the GPU)

Everything lands in the work folder (default: this folder): models/g<k>.pt, runs/log.txt (one line per step),
runs/eval.txt (the matches), data/ (the self-play samples; --data puts them elsewhere, e.g. off OneDrive).
config.json holds the settings; edit it between runs."""
import argparse, json, math, os, sys, time, glob
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
DEFAULT = dict(
    game='sgo', komi=7.5,                             # 'sgo' (rule D below) or 'go' (area scoring, komi, positional superko)
    n=9, place=4, orphan=1, eyedef=1,                 # rule D of the paper on 9x9
    blocks=10, ch=128, gpool_every=3, gch=32, hc=32, vh=128,
    slots=512,                                        # games played at once (the GPU batch); CPU threads: SGOZ_THREADS or all but two
    games_per_gen=1200, sims_full=600, sims_fast=100, p_full=0.25,  # KataGo's playout cap randomization
    cpuct=1.5, fpu=0.2, mix_start=0.5, mix_gens=20,   # leaf value = (1-mix) net + mix random playout; mix falls to 0 over mix_gens
    batch=256, lr=0.02, wd=1e-4, train_ratio=8, warmup=500,
    eval_games=64, eval_sims=100, old_net='nets/g35.bin', old_every=2, mc_every=4,
    anchor_back=8, anchor_every=4)               # every 4th generation also g<k> v g<k-8>: progress on a fixed stride (0 = off)


def rules(cfg):
    from sgoz import lib as L
    return L.Rules(cfg['n'], cfg['place'], cfg['orphan'], cfg['eyedef'], game=cfg.get('game', 'sgo'), komi=cfg.get('komi', 7.5))


def log(cfg, msg):
    line = time.strftime('%m-%d %H:%M ') + msg; print(line, flush=True)
    with open(os.path.join(cfg['work'], 'runs', 'log.txt'), 'a') as f: f.write(line + '\n')


def mix_of(cfg, g):
    return max(0.0, cfg['mix_start'] * (1 - g / cfg['mix_gens'])) if cfg['mix_gens'] else cfg['mix_start']


# ---------- self-play and matches (one process: the engine runs the games on CPU threads, the GPU takes the batches) ----------
def selfplay(cfg, R, model, gen, dev):
    from sgoz import lib as L
    from sgoz.model import Evaluator
    ev = Evaluator(model, dev, seed=gen); seed = 100003 * gen + 1
    pool = L.lib().sz_selfplay(cfg['games_per_gen'], cfg['slots'], seed, cfg['sims_full'], cfg['sims_fast'], cfg['p_full'], cfg['cpuct'], cfg['fpu'], mix_of(cfg, gen))
    L.run_pool(pool, {0: ev}, R); s = L.take_samples(pool, R); L.lib().sz_free(pool)
    out = os.path.join(cfg['data'], f'g{gen}_0.npz')
    np.savez(out + '.tmp.npz', x=s['x'], tf=s['tf'], pB=s['pB'].astype(np.float16), pW=s['pW'].astype(np.float16), z=s['z'],
             margin=s['margin'], own=s['own'].astype(np.int8))
    os.replace(out + '.tmp.npz', out)
    return s


def player(cfg, spec, netid):
    """spec: 'mc<budget>' | path of a .pt net | path of an SGN2 .bin net (the old nets, feature set 0) -> (kind, net, fs, sims, mix, budget)"""
    if spec.startswith('mc'):
        return (1, netid, 0, 0, 0.0, int(spec[2:]))
    if spec.endswith('.bin'):
        return (0, netid, 0, cfg['eval_sims'], 0.5, 0)  # the old nets search with the half-playout leaf they were rated with
    g = int(os.path.basename(spec)[1:-3])
    return (0, netid, 2 if cfg.get('game') == 'go' else 1, cfg['eval_sims'], mix_of(cfg, g), 0)


def arena(cfg, R, specA, specB, games, seed, dev):
    """A plays Black in the even games.  Returns (score of A, games, Elo of A over B, 'W-D-L')."""
    from sgoz import lib as L
    from sgoz.model import load, Evaluator
    from sgoz.oldnet import torch_module
    pA, pB = player(cfg, specA, 0), player(cfg, specB, 1); evs = {}
    for p, spec in ((pA, specA), (pB, specB)):
        if p[0] == 0:
            evs[p[1]] = Evaluator(torch_module(spec) if spec.endswith('.bin') else load(spec, dev), dev, old=spec.endswith('.bin'), seed=seed + p[1])
    pool = L.lib().sz_arena(games, games, seed, *pA, *pB, cfg['cpuct'], cfg['fpu'])
    L.run_pool(pool, evs, R); res = L.results(pool, games).tolist(); L.lib().sz_free(pool)
    sc = sum(0.5 if m == 0 else float((m > 0) == (ab == 1)) for _, m, ab, _ in res); n = len(res)
    p = min(max(sc / n, 0.5 / n), 1 - 0.5 / n); elo = 400 * math.log10(p / (1 - p))
    w = sum(1 for _, m, ab, _ in res if m and (m > 0) == (ab == 1)); d = sum(1 for _, m, _, _ in res if m == 0)
    return sc, n, elo, f'{w}-{d}-{n - w - d}'


# ---------- the check ----------
def check(cfg):
    from sgoz import lib as L
    from sgoz.oldnet import load_sgn2, forward_np, torch_module
    import torch
    R = rules(cfg); print('engine: ok,', R.C, 'feature planes')
    import torch
    if cfg.get('game') == 'go':
        from sgoz.model import Net, Evaluator
        dev = 'cuda' if torch.cuda.is_available() else 'cpu'; net = Net(R.C, cfg['ch'], cfg['blocks'], cfg['gpool_every'], cfg['gch'], cfg['hc'], cfg['vh']).to(dev)
        ev = Evaluator(net, dev); lg, v = ev(np.random.rand(64, R.C, R.n, R.n).astype(np.float32)); print('Go: new net runs,', lg.shape, v.shape, 'device', dev); return
    ref = [json.loads(l) for l in open(os.path.join(HERE, 'tests', 'g35_ref.jsonl'))]
    x = np.array([r['x'] for r in ref], np.float32).reshape(-1, 8, 9, 9)
    want = np.stack([np.array([r['pB'] for r in ref]), np.array([r['pW'] for r in ref])], 1); wv = np.array([r['v'] for r in ref])
    old = os.path.join(HERE, 'nets', 'g35.bin')
    lg, v = forward_np(load_sgn2(old), x); print(f'old net, numpy: max |dlogit| {np.abs(lg - want).max():.1e}, |dv| {np.abs(v - wv).max():.1e} (want < 1e-3)')
    dev = 'cuda' if torch.cuda.is_available() else 'cpu'; print('torch', torch.__version__, 'device', dev, torch.cuda.get_device_name(0) if dev == 'cuda' else '')
    m = torch_module(old).to(dev)
    with torch.no_grad():
        lt, vt = m(torch.from_numpy(x).to(dev))
    print(f'old net, torch: max |dlogit| {np.abs(lt.cpu().numpy() - want).max():.1e}, |dv| {np.abs(vt.cpu().numpy() - wv).max():.1e} (want < 1e-3)')
    from sgoz.model import Net, Evaluator
    net = Net(R.C, cfg['ch'], cfg['blocks'], cfg['gpool_every'], cfg['gch'], cfg['hc'], cfg['vh']).to(dev)
    print('new net:', sum(p.numel() for p in net.parameters()), 'weights')
    ev = Evaluator(net, dev); xb = np.random.rand(512, R.C, R.n, R.n).astype(np.float32); ev(xb)
    if dev == 'cuda': torch.cuda.synchronize()
    t = time.time()
    for _ in range(20): ev(xb)
    if dev == 'cuda': torch.cuda.synchronize()
    print(f'new net: {20 * 512 / (time.time() - t):.0f} positions a second (batches of 512)')


# ---------- the loop ----------
def main():
    ap = argparse.ArgumentParser(); ap.add_argument('--work', default=HERE); ap.add_argument('--data', default=None)
    ap.add_argument('--gens', type=int, default=0); ap.add_argument('--check', action='store_true')
    ap.add_argument('--arena', nargs=2, metavar=('A', 'B'), help='one match: two of models/g<k>.pt, nets/g35.bin, mc<budget>')
    ap.add_argument('--games', type=int, default=0)
    ap.add_argument('--game', choices=['sgo', 'go'], help='for a new work folder: which game (written to its config.json)'); a = ap.parse_args()
    cfg = dict(DEFAULT); cp = os.path.join(a.work, 'config.json')
    if os.path.exists(cp): cfg.update(json.load(open(cp)))
    else:
        os.makedirs(a.work, exist_ok=True)
        if a.game == 'go': cfg.update(game='go', old_every=0, mc_every=0)
        json.dump(cfg, open(cp, 'w'), indent=1)
    cfg['work'] = a.work; cfg['data'] = a.data or os.path.join(a.work, 'data')
    for d in ('models', 'runs'): os.makedirs(os.path.join(a.work, d), exist_ok=True)
    os.makedirs(cfg['data'], exist_ok=True)
    if not os.path.isabs(cfg['old_net']): cfg['old_net'] = os.path.join(HERE, cfg['old_net'])
    if a.check:
        check(cfg); return
    if a.arena:
        import torch
        from sgoz import lib as L
        R = rules(cfg); dev = 'cuda' if torch.cuda.is_available() else 'cpu'
        spec = lambda x: x if x.startswith('mc') or os.path.isabs(x) else os.path.join(a.work, x)
        t = time.time(); sc, n, elo, wdl = arena(cfg, R, spec(a.arena[0]), spec(a.arena[1]), a.games or 128, 77000 + (a.games or 128), dev)
        line = f'{a.arena[0]} v {a.arena[1]}: {wdl} ({sc:g}/{n}), {elo:+.0f} Elo, {time.time() - t:.0f} s'
        print(line)
        with open(os.path.join(a.work, 'runs', 'matches.txt'), 'a') as f: f.write(time.strftime('%m-%d %H:%M ') + line + '\n')
        return
    import torch
    from sgoz import lib as L
    from sgoz.model import Net, save, load
    from sgoz.train import load_window, train
    R = rules(cfg); dev = 'cuda' if torch.cuda.is_available() else 'cpu'
    if dev == 'cpu': log(cfg, 'warning: no GPU visible to torch; running on the CPU (slow)')
    md = os.path.join(a.work, 'models')
    gens = sorted(int(os.path.basename(f)[1:-3]) for f in glob.glob(os.path.join(md, 'g*.pt')))
    if not gens:
        torch.manual_seed(1); save(Net(R.C, **{k: cfg[k] for k in ('ch', 'blocks', 'gpool_every', 'gch', 'hc', 'vh')}), os.path.join(md, 'g0.pt'))
        gens = [0]; log(cfg, f'g0: a new net, {cfg["blocks"]} blocks of {cfg["ch"]} channels')
    g = gens[-1]; done = 0
    while not a.gens or done < a.gens:
        # 1. self-play with g
        if not os.path.exists(os.path.join(cfg['data'], f'g{g}.done')):
            t = time.time(); log(cfg, f'g{g}: self-play, {cfg["games_per_gen"]} games, {cfg["slots"]} at a time, mix {mix_of(cfg, g):.2f}')
            s = selfplay(cfg, R, load(os.path.join(md, f'g{g}.pt'), dev), g, dev)
            open(os.path.join(cfg['data'], f'g{g}.done'), 'w').close()
            mg = s['margin']
            log(cfg, f'g{g}: self-play done, {len(mg)} samples, {time.time() - t:.0f} s; per sample: Black wins {np.mean(mg > 0):.2f}, mean |margin| {np.mean(np.abs(mg)):.1f}')
        # 2. train g -> g+1
        nxt = os.path.join(md, f'g{g + 1}.pt')
        if not os.path.exists(nxt):
            t = time.time(); D, total = load_window(cfg['data'], g)
            new = sum(len(np.load(f)['z']) for f in glob.glob(os.path.join(cfg['data'], f'g{g}_*.npz')))
            steps = max(100, cfg['train_ratio'] * new // cfg['batch'])
            log(cfg, f'g{g} -> g{g + 1}: training, window {len(D["z"])} of {total} samples, {steps} steps')
            m = load(os.path.join(md, f'g{g}.pt'), dev)
            train(m, D, R.swap, steps, dev, invert=R.invert, lr=cfg['lr'], batch=cfg['batch'], wd=cfg['wd'], warmup=cfg['warmup'] if g == 0 else 0,
                  log=lambda s: log(cfg, s), seed=g)
            save(m, nxt); del D
            log(cfg, f'g{g + 1}: saved ({time.time() - t:.0f} s)')
        g += 1; done += 1
        # 3. evaluate g against g-1, the old net g35 (every old_every), mc3277 (every mc_every); 100 simulations each
        ev = os.path.join(a.work, 'runs', 'eval.txt')
        todo = [(os.path.join(md, f'g{g - 1}.pt'), f'g{g - 1}')]
        if os.path.exists(cfg['old_net']) and cfg['old_every'] and g % cfg['old_every'] == 0: todo.append((cfg['old_net'], 'old g35'))
        if cfg['mc_every'] and g % cfg['mc_every'] == 0: todo.append(('mc3277', 'mc3277'))
        b = g - cfg['anchor_back']
        if cfg['anchor_every'] and g % cfg['anchor_every'] == 0 and b >= 0: todo.append((os.path.join(md, f'g{b}.pt'), f'g{b}'))
        for spec, name in todo:
            t = time.time(); sc, n, elo, wdl = arena(cfg, R, os.path.join(md, f'g{g}.pt'), spec, cfg['eval_games'], 50000 + g, dev)
            line = f'g{g} v {name}: {wdl} ({sc:g}/{n}), {elo:+.0f} Elo, {time.time() - t:.0f} s'
            log(cfg, line)
            with open(ev, 'a') as f: f.write(time.strftime('%m-%d %H:%M ') + line + '\n')


if __name__ == '__main__':
    main()
