#!/bin/bash
# strong-play statistics for the paper: the generation-48 net of each line against itself, 400 games each (about 10 min
# each), then the two side by side as the paper's table (runs/stats_table.txt)
cd "$(dirname "$0")"
S=/mnt/c/Users/yasha/OneDrive/Documents/SGo/sgoz; G=/mnt/c/Users/yasha/OneDrive/Documents/SGo/sgoz_go
python stats.py --work $S --net g48 --games 400 && \
python stats.py --work $G --net g48 --games 400 && \
python stats.py --table $S/runs/stats_g48_match.json $G/runs/stats_g48_match.json | tee $S/runs/stats_table.txt
