# sgolean — Lean 4 formalization of Theorem 5.2, the one-stage lemma, and the simultaneization lemmas of *The radius spectrum of games, and simultaneous Go via objective quantum reduction*

STATUS: COMPLETE. All results below are fully proved, sorry-free, in Lean
4.15.0 core (no Mathlib, no other dependency), kernel-checked by `lake build`.

- `SgoThm.thm52` — Theorem 5.2: on a board of side at least five, SGo, the
  delayed games k-DSGo (k ≥ 1) and DSGo are simple symmetric simultaneizations
  of Go with faithfulness radii zero, exactly k, and infinity; Go itself is
  symmetric. `SgoThm.spectrum_full` — the corollary: every element of
  ℕ ⊔ {∞} is the radius of a simple symmetric simultaneization of Go.
- `lem_onestage_final` (Step8.lean) — the one-stage lemma (`lem_onestage`), the resolution of
  commuting joint moves: at every board side n ≥ 2 and every turn, for non
  pass joint moves; the pass cases are covered inside the SGo clause of the
  theorem (`SgoStage1.onestage_single`, `SgoSemi.sgo_semiclassical`).
- `SgoGames.lem_symmetric` (SgoSim.lean) — `lem_symmetric`: the universal
  simultaneization Sim(G) of a symmetric sequential game is symmetric
  (def_symmetric, all clauses; `simGame_simOK`: Sim(G) is a combinatorial
  simultaneous game).
- `SgoGames.lem_dynamics_2`, `SgoGames.lem_dynamics_3` (SgoDyn.lean) —
  `lem_dynamics`: a dynamical isomorphism of sequential games transports
  simultaneizations with their faithfulness radii and simplicity (part 2),
  and the radius spectra coincide (part 3); part 1 is `lem_dynamics_1`.

Axiom footprint of every theorem above: `[propext, Classical.choice,
Quot.sound]` — the standard trio. No `sorryAx` (no incomplete proof) and no
`Lean.ofReduceBool` (no `native_decide`, i.e. no trust in the compiler) in
their dependency cones.

Release 1.1. Hosted at
<https://yashamon.github.io/web2/papers/sgoleanformalization/> — the files
below, this [README](README.md), and the archive
[sgoleanformalization-1.1.zip](sgoleanformalization-1.1.zip). (Release 1.0
carried the theorem and the one-stage lemma; 1.1 adds `lem_symmetric` and
`lem_dynamics`, and the position normal form of a final state now resets
its grading, as printed.)

## Verifying this development

Four commands; no dependency beyond Lean itself:

    curl -sSfL https://elan.lean-lang.org/elan-init.sh | sh -s -- -y
    curl -LO https://yashamon.github.io/web2/papers/sgoleanformalization/sgoleanformalization-1.1.zip
    unzip sgoleanformalization-1.1.zip && cd sgoleanformalization
    lake build          # kernel-checks the complete chain (lean-toolchain pins v4.15.0; ~2 min)

Then the axiom certificate:

    lake env lean Audit.lean

Expected output, exactly these seven lines:

    'lem_onestage_final' depends on axioms: [propext, Classical.choice, Quot.sound]
    'SgoThm.thm52' depends on axioms: [propext, Classical.choice, Quot.sound]
    'SgoThm.spectrum_full' depends on axioms: [propext, Classical.choice, Quot.sound]
    'SgoKWit.not_faithful_kp1' depends on axioms: [propext, Classical.choice, Quot.sound]
    'SgoGames.lem_symmetric' depends on axioms: [propext, Classical.choice, Quot.sound]
    'SgoGames.lem_dynamics_2' depends on axioms: [propext, Classical.choice, Quot.sound]
    'SgoGames.lem_dynamics_3' depends on axioms: [propext, Classical.choice, Quot.sound]

Gold-standard extra: replay the build through an external kernel with
lean4checker. The CI workflow (`.github/workflows/ci.yml`, for a git
hosting of the same files) runs the build and greps the seven lines.

## What is checked: where the printed notions live

The default target `Sgolean` (lakefile.toml) builds the whole sorry-free
chain. Correspondence with the print is documented at the top of each file.

Classical Go and the display calculus (Section 2):
- `SgoGo` — classical Go on diagrams: the placed diagram B + m, go_captures,
  go_suicide, go_closure (`goMoveN`).
- `SgoDisplay` — the display calculus: q-stones and time stamps,
  def_trapped, def_captured 1/2/3a/3b, the basic capture reduction,
  its fixpoint (Cap_n), placeJoint (collision → q-stone), the stage
  recursion (OR).

The one-stage lemma (`lem_onestage_final`): `SgoLemma` (statement, goMoveN factored
through named stages), `Infra`..`Infra6` (components, liberties, legality),
`Step0`, `Step1`, `Step3`, `Step4`, `Step5`, `DispInfra`, `Step6`, `Step7`,
`Step8` (assembly).

The games (Sections 4–5):
- `SgoSerial` — the branch step `#`, the serialization map P (`serialP`, the
  four priority cases), `simEv`, and E_SGo (`sgoEv`).
- `SgoDelta` — the postprocessing Δ (`deltaRound`, `recut`, `delta`), E_DSGo
  (`dsgoEv`), the objective reduction `orOp`, verdicts (`verOf`, `execV`),
  and E_k (`kEv`).
- `SgoGames` — the abstract layer: def_sequential in its core presentation
  (core states, the action of the non pass moves, ended-by-play cores;
  states bigraded by turn and pass grading; finals), the evolution, bar and
  `#` (`hashOp`), the position normal form (`sN`), P (`Pmap`), Sim(G)
  (`simDefP`, `simVal`, `simFinal`), def_simultaneous (`SimulGame`,
  `SimOK`), symmetry (`SeqSym`, `SimSym`), def_semiclassical (`CommuteAt`,
  `SemiC`), def_symmetrization conditions 3–4 (`IsSimultaneization`), the
  interfaces, def_faithful (`FaithfulAt`, `WithinD`, `FaithfulWithin`),
  def_simplesymmetrization (`IsSimple`).
- `SgoInst` — Go presented by its core (`goGame`), the four games
  (`sgoGame`, `dsgoGame`, `kGame`), their branch semantics (`rhoSGo`,
  `rhoD`, `rhoK`), and the statements `Thm52_SGo`, `Thm52_DSGo`,
  `Thm52_kDSGo`, `Thm52`, `SpectrumFull`.
- `SgoSim` — Sim(G) as a simultaneous game (`simGame`, on the sets of
  position normal forms `NSet`), `simGame_simOK`, and `lem_symmetric`:
  the swap R̃ (`Rt`), the characterization of P as the pair of its two
  terms' normal forms (`Pmap_eq`), P's insensitivity to the turn grading
  at live states (`Pmap_flip` — the printed "unaffected by the
  normalization"), and P intertwining the swap (`Pmap_Rst`).
- `SgoDyn` — dynamical isomorphisms (`SeqIso`), the renaming of a
  simultaneization (`renameSim`, `renameRho`), the transports of every
  printed condition (`lem_dynamics_2`), the spectrum as a set of realized
  radii (`HasRadius`, `InSpectrum`) and `lem_dynamics_3`;
  `SgoThm.spectrum_full_inSpectrum` restates the spectrum corollary.

The proof of Theorem 5.2:
- SGo: `SgoInv` (the entanglement invariant), `SgoOK` (def_simultaneous),
  `SgoBridge` (P on position normal forms = `serialP`), `SgoNat`
  (naturality), `SgoStage1` (the single-placement one-stage lemma — the
  pass cases), `SgoSemi` (the semi-classical recursion tracks the display),
  `SgoFaith` (faithful within 0), `SgoSimple` (simplicity), `SgoWit` (not
  faithful within 1, side ≥ 3).
- DSGo: `SgoDInv`, `SgoDOK`, `SgoDNat`, `SgoDSemi` (Δ is the resolution at
  semi-classical states), `SgoDFaith` (faithful within every distance).
- k-DSGo: `SgoKInv`, `SgoKNat` (faithful within k, by projection to a DSGo
  history), `SgoKWit` + `SgoKFin` (not faithful within k+1, side ≥ 5: the
  delayed-verdict witness — collision, pocket-suicide padding, final turn).
- Symmetry: `SgoSwap` (the color swap through the whole capture stack; Go
  is symmetric, `GoOK`), `SgoSym` (the four games are symmetric).
- `SgoThm` — the assembly: `thm52_SGo`, `thm52_DSGo`, `thm52_kDSGo`,
  `thm52`, `spectrum_full`.

## Statement audit — what the kernel cannot check for you

That the checked statements SAY what the paper says. Points to compare
against the print:

1. Board side. `thm52` and `spectrum_full` assume `5 ≤ n`, as the printed
   theorem. Per clause: SGo faithful within 0 at n ≥ 2 and not within 1 at
   n ≥ 3; DSGo faithful within every distance at n ≥ 2; k-DSGo faithful
   within k at n ≥ 2 and not within k+1 at n ≥ 5. The 2×2 board is not
   covered (the paper's footnote cites a separate exhaustion).
2. Finality, as printed: a state of any game of the family is final exactly
   after a double pass turn (the `final` flag); Go's finals arise from a
   pass at pass grading 1 (`SgoGames.sE`); no core state of Go is ended by
   play. def_faithful's finality clause is as printed (`FaithfulAt`).
3. The sequential-game layer is the printed core presentation; the
   position normal form `sN` is the printed N exactly (gradings reset, the
   core kept, for live states and finals alike).
4. Radii are stated in explicit form — faithful within d, not faithful
   within d+1 — with no supremum; the spectrum is the existence statement
   over these (`SpectrumFull`).
5. Not carried: the partition of the final states into wins and draws
   (unused by the theorem's clauses), and finiteness of the move alphabet.
   Consequently def_symmetric's clause that R maps W_0 onto W_1 and D onto
   D is carried as the preservation of finality (`SimSym`), and the
   scoring clause of `lem_dynamics`(3) — repartitioning the final states
   does not change the spectrum — has no formal counterpart beyond the
   fact that no formal notion reads a partition (`InSpectrum` is defined on
   the scoring-free `SeqGame`). Symmetry of the four games is `SimSym`,
   with states compared up to equality of the entanglement as a SET
   (`sgoEqv`, `kEqv`), matching the printed set-based definition; for
   Sim(G) the comparison is equality (`lem_symmetric`).
6. Moves are `Option (Bool × Nat)`: the pass, or a colored intersection;
   off-board indices are undefined moves. Availability is read from the
   display, as printed.
7. Branches: a live branch of the entanglement is the position normal form
   of its diagram (time stamps in branch diagrams ride as 0 and are never
   read). That P's outputs land exactly there is a proved bridge
   (`SgoBridge`), not an assumption.
8. Array encoding: displays are `Display n` with `cells.size = n*n` pinned
   by `WFD`; cell i = column * n + row.

## Separate artifacts (larger trusted base: native_decide)

Not in the default target; build or run individually.

- `lake build Exhaust` — `lem_onestage_3x3_exhaustive` (ExhaustBase.lean +
  Exhaust.lean): all 19,683 assignments of the 3×3 board, legality filtered
  in-proof, every commuting non pass ordered pair; ~3 min.
- `lake build Counts` — the 3×3 legal-state census cross-check (12,675).
- Differential tests against the paper's Python engine (`lake env lean
  <file>`): `Tests.lean` (1,844 legal Go transitions), `TestsDAll.lean`
  (display resolution, 1,722 playout turns; `TestsD300.lean` a 300-turn slice), `TestSerial.lean`
  (SGo, 240 games / 2,009 turns), `TestDelta.lean` (DSGo and k-DSGo, 390
  games / 3,262 turns); `TestsD.lean` is an eval sheet.
- `EvalKWit.lean` — an `#eval` replay of the k-DSGo witness (side 5 for
  k = 1..4, and sides 6, 7, 8 for k = 3, 5, 8): the violation at A3 each
  time; a sanity check of the construction that `SgoKFin` proves.

`tools/` holds the Python generators of the test sheets and the witness
search; they need the paper's engine (`sgo_engine.py`, not included).
`attic/` holds inactive scratch, unrun variants and superseded checkpoints;
nothing there is built.

## Notes on core Lean (for readers of the proofs)

Core Lean 4.15 lacks Mathlib's `by_contra`, `split_ifs`, `Subperm` and
`LawfulBEq (Array _)`: components are handled by a filter-complement measure,
array equality through `Array.isEqv` bridges, and case analysis by
`by_cases` with `if_pos`/`if_neg`. Symbolic board sides make the component
search (fuel n*n) irreducible under `whnf`, so the witness files are written
entirely with rewriting lemmas rather than evaluation.
