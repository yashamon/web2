#!/bin/bash
# Go with POSITIONAL SUPERKO (SGO_SUPERKO=1), rungs to 1638v3277 regardless of saturation (pass STOP=-9999); ladder11.sh with two processes per rung (SGO_STRIDE), otherwise identical: adaptive samples until the 68% band
# half-width is <= BAND Elo (min MIN, max MAX games), stop after a rung with gap <= STOP.
# usage: ladder11p.sh <sgo|go> <cap> <pdepth> [BAND=40] [STOP=40] [MIN=100] [MAX=600]; honors SGO_N (default 11), SGO_PLACE
game=$1; cap=$2; pd=$3; band=${4:-40}; stop=${5:-40}; min=${6:-100}; max=${7:-600}; n=${SGO_N:-11}; export SGO_N=$n
tag="_n${n}${SGO_SIMP:+_simp}${SGO_PLACE:+_p$SGO_PLACE}_sk_tot"; export SGO_SUPERKO=1; out=runs/${game}_ko1${tag}.txt; touch $out
budgets="0 3 26 205 410 819 1638 3277"
prev=""; seed=700; idx=0
for b in $budgets; do
  if [ -n "$prev" ]; then
    seed=$((seed+1)); glog=runs/${game}_ko1${tag}_${prev}v${b}.games; elog=runs/${game}_ko1${tag}_${prev}v${b}.log
    line=$(grep "A=$prev B=$b " $out | tail -1)
    if [ -z "$line" ]; then
      g=$min
      while :; do
        res=runs/tmp_${game}${tag}
        SGO_LOG=$glog SGO_STRIDE=0/2 ./sgo match $game 1 $prev $b $g $seed 0 $cap $pd 2>>$elog > $res.0 &
        SGO_LOG=$glog SGO_STRIDE=1/2 ./sgo match $game 1 $prev $b $g $seed 0 $cap $pd 2>>$elog > $res.1 &
        wait
        read cnt sB gap half < <(python3 band.py $glog $g)
        echo "rung $prev v $b: $cnt games, B score $sB, gap $gap, band ±$half" >> $elog
        if [ "$half" -le "$band" ] || [ "$g" -ge "$max" ]; then break; fi
        g=$(python3 -c "import math; print(min($max, max($g+50, int(math.ceil($g*($half/$band)**2/50.0))*50)))")
      done
      cat $res.0 $res.1 | grep RESULT | tail -1 >> $out
      line=$(grep "A=$prev B=$b " $out | tail -1)
    fi
    gapA=$(echo "$line" | sed -n 's/.*eloA-B=\([-+0-9]*\).*/\1/p')
    if [ -n "$gapA" ] && [ "$gapA" -ge "-$stop" ]; then echo "SATURATED at $prev v $b (gap $gapA)" >> $out; break; fi
  fi
  prev=$b
done
echo DONE >> $out
