#!/bin/bash
# refine a tournament: every pair whose fitted ratings are within MAXGAP Elo is brought up to GAMES games (the arena
# log resumes, so only the missing games are played), two strided processes per pair.  usage:
#   SGO_PLACE=<rule> refine.sh <name> [GAMES=64] [MAXGAP=300]     (runs/tour_<name>/, players.txt, bt.txt from bt.py)
cd /home/claude/eng
if [ -n "$SGO_GO" ]; then MODE=goarena; CAP=300; else MODE=arena; CAP=200; fi
SG=${SGONET:-./sgonet}
name=$1; GAMES=${2:-64}; MAXGAP=${3:-300}; dir=runs/tour_$name
python3 - "$dir" "$MAXGAP" > $dir/refine_pairs.txt <<'PY'
import sys, re
d, maxgap = sys.argv[1], int(sys.argv[2])
players = open(f'{d}/players.txt').read().split()[2:]
r = {}
for line in open(f'{d}/bt.txt'):
    m = re.match(r'\s*(\S+)\s+([-+]\d+)\s+(\d+)\s+\d+', line)
    if m: r[m.group(1)] = int(m.group(2))
for i in range(len(players)):
    for j in range(i + 1, len(players)):
        if abs(r[players[i]] - r[players[j]]) <= maxgap: print(i, j, players[i], players[j])
PY
echo "# refine $name: $(wc -l < $dir/refine_pairs.txt) pairs to $GAMES games (gap <= $MAXGAP)" >> $dir/results.txt
while read i j a b; do
  log=$dir/p${i}_${j}.games; seed=$((9000 + 100 * i + j))
  [ "$(grep -c '^G' $log 2>/dev/null)" -ge "$GAMES" ] && continue
  SGO_STRIDE=0/2 $SG $MODE "$a" "$b" $GAMES $seed $CAP $log 2>>$dir/p${i}_${j}.log > $dir/tmp.0 &
  SGO_STRIDE=1/2 $SG $MODE "$a" "$b" $GAMES $seed $CAP $log 2>>$dir/p${i}_${j}.log > $dir/tmp.1 &
  wait
  echo "R $i $j $(cat $dir/tmp.0 $dir/tmp.1 | grep -E 'ARENA|GOARENA' | tail -1)" >> $dir/results.txt
done < $dir/refine_pairs.txt
echo "REFINED $GAMES" >> $dir/results.txt
