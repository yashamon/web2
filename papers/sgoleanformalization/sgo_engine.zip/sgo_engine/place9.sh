#!/bin/bash
# the g<G> nets against the Monte Carlo agent at 3277 playouts per candidate (the top rung of the 9x9 ladders), each
# under its own rule: A nets/ (SGO_PLACE=4), B nets_simple/ (1), C nets_aug/ (3); 100 games each, 100 sims, two strided
# processes; resumable.  usage: place9.sh <G> [games=100] [budget=3277] -> runs/place_g<G>.txt
cd /home/claude/eng
G=$1; N=${2:-100}; BUD=${3:-3277}; out=runs/place_g${G}_b$BUD.txt; touch $out
export SGO_EYEDEF=1
run() { local tag=$1 place=$2 w=$3; grep -q "^$tag " $out && return; [ -f $w ] || { echo "no $w yet"; return; }
  SGO_PLACE=$place SGO_STRIDE=0/2 ./sgonet eval $w 100 $BUD $N 8001 200 runs/place_g${G}_${tag}_b$BUD.games 2>>runs/place_g${G}_${tag}_b$BUD.log > runs/tmp_place_$tag.0 &
  SGO_PLACE=$place SGO_STRIDE=1/2 ./sgonet eval $w 100 $BUD $N 8001 200 runs/place_g${G}_${tag}_b$BUD.games 2>>runs/place_g${G}_${tag}_b$BUD.log > runs/tmp_place_$tag.1 &
  wait
  echo "$tag $(cat runs/tmp_place_$tag.0 runs/tmp_place_$tag.1 | grep EVAL | tail -1)" >> $out; }
run A_dec 4 nets/g$G.bin
run B_simple 1 nets_simple/g$G.bin
run C_aug 3 nets_aug/g$G.bin
echo DONE >> $out
