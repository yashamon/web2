#!/bin/bash
out=runs/pos_$1_rule$2.txt
SGO_PLACE=$2 ./sgo pos pos/$1.txt matrixeq 100 8 "$3" "$4" > $out 2>/dev/null
