#!/bin/bash
# 19x19: SGo Dec, no ko rule, eye defense (cap 600 turns / playouts 500), then Go with positional superko and
# komi 7.5 (cap 1200 plies / playouts 700); adaptive samples to band <= 40, two processes per rung; resumable.
cd /home/claude/eng
SGO_N=19 SGO_PLACE=4 SGO_KOFLAG=0 SGO_EYEDEF=1 ./ladder13p.sh sgo 600 500 40 100 600
SGO_N=19 SGO_SUPERKO=1 SGO_KOMI=7.5 ./ladder13p.sh go 1200 700 40 100 600
