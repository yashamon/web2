#!/bin/bash
# 13x13 ladder with adaptive sample sizes (as ladder11.sh): each rung is played until its 68% band half-width is
# <= BAND Elo (min MIN games, max MAX), rungs to 1638v3277 regardless of saturation, one process.
# usage: ladder13a.sh <sgo|go> <cap> <pdepth> [BAND=40] [MIN=100] [MAX=600]; honors SGO_N (default 13), SGO_PLACE,
# SGO_SUPERKO (Go: positional superko in the games; adds _sk to the file tag), SGO_KOFLAG (the fiat simple ko, default 1; 0 = no ko rule)
game=$1; cap=$2; pd=$3; band=${4:-40}; min=${5:-100}; max=${6:-600}; n=${SGO_N:-13}; export SGO_N=$n; ko=${SGO_KOFLAG:-1}
tag="_n${n}${SGO_SIMP:+_simp}${SGO_PLACE:+_p$SGO_PLACE}${SGO_SUPERKO:+_sk}_tot"; out=runs/${game}_ko${ko}${tag}.txt; touch $out
budgets="0 3 26 205 410 819 1638 3277"
prev=""; seed=800
for b in $budgets; do
  if [ -n "$prev" ]; then
    seed=$((seed+1)); glog=runs/${game}_ko${ko}${tag}_${prev}v${b}.games; elog=runs/${game}_ko${ko}${tag}_${prev}v${b}.log
    line=$(grep "A=$prev B=$b " $out | tail -1)
    if [ -z "$line" ]; then
      g=$min
      while :; do
        SGO_LOG=$glog ./sgo match $game $ko $prev $b $g $seed 0 $cap $pd 2>>$elog > runs/tmp_${game}${tag}.res
        read cnt sB gap half < <(python3 band.py $glog $g)
        echo "rung $prev v $b: $cnt games, B score $sB, gap $gap, band ±$half" >> $elog
        if [ "$half" -le "$band" ] || [ "$g" -ge "$max" ]; then break; fi
        g=$(python3 -c "import math; print(min($max, max($g+50, int(math.ceil($g*($half/$band)**2/50.0))*50)))")
      done
      cat runs/tmp_${game}${tag}.res >> $out
    fi
  fi
  prev=$b
done
echo DONE >> $out
