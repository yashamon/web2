#!/bin/bash
# small-board ladders under the new conventions: SGo Dec wording / simplest rule, no ko rule, eye defense;
# Go with positional superko; adaptive samples to band <= 40, rungs to 1638v3277, two processes per rung
cd /home/claude/eng
SGO_N=5  SGO_PLACE=4 SGO_KOFLAG=0 SGO_EYEDEF=1 ./ladder13p.sh sgo 200 0 40 100 600
SGO_N=5  SGO_KOFLAG=0 SGO_EYEDEF=1 ./ladder13p.sh sgo 200 0 40 100 600
SGO_N=5  SGO_SUPERKO=1 ./ladder13p.sh go 400 0 40 100 600
SGO_N=7  SGO_PLACE=4 SGO_KOFLAG=0 SGO_EYEDEF=1 ./ladder13p.sh sgo 300 0 40 100 600
SGO_N=7  SGO_KOFLAG=0 SGO_EYEDEF=1 ./ladder13p.sh sgo 300 0 40 100 600
SGO_N=7  SGO_SUPERKO=1 ./ladder13p.sh go 600 0 40 100 600
SGO_N=11 SGO_PLACE=4 SGO_KOFLAG=0 SGO_EYEDEF=1 ./ladder13p.sh sgo 300 250 40 100 600
