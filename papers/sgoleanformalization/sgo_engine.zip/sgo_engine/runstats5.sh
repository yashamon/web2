#!/bin/bash
# branch reduce (2026-11-14): the SGo statistics of Sections 2.2, 7.1 and 7.2 under Condition (4) of def_captured
# (SGO_ORPHAN=1); otherwise the conventions of runstats4.sh (Dec wording, no ko rule, the eye defense in the agents'
# move set).  The Go lines of runstats4.sh do not depend on the SGo capture rule and are not rerun.
out=runs/stats5.txt; : > $out
run() { echo "## $*" >> $out; env "$@" 2>/dev/null >> $out; }
run SGO_ORPHAN=1 SGO_PLACE=4 SGO_EYEDEF=1 ./sgo eqplay 1000 16 5 400
run SGO_ORPHAN=1 SGO_PLACE=4 ./sgo table sgo 1000 40
run SGO_ORPHAN=1 SGO_PLACE=4 ./sgo table sgo 1000 0
run SGO_ORPHAN=1 SGO_N=19 SGO_PLACE=4 ./sgo table sgo 1000 0
echo DONE >> $out
