RESULT game=go ko=1 A=1638 B=3277 games=100 scoreA=0.470 W47 D0 L53 eloA-B=-21 meanturns=220.9 meanabsmargin=30.7
