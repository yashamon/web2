RESULT game=sgo ko=0 A=819 B=1638 games=100 scoreA=0.420 W42 D0 L58 eloA-B=-56 meanturns=252.7 meanabsmargin=35.4
