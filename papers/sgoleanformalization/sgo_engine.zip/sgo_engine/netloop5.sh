#!/bin/bash
# the self-play training loop, one instance per game/rule (netloop4.sh + the Go tag):
#   netloop5.sh dec|aug|simple <first> <last> [games=150] [sims=100]   SGo under placement rule 4 | 3 | 1 (nets/, nets_aug/, nets_simple/)
#   netloop5.sh go <first> <last> [games=150] [sims=100]               9x9 Go, positional superko, komi 7.5 (nets_go/, data_go/)
# Generation k: self-play with <nets>/g$k.bin (two processes, seeds 1000+k and 2000+k), training on the last three
# generations -> <nets>/g$((k+1)).bin, then the progress match of the new net (SGo: 30 games vs the fork base nets/g13.bin
# at <sims>; Go: 30 games vs the MC agent at 205 playouts per candidate).  Resumable at every step.
cd /home/claude/eng
tag=$1; k=$2; last=$3; G=${4:-150}; S=${5:-100}
case $tag in
  dec) export SGO_PLACE=4; nets=nets; data=data; sfx="";;
  aug) export SGO_PLACE=3; nets=nets_aug; data=data_aug; sfx="_aug";;
  simple) export SGO_PLACE=1; nets=nets_simple; data=data_simple; sfx="_simple";;
  go) export SGO_GO=1; nets=nets_go; data=data_go; sfx="_go";;
  *) echo "tag dec|aug|simple|go"; exit 1;;
esac
if [ "$tag" = go ]; then SP=goselfplay; CAP=300; else SP=selfplay; CAP=200; fi
REF=nets/g13.bin
mkdir -p $nets $data
while [ $k -le $last ]; do
  if [ ! -f $nets/g$k.bin ]; then echo "no $nets/g$k.bin"; exit 1; fi
  if [ ! -f $data/g${k}.done ]; then
    ./sgonet $SP $nets/g$k.bin $G $S $data/g${k}_a.dat $((1000+k)) $CAP 2>>runs/net_selfplay${sfx}_g${k}_a.log > runs/tmp_sp${sfx}_a.txt &
    ./sgonet $SP $nets/g$k.bin $G $S $data/g${k}_b.dat $((2000+k)) $CAP 2>>runs/net_selfplay${sfx}_g${k}_b.log > runs/tmp_sp${sfx}_b.txt &
    wait
    { echo "## generation $k"; cat runs/tmp_sp${sfx}_a.txt runs/tmp_sp${sfx}_b.txt; } >> runs/net_selfplay${sfx}.txt
    touch $data/g${k}.done
  fi
  if [ ! -f $nets/g$((k+1)).bin ]; then
    files=""; for j in $k $((k-1)) $((k-2)); do
      if [ $j -ge 0 ]; then if [ -f $data/g${j}_a.dat ]; then files="$files $data/g${j}_a.dat $data/g${j}_b.dat"; else files="$files data/g${j}_a.dat data/g${j}_b.dat"; fi; fi; done
    lr=0.001; [ $k -ge 10 ] && lr=0.0003; [ $k -ge 20 ] && lr=0.0001
    { echo "## generation $k -> $((k+1))"; ./sgonet train $nets/g$k.bin $nets/g$((k+1)).bin 2 $lr $files; } >> runs/net_train${sfx}.txt 2>&1
  fi
  if [ ! -f runs/net_ref${sfx}_g$((k+1)).txt ]; then
    if [ "$tag" = go ]; then
      ./sgonet goarena net:$nets/g$((k+1)).bin@$S mc205 30 $((4000+k)) $CAP runs/net_ref${sfx}_g$((k+1)).games 2>/dev/null > runs/net_ref${sfx}_g$((k+1)).tmp
    else
      ./sgonet match $nets/g$((k+1)).bin $S $REF $S 30 $((4000+k)) $CAP runs/net_ref${sfx}_g$((k+1)).games 2>/dev/null > runs/net_ref${sfx}_g$((k+1)).tmp
    fi && mv runs/net_ref${sfx}_g$((k+1)).tmp runs/net_ref${sfx}_g$((k+1)).txt
    { echo -n "g$((k+1)): "; cat runs/net_ref${sfx}_g$((k+1)).txt; } >> runs/net_ref${sfx}.txt
  fi
  k=$((k+1))
done
