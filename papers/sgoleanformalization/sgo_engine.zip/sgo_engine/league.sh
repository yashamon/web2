#!/bin/bash
# The MC-partner experiment (2026-11-13), resumable; (re)started by relaunch.sh.
#  1. the league line under rule A (netloop6.sh lgA) from nets/g0.bin (the original line's start) to g25;
#  2. from its g13, the league line under rule B (netloop6.sh lgB) to g25, alongside;
#  3. robustness baselines (lgbase.sh, low priority): the original nets vs mc0, 30 games each, as the lines' eval0;
#  4. when both lines are done: the combined tournaments tour_LA / tour_LB (lgtour.sh);
#  5. then the paused Go run resumes (runs/GO_PAUSED removed, relaunch.sh go).
cd /home/claude/eng
mkdir -p nets_lgA nets_lgB runs/lgA runs/lgB runs/lgbase
[ -f nets_lgA/g0.bin ] || cp nets/g0.bin nets_lgA/g0.bin
latest() { ls $1/g*.bin 2>/dev/null | sed 's/.*g\([0-9]*\)\.bin/\1/' | sort -n | tail -1; }
done_line() { [ -f runs/$1/ref_g25.txt ]; }
startloop() { # startloop <tag> <nets> <first>: from the latest net, one generation back when its records are missing
  local tag=$1 nets=$2 first=$3 k; k=$(latest $nets)
  if [ "$k" -gt "$first" ] && [ ! -f runs/$tag/eval0_g$k.txt ]; then k=$((k-1)); fi
  echo "$(date +%m-%d_%H:%M) $tag loop from g$k"
  setsid nohup ./netloop6.sh $tag $k 24 150 100 >> runs/$tag/loop.out 2>&1 < /dev/null &
}
if ! pgrep -f '/bin/bash ./lgbase.sh' > /dev/null && [ ! -f runs/lgbase/DONE ]; then setsid nohup ./lgbase.sh >> runs/lgbase/out.txt 2>&1 < /dev/null & fi
while true; do
  if ! done_line lgA && ! pgrep -f '/bin/bash ./netloop6.sh lgA' > /dev/null; then startloop lgA nets_lgA 0; fi
  if [ -f nets_lgA/g13.bin ]; then
    [ -f nets_lgB/g13.bin ] || cp nets_lgA/g13.bin nets_lgB/g13.bin
    if ! done_line lgB && ! pgrep -f '/bin/bash ./netloop6.sh lgB' > /dev/null; then startloop lgB nets_lgB 13; fi
  fi
  if done_line lgA && done_line lgB; then break; fi
  sleep 120
done
echo "$(date +%m-%d_%H:%M) both lines done; tournaments"
[ -f runs/tour_LB/ALLDONE ] || ./lgtour.sh
if [ -f runs/tour_LB/ALLDONE ]; then
  rm -f runs/GO_PAUSED; echo "$(date +%m-%d_%H:%M) resuming Go"; ./relaunch.sh go
  touch runs/LEAGUE_DONE
fi
