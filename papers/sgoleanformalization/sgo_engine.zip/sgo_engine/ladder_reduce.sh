#!/bin/bash
# branch reduce (2026-11-14): the 13x13 SGo ladder of Section 7.3 under Condition (4) (SGO_ORPHAN=1), same seeds and
# conventions as the Dec ladder (runs/sgo_ko0_n13_p4_ed_tot.txt); then the statistics.  Resumable.  Lower priority.
cd /home/claude/eng
echo 5 > /proc/$$/autogroup 2>/dev/null
grep -q '^DONE' runs/sgo_ko0_n13_p4_ed_or_tot.txt 2>/dev/null || SGO_N=13 SGO_PLACE=4 SGO_KOFLAG=0 SGO_EYEDEF=1 SGO_ORPHAN=1 ./ladder13p.sh sgo 300 250
grep -q '^DONE' runs/stats5.txt 2>/dev/null || ./runstats5.sh
touch runs/REDUCE_STATS_DONE
