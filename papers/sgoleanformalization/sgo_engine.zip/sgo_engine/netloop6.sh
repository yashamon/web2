#!/bin/bash
# The MC-partner ("league") training loops (2026-11-13).  The recipe of netloop5.sh (2 x <games> games per generation,
# <sims> simulations, training on the last three generations, 2 epochs, lr 1e-3 / 3e-4 from g10 / 1e-4 from g20), except
# that every second game puts the net against an agent of the pool mc0,mc3,mc26,mc205 (sgonet leagueplay), and the
# binary is sgonet2 (matrix-product convolutions, the same arithmetic up to float rounding, about 6x faster).
#   netloop6.sh lgA <first> <last> [games=150] [sims=100]   rule A (SGO_PLACE=4): nets_lgA/, data_lgA/; g0 = nets/g0.bin
#   netloop6.sh lgB <first> <last> [games=150] [sims=100]   rule B (SGO_PLACE=1): nets_lgB/, data_lgB/; g13 = nets_lgA/g13.bin,
#                                                           the generations before the fork train on data_lgA
# Records of each new net g$((k+1)) in runs/<tag>/: eval205_gK.txt (30 games vs mc205, as the original loop's net_eval),
# eval0_gK.txt (30 games vs mc0, the random policy), and from g14 on ref_gK.txt (30 games vs nets/g13.bin, as netloop5's
# progress match).  Resumable at every step.
cd /home/claude/eng
tag=$1; k=$2; last=$3; G=${4:-150}; S=${5:-100}; POOL=mc0,mc3,mc26,mc205; CAP=200; REF=nets/g13.bin
case $tag in
  lgA) export SGO_PLACE=4; nets=nets_lgA; data=data_lgA; prev=data_lgA;;
  lgB) export SGO_PLACE=1; nets=nets_lgB; data=data_lgB; prev=data_lgA;;
  *) echo "tag lgA|lgB"; exit 1;;
esac
R=runs/$tag; mkdir -p $nets $data $R
while [ $k -le $last ]; do
  if [ ! -f $nets/g$k.bin ]; then echo "no $nets/g$k.bin"; exit 1; fi
  if [ ! -f $data/g${k}.done ]; then
    ./sgonet2 leagueplay $nets/g$k.bin $G $S $data/g${k}_a.dat $((1000+k)) $CAP $POOL 2>>$R/selfplay_g${k}_a.log > $R/tmp_sp_a.txt &
    ./sgonet2 leagueplay $nets/g$k.bin $G $S $data/g${k}_b.dat $((2000+k)) $CAP $POOL 2>>$R/selfplay_g${k}_b.log > $R/tmp_sp_b.txt &
    wait
    { echo "## generation $k"; cat $R/tmp_sp_a.txt $R/tmp_sp_b.txt; } >> $R/selfplay.txt
    touch $data/g${k}.done
  fi
  if [ ! -f $nets/g$((k+1)).bin ]; then
    files=""; for j in $k $((k-1)) $((k-2)); do
      if [ $j -ge 0 ]; then if [ -f $data/g${j}_a.dat ]; then files="$files $data/g${j}_a.dat $data/g${j}_b.dat"; else files="$files $prev/g${j}_a.dat $prev/g${j}_b.dat"; fi; fi; done
    lr=0.001; [ $k -ge 10 ] && lr=0.0003; [ $k -ge 20 ] && lr=0.0001
    { echo "## generation $k -> $((k+1))"; ./sgonet2 train $nets/g$k.bin $nets/g$((k+1)).bin.tmp 2 $lr $files; } >> $R/train.txt 2>&1 && mv $nets/g$((k+1)).bin.tmp $nets/g$((k+1)).bin
    [ -f $nets/g$((k+1)).bin ] || { echo "training g$k -> g$((k+1)) failed"; exit 1; }
  fi
  n1=$((k+1))
  if [ ! -f $R/eval205_g$n1.txt ]; then
    ./sgonet2 eval $nets/g$n1.bin $S 205 30 $((3000+k)) $CAP 2>/dev/null > $R/eval205_g$n1.tmp && mv $R/eval205_g$n1.tmp $R/eval205_g$n1.txt
    { echo -n "g$n1: "; cat $R/eval205_g$n1.txt; } >> $R/eval205.txt
  fi
  if [ ! -f $R/eval0_g$n1.txt ]; then
    ./sgonet2 eval $nets/g$n1.bin $S 0 30 $((5000+k)) $CAP 2>/dev/null > $R/eval0_g$n1.tmp && mv $R/eval0_g$n1.tmp $R/eval0_g$n1.txt
    { echo -n "g$n1: "; cat $R/eval0_g$n1.txt; } >> $R/eval0.txt
  fi
  if [ $n1 -ge 14 ] && [ ! -f $R/ref_g$n1.txt ]; then
    ./sgonet2 match $nets/g$n1.bin $S $REF $S 30 $((4000+k)) $CAP $R/ref_g$n1.games 2>/dev/null > $R/ref_g$n1.tmp && mv $R/ref_g$n1.tmp $R/ref_g$n1.txt
    { echo -n "g$n1: "; cat $R/ref_g$n1.txt; } >> $R/ref.txt
  fi
  k=$((k+1))
done
echo "$tag done through g$((last+1))"
