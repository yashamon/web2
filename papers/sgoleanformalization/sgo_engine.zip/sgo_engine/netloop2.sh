#!/bin/bash
# the self-play training loop under the August wording of placement rule (2) (SGO_PLACE=3), forked from the December
# loop: nets_aug/g<first>.bin is a copy of nets/g<first>.bin; generations before the fork are read from the December
# data (identical history), later ones from data_aug/.  Same seeds, games and simulations as netloop.sh, so the two
# loops are paired.  Resumable.  usage: netloop2.sh <first_gen> <last_gen> [games_per_process=150] [sims=100]
cd /home/claude/eng
export SGO_PLACE=3
k=$1; last=$2; G=${3:-150}; S=${4:-100}
mkdir -p nets_aug data_aug
while [ $k -le $last ]; do
  if [ ! -f nets_aug/g$k.bin ]; then echo "no nets_aug/g$k.bin"; exit 1; fi
  if [ ! -f data_aug/g${k}.done ]; then
    ./sgonet selfplay nets_aug/g$k.bin $G $S data_aug/g${k}_a.dat $((1000+k)) 2>runs/net_selfplay_aug_g${k}_a.log > runs/tmp_sp_aug_a.txt &
    ./sgonet selfplay nets_aug/g$k.bin $G $S data_aug/g${k}_b.dat $((2000+k)) 2>runs/net_selfplay_aug_g${k}_b.log > runs/tmp_sp_aug_b.txt &
    wait
    { echo "## generation $k"; cat runs/tmp_sp_aug_a.txt runs/tmp_sp_aug_b.txt; } >> runs/net_selfplay_aug.txt
    touch data_aug/g${k}.done
  fi
  if [ ! -f nets_aug/g$((k+1)).bin ]; then
    files=""; for j in $k $((k-1)) $((k-2)); do
      if [ $j -ge 0 ]; then if [ -f data_aug/g${j}_a.dat ]; then files="$files data_aug/g${j}_a.dat data_aug/g${j}_b.dat"; else files="$files data/g${j}_a.dat data/g${j}_b.dat"; fi; fi; done
    lr=0.001; [ $k -ge 10 ] && lr=0.0003; [ $k -ge 20 ] && lr=0.0001
    { echo "## generation $k -> $((k+1))"; ./sgonet train nets_aug/g$k.bin nets_aug/g$((k+1)).bin 2 $lr $files; } >> runs/net_train_aug.txt 2>&1
  fi
  if [ ! -f runs/net_eval_aug_g$((k+1)).txt ]; then
    ./sgonet eval nets_aug/g$((k+1)).bin $S 205 30 $((3000+k)) 2>/dev/null > runs/net_eval_aug_g$((k+1)).txt
    { echo -n "g$((k+1)): "; cat runs/net_eval_aug_g$((k+1)).txt; } >> runs/net_eval_aug.txt
  fi
  k=$((k+1))
done
