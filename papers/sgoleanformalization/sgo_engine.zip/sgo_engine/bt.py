#!/usr/bin/env python3
"""Bradley-Terry ratings from a tournament directory: bt.py <dir> [anchor_index=0] [boots=400] [prior=0.1]
Reads runs/tour_<name>/players.txt and p<i>_<j>.games (lines "G gi margin aBlack ..."; A = player i).  Draws count half.
Elo = 400 log10(strength), anchored so that the anchor player is 0.  Bootstrap over games within each pair."""
import sys, os, glob, math, random
d = sys.argv[1]; anchor = int(sys.argv[2]) if len(sys.argv) > 2 else 0; boots = int(sys.argv[3]) if len(sys.argv) > 3 else 400
prior = float(sys.argv[4]) if len(sys.argv) > 4 else 0.1  # virtual wins per pair, split equally (keeps all-win players finite; small so that it does not compress the scale)
players = open(os.path.join(d, 'players.txt')).read().split()[2:]
n = len(players)
games = {}  # (i, j) -> list of A-scores
for f in glob.glob(os.path.join(d, 'p*_*.games')):
    b = os.path.basename(f)[1:-6]; i, j = map(int, b.split('_'))
    sc = []
    for line in open(f):
        p = line.split()
        if len(p) >= 5 and p[0] == 'G':
            m = float(p[2]); ab = int(p[3]); sc.append(0.5 if m == 0 else (1.0 if (m > 0) == (ab == 1) else 0.0))
    if sc: games[(i, j)] = sc
def fit(games):
    # MM algorithm for Bradley-Terry with half-wins for draws
    w = [0.0] * n; cnt = {}
    for (i, j), sc in games.items():
        s = sum(sc); w[i] += s + prior / 2; w[j] += len(sc) - s + prior / 2; cnt[(i, j)] = len(sc) + prior
    g = [1.0] * n
    for it in range(2000):
        new = []
        for i in range(n):
            den = 0.0
            for (a, b), c in cnt.items():
                if a == i: den += c / (g[i] + g[b])
                elif b == i: den += c / (g[i] + g[a])
            new.append(w[i] / den if den > 0 else g[i])
        m = sum(math.log(x) for x in new) / n; new = [x / math.exp(m) for x in new]
        if max(abs(math.log(new[i]) - math.log(g[i])) for i in range(n)) < 1e-9: g = new; break
        g = new
    elo = [400 * math.log10(x) for x in g]; a0 = elo[anchor]; return [e - a0 for e in elo]
base = fit(games)
random.seed(7); bs = [[] for _ in range(n)]
for _ in range(boots):
    gb = {k: [random.choice(sc) for _ in sc] for k, sc in games.items()}
    e = fit(gb)
    for i in range(n): bs[i].append(e[i])
order = sorted(range(n), key=lambda i: -base[i])
print(f"{'player':>36} {'elo':>7} {'se':>5}  games")
for i in order:
    se = (sum((x - sum(bs[i]) / boots) ** 2 for x in bs[i]) / (boots - 1)) ** 0.5 if boots > 1 else 0
    ng = sum(len(sc) for (a, b), sc in games.items() if a == i or b == i)
    print(f"{players[i]:>36} {base[i]:>+7.0f} {se:>5.0f}  {ng}")

# residuals: observed score of i against j vs the fitted expectation; the largest show where one Elo scale fails
res = []
for (i, j), sc in games.items():
    obs = sum(sc) / len(sc); exp = 1 / (1 + 10 ** ((base[j] - base[i]) / 400)); se = math.sqrt(max(exp * (1 - exp), 1e-4) / len(sc))
    res.append(((obs - exp) / se, players[i], players[j], obs, exp, len(sc)))
res.sort(key=lambda r: -abs(r[0]))
print("\nlargest residuals (observed score of A vs B against the fit, in standard errors):")
for z, a, b, obs, exp, m in res[:8]: print(f"  {a:>24} v {b:<24} observed {obs:.2f} expected {exp:.2f} ({m} games) {z:+.1f} se")
