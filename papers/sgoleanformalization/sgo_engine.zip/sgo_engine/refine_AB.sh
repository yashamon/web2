#!/bin/bash
# the two refinements in sequence (A then B), each resumable
cd /home/claude/eng
grep -q '^REFINED 64' runs/tour_A17/results.txt || SGO_PLACE=4 ./refine.sh A17 64 300
grep -q '^REFINED 64' runs/tour_B25/results.txt || SGO_PLACE=1 ./refine.sh B25 64 300
