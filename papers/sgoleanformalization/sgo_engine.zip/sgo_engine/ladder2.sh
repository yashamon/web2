#!/bin/bash
# print-like convention: budgets read as TOTAL playouts per turn (menu 5 → per candidate 3/26/205/410/819),
# game bound as in the printed random-play rows (SGo 40 turns, Go 80 plies).
# usage: ladder2.sh <sgo|go> <ko> <cap> ; writes runs/<game>_ko<ko>_print.txt
game=$1; ko=$2; cap=$3; out=runs/${game}_ko${ko}_print.txt; : > $out
pairs="0:3:100 3:26:100 26:205:100 205:410:100 410:819:60"
seed=300
for p in $pairs; do a=${p%%:*}; rest=${p#*:}; b=${rest%%:*}; g=${rest#*:}; seed=$((seed+1))
  ./sgo match $game $ko $a $b $g $seed 0 $cap 2>runs/${game}_ko${ko}_print_${a}v${b}.log | tee -a $out
done
echo DONE >> $out
