#!/bin/bash
# short-playout probe: print-like budgets, printed bounds, playouts cut at pdepth (SGo turns / Go plies)
out=runs/pdepth_probe.txt; : > $out
for p in "sgo 40 5" "go 80 10" "sgo 40 2" "go 80 4"; do set -- $p; game=$1; cap=$2; pd=$3
  for pair in "0 3" "3 26" "26 205"; do set -- $pair
    ./sgo_pd match $game 0 $1 $2 100 401 0 $cap $pd 2>/dev/null | sed "s/^/pdepth=$pd /" | tee -a $out
  done
done
echo DONE >> $out
