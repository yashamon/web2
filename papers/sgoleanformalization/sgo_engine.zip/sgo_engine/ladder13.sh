#!/bin/bash
# climbing ladder, ko on, budgets as totals per turn (16·2^k; per candidate 3,26,205,410,819,1638,...), resumable
# at the game level (SGO_LOG) and at the rung level (RESULT lines); stops after a rung whose gap is <= STOP Elo.
# usage: ladder13.sh <sgo|go> <cap> <pdepth> [STOP=40] ; honors SGO_N (default 13), SGO_PLACE
game=$1; cap=$2; pd=$3; stop=${4:-40}; n=${SGO_N:-13}; export SGO_N=$n
tag="_n${n}${SGO_SIMP:+_simp}${SGO_PLACE:+_p$SGO_PLACE}_tot"; out=runs/${game}_ko1${tag}.txt; touch $out
budgets="0 3 26 205 410 819 1638 3277 6554 13107"
prev=""; seed=400; idx=0
for b in $budgets; do
  if [ -n "$prev" ]; then
    idx=$((idx+1)); seed=$((seed+1)); g=100; [ $idx -ge 5 ] && g=60
    line=$(grep "A=$prev B=$b " $out | head -1)
    if [ -z "$line" ]; then
      SGO_LOG=runs/${game}_ko1${tag}_${prev}v${b}.games ./sgo match $game 1 $prev $b $g $seed 0 $cap $pd 2>runs/${game}_ko1${tag}_${prev}v${b}.log | tee -a $out
      line=$(grep "A=$prev B=$b " $out | head -1)
    fi
    gap=$(echo "$line" | sed -n 's/.*eloA-B=\([-+0-9]*\).*/\1/p')
    # the gap is A-B; B is the bigger budget, so saturation = gap >= -STOP
    if [ -n "$gap" ] && [ "$gap" -ge "-$stop" ]; then echo "SATURATED at $prev v $b (gap $gap)" >> $out; break; fi
  fi
  prev=$b
done
echo DONE >> $out
