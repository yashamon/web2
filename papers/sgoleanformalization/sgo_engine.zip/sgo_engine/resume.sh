#!/bin/bash
# resume a ladder: run the rungs whose RESULT line is missing. usage: resume.sh <game> <ko>  (SGO_SIMP honored)
game=$1; ko=$2; tag=${SGO_SIMP:+_simp}; out=runs/${game}_ko${ko}${tag}.txt
pairs="0:16:100 16:128:100 128:1024:100 1024:2048:100 2048:4096:60"
seed=100
for p in $pairs; do a=${p%%:*}; rest=${p#*:}; b=${rest%%:*}; g=${rest#*:}; seed=$((seed+1))
  grep -q "A=$a B=$b " $out && continue
  ./sgo match $game $ko $a $b $g $seed 2>runs/${game}_ko${ko}${tag}_${a}v${b}.log | tee -a $out
done
echo DONE >> $out
