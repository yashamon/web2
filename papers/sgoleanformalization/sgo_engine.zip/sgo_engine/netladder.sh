#!/bin/bash
# the simulation ladder of one net: rung s v 2s = the net at 2s simulations (A) against itself at s (B), colors
# alternating, adaptive samples until the 68% band half-width is <= BAND Elo (min MIN, max MAX games), two processes
# per rung sharing one game log.  usage: netladder.sh <tag> <weights> <place 3|4> [BAND=40] [MIN=100] [MAX=400] [SIMS="12 25 50 100 200 400"]
# output: runs/netladder_<tag>.txt (a MATCH line per rung), runs/netladder_<tag>_<s>v<2s>.games
cd /home/claude/eng
tag=$1; w=$2; export SGO_PLACE=$3; band=${4:-40}; min=${5:-100}; max=${6:-400}; sims=${7:-"12 25 50 100 200 400"}
out=runs/netladder_$tag.txt; touch $out; prev=""; seed=5000
for s in $sims; do
  if [ -n "$prev" ]; then
    seed=$((seed+1)); glog=runs/netladder_${tag}_${prev}v${s}.games; elog=runs/netladder_${tag}_${prev}v${s}.log
    if ! grep -q "sims=$s B=.* sims=$prev " $out; then
      g=$min
      while :; do
        SGO_STRIDE=0/2 ./sgonet match $w $s $w $prev $g $seed 200 $glog 2>>$elog > runs/tmp_nl_${tag}.0 &
        SGO_STRIDE=1/2 ./sgonet match $w $s $w $prev $g $seed 200 $glog 2>>$elog > runs/tmp_nl_${tag}.1 &
        wait
        read cnt sA gap half < <(python3 band2.py $glog $g)
        echo "rung $s v $prev: $cnt games, A score $sA, gap $gap, band ±$half" >> $elog
        if [ "$half" -le "$band" ] || [ "$g" -ge "$max" ]; then break; fi
        g=$(python3 -c "import math; print(min($max, max($g+50, int(math.ceil($g*($half/$band)**2/50.0))*50)))")
      done
      cat runs/tmp_nl_${tag}.0 runs/tmp_nl_${tag}.1 | grep MATCH | tail -1 >> $out
    fi
  fi
  prev=$s
done
echo DONE >> $out
