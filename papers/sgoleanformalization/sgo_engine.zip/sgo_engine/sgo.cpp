// sgo.cpp — SGo and classical Go engines, remade from the printed rules
// (sgo.tex §2) by transcribing the differentially tested Lean engine
// (SgoDisplay.lean / SgoSerial.lean / SgoGo.lean), with Monte Carlo
// agents and the Elo ladder of §7.3.  Build: g++ -O2 -std=c++17 sgo.cpp -o sgo
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cstdint>
#include <string>
#include <vector>
#include <random>
#include <algorithm>
#include <fstream>
#include <sstream>
#include <cmath>
#include <chrono>
#include <unordered_map>
#include <unordered_set>

static const int MAXC = 361;
enum Kind : int8_t { EMPTY = 0, B = 1, W = 2, R = 3 };
static inline int opp(int k) { return k == B ? W : (k == W ? B : R); }

struct Board;
static const Board* g_bd = nullptr; // the board in use (geometry for the placement rule); set by the constructor
struct Board {
  int n, h, N; // n columns, h rows (h = n unless a rectangular board is asked for, pos mode only), N = n*h cells
  int nbr[MAXC][4]; int nnb[MAXC];
  Board(int n_, int h_ = 0) : n(n_), h(h_ > 0 ? h_ : n_), N(n_ * (h_ > 0 ? h_ : n_)) {
    g_bd = this;
    for (int i = 0; i < N; i++) {
      int x = i / n, y = i % n; nnb[i] = 0;
      if (x > 0) nbr[i][nnb[i]++] = i - n;
      if (x + 1 < h) nbr[i][nnb[i]++] = i + n;
      if (y > 0) nbr[i][nnb[i]++] = i - 1;
      if (y + 1 < n) nbr[i][nnb[i]++] = i + 1;
    }
  }
};

struct Display {
  int8_t kind[MAXC]; int16_t stamp[MAXC]; int N;
  void clear(int N_) { N = N_; memset(kind, 0, sizeof(kind)); memset(stamp, 0, sizeof(stamp)); }
  bool operator==(const Display& o) const {
    for (int i = 0; i < N; i++) if (kind[i] != o.kind[i] || (kind[i] && stamp[i] != o.stamp[i])) return false;
    return true;
  }
  bool operator!=(const Display& o) const { return !(*this == o); }
};

// ---------- the display calculus (SgoDisplay.lean) ----------
struct Comp { int cells[MAXC]; int sz; bool mark[MAXC]; };

static void component(const Board& bd, const Display& D, int i, Comp& c) {
  c.sz = 0; memset(c.mark, 0, bd.N);
  int k = D.kind[i]; if (k == EMPTY) return;
  int stack[MAXC], sp = 0; stack[sp++] = i; c.mark[i] = true;
  while (sp) {
    int p = stack[--sp]; c.cells[c.sz++] = p;
    for (int a = 0; a < bd.nnb[p]; a++) { int q = bd.nbr[p][a]; if (!c.mark[q] && D.kind[q] == k) { c.mark[q] = true; stack[sp++] = q; } }
  }
}
static bool noLib(const Board& bd, const Display& D, const Comp& c) {
  for (int s = 0; s < c.sz; s++) { int p = c.cells[s]; for (int a = 0; a < bd.nnb[p]; a++) if (D.kind[bd.nbr[p][a]] == EMPTY) return false; }
  return true;
}
// def_trapped: trapped, and t is the largest stamp among the component's stones and the stones adjacent to it
static bool trappedOnTurn(const Board& bd, const Display& D, const Comp& c, int t) {
  if (!noLib(bd, D, c)) return false;
  int mx = 0;
  for (int s = 0; s < c.sz; s++) { int p = c.cells[s]; if (D.stamp[p] > mx) mx = D.stamp[p];
    for (int a = 0; a < bd.nnb[p]; a++) { int q = bd.nbr[p][a]; if (D.kind[q] != EMPTY && !c.mark[q] && D.stamp[q] > mx) mx = D.stamp[q]; } }
  return mx == t;
}
// "trapped by <attacker> on turn t" for the stone at z (a q-stone read as the defender's color)
static bool stoneTrappedBy(const Board& bd, const Display& D, int z, int attacker, int t, Comp& tmp) {
  int defender = opp(attacker);
  if (D.kind[z] == R) {
    Display D2 = D; D2.kind[z] = defender;
    component(bd, D2, z, tmp); return trappedOnTurn(bd, D2, tmp, t);
  } else if (D.kind[z] == defender) {
    component(bd, D, z, tmp); return trappedOnTurn(bd, D, tmp, t);
  }
  return false;
}
static bool sameSet(const Comp& a, const Comp& b) {
  if (a.sz != b.sz) return false;
  for (int s = 0; s < a.sz; s++) if (!b.mark[a.cells[s]]) return false;
  return true;
}
// SGO_SIMP=1 (environment): the simplified capture condition — the clause "and is not a q-stone" of
// cond_suicidalcapture (3b) is dropped, so a suicidal capture by a q-stone resolves as a capture.
// Remark rem_suicidalcapture names this clause as the one that precludes Ko type loops.
static bool g_simp = false;
// def_captured for the unicolor component comp of kind c, this turn t
static bool isCaptured(const Board& bd, const Display& D, const Comp& comp, int c, int t) {
  if (!trappedOnTurn(bd, D, comp, t)) return false;
  Comp Dc;
  // (2) cond_unambiguous0: a q-stone adjacent to C adjacent to another trapped component ⇒ that component has C's color
  for (int s = 0; s < comp.sz; s++) { int p = comp.cells[s];
    for (int a = 0; a < bd.nnb[p]; a++) { int r = bd.nbr[p][a]; if (D.kind[r] != R) continue;
      for (int b = 0; b < bd.nnb[r]; b++) { int z = bd.nbr[r][b]; if (D.kind[z] != B && D.kind[z] != W) continue;
        component(bd, D, z, Dc);
        if (!sameSet(Dc, comp) && noLib(bd, D, Dc) && D.kind[z] != c) return false; } } }
  // adjacent stones: occupied, not in comp, adjacent to comp (deduplicated)
  int adj[MAXC], nadj = 0; bool seen[MAXC]; memset(seen, 0, bd.N);
  for (int s = 0; s < comp.sz; s++) { int p = comp.cells[s];
    for (int a = 0; a < bd.nnb[p]; a++) { int z = bd.nbr[p][a]; if (D.kind[z] != EMPTY && !comp.mark[z] && !seen[z]) { seen[z] = true; adj[nadj++] = z; } } }
  // (3a)
  bool a3 = true;
  for (int s = 0; s < nadj && a3; s++) { int z = adj[s];
    if ((D.kind[z] == opp(c) || D.kind[z] == R) && stoneTrappedBy(bd, D, z, c, t, Dc)) a3 = false; }
  if (a3) return true;
  // (3b) suicidal capture: no stone of C created this turn; every adjacent stone trapped on this turn
  // lies in a component containing a stone created this turn that is not a q-stone
  for (int s = 0; s < comp.sz; s++) if (D.stamp[comp.cells[s]] == t) return false;
  for (int s = 0; s < nadj; s++) { int z = adj[s];
    component(bd, D, z, Dc);
    if (trappedOnTurn(bd, D, Dc, t)) {
      bool fresh = false;
      for (int u = 0; u < Dc.sz && !fresh; u++) { int q = Dc.cells[u]; if (D.stamp[q] == t && (g_simp || D.kind[q] != R)) fresh = true; }
      if (!fresh) return false; } }
  return true;
}
// one simultaneous round: the basic capture reduction at turn t; returns whether anything changed
static bool basicCap(const Board& bd, const Display& D, int t, Display& out) {
  bool capB[MAXC], capW[MAXC]; memset(capB, 0, bd.N); memset(capW, 0, bd.N);
  bool seen[MAXC]; Comp comp;
  for (int k = B; k <= W; k++) {
    memset(seen, 0, bd.N);
    for (int p = 0; p < bd.N; p++) { if (D.kind[p] != k || seen[p]) continue;
      component(bd, D, p, comp);
      for (int s = 0; s < comp.sz; s++) seen[comp.cells[s]] = true;
      if (isCaptured(bd, D, comp, k, t)) for (int s = 0; s < comp.sz; s++) (k == B ? capB : capW)[comp.cells[s]] = true; }
  }
  out = D; bool changed = false;
  for (int p = 0; p < bd.N; p++) {
    if (capB[p] || capW[p]) { out.kind[p] = EMPTY; out.stamp[p] = 0; changed = true; continue; }
    if (D.kind[p] == R) {
      bool aw = false, ab = false;
      for (int a = 0; a < bd.nnb[p]; a++) { int q = bd.nbr[p][a]; if (capW[q]) aw = true; if (capB[q]) ab = true; }
      if (aw) { out.kind[p] = B; changed = true; } else if (ab) { out.kind[p] = W; changed = true; }
    }
  }
  return changed;
}
static void capFix(const Board& bd, Display& D, int t) {
  Display D2;
  for (int fuel = 0; fuel <= bd.N; fuel++) { if (!basicCap(bd, D, t, D2)) return; D = D2; }
}
// SGO_PLACE=3 (environment): the original three-tier placement resolution (sgo.tex up to 2026-08-25, §"Stone
// placement resolution rule"): a same-intersection conflict at i resolves, in decreasing priority, to
//  1. a q-stone, if either a white or a black stone placed at i would be trapping (adjacent to an opposite
//     colored unicolor component with no liberties) — the "trapping move";
//  2. a black stone, if i is adjacent to a black stone and not to a white one; mirrored for white;
//  3. a q-stone otherwise.
// (The Dec 2025 wording of 2 also required no adjacent q-stone; the Aug 2026 wording, used here, does not.)
static int g_place = 1;
static bool wouldTrap(const Board& bd, Display& D, int i, int c) { // a c stone at i leaves an adjacent opp(c) component without liberties?
  D.kind[i] = c; Comp cc; bool r = false;
  for (int a = 0; a < bd.nnb[i] && !r; a++) { int q = bd.nbr[i][a]; if (D.kind[q] == opp(c)) { component(bd, D, q, cc); if (noLib(bd, D, cc)) r = true; } }
  D.kind[i] = EMPTY; return r;
}
// SGO_PLACE=4: the December 2025 wording of the same rule — rule 2 also requires no adjacent q-stone
// ("adjacent to a black stone, and neither a white stone nor red stone").
static int conflictKind(Display& D, int i) {
  if (g_place != 3 && g_place != 4) return R;
  const Board& bd = *g_bd;
  if (wouldTrap(bd, D, i, B) || wouldTrap(bd, D, i, W)) return R;
  bool adjB = false, adjW = false, adjR = false;
  for (int a = 0; a < bd.nnb[i]; a++) { int q = bd.nbr[i][a]; if (D.kind[q] == B) adjB = true; if (D.kind[q] == W) adjW = true; if (D.kind[q] == R) adjR = true; }
  if (g_place == 4 && adjR) return R;
  if (adjB && !adjW) return B;
  if (adjW && !adjB) return W;
  return R;
}
// the class of a conflict at the empty intersection i: 0 trapping (q-stone under both wordings), 1 adjacent to both
// colors or to none (q-stone under both), 2 one color and no adjacent q-stone (that color under both), 3 one color and
// an adjacent q-stone — the DIVERGENT case: the color under the August wording, a q-stone under the December one
static long g_confClass[4] = {0, 0, 0, 0}; static int g_divShown = 0; static bool g_divlog = false;
static int conflictClass(Display& D, int i) {
  const Board& bd = *g_bd;
  if (wouldTrap(bd, D, i, B) || wouldTrap(bd, D, i, W)) return 0;
  bool adjB = false, adjW = false, adjR = false;
  for (int a = 0; a < bd.nnb[i]; a++) { int q = bd.nbr[i][a]; if (D.kind[q] == B) adjB = true; if (D.kind[q] == W) adjW = true; if (D.kind[q] == R) adjR = true; }
  if (adjB == adjW) return 1;
  return adjR ? 3 : 2;
}
static void placeJoint(Display& D, int t, int m0, int m1) { // -1 = pass; m0 Black, m1 White
  if (m0 >= 0 && m1 >= 0) { if (m0 == m1) { D.kind[m0] = conflictKind(D, m0); D.stamp[m0] = t; } else { D.kind[m0] = B; D.stamp[m0] = t; D.kind[m1] = W; D.stamp[m1] = t; } }
  else if (m0 >= 0) { D.kind[m0] = B; D.stamp[m0] = t; }
  else if (m1 >= 0) { D.kind[m1] = W; D.stamp[m1] = t; }
}
// the stage recursion: Cap at descending turns, stopping when a stage changes nothing
static void resolveTurn(const Board& bd, Display& D, int t, int m0, int m1) {
  placeJoint(D, t, m0, m1);
  for (int s = t; s >= 1; s--) { Display before = D; capFix(bd, D, s); if (D == before) return; }
}

// ---------- classical Go (SgoGo.lean; suicide legal) ----------
// returns false if the intersection is occupied; captured count via *ncap
static bool goMove(const Board& bd, Display& D, int color, int i, int* ncap, int* capPoint) {
  if (D.kind[i] != EMPTY) return false;
  D.kind[i] = color; D.stamp[i] = 0;
  Comp c; bool dead[MAXC]; memset(dead, 0, bd.N); int nc = 0, cp = -1;
  for (int a = 0; a < bd.nnb[i]; a++) { int q = bd.nbr[i][a]; if (D.kind[q] != opp(color) || dead[q]) continue;
    component(bd, D, q, c); if (noLib(bd, D, c)) for (int s = 0; s < c.sz; s++) { dead[c.cells[s]] = true; nc++; cp = c.cells[s]; } }
  for (int p = 0; p < bd.N; p++) if (dead[p]) D.kind[p] = EMPTY;
  component(bd, D, i, c);
  if (noLib(bd, D, c)) for (int s = 0; s < c.sz; s++) D.kind[c.cells[s]] = EMPTY; // suicide
  if (ncap) *ncap = nc; if (capPoint) *capPoint = (nc == 1 ? cp : -1);
  return true;
}

// ---------- scoring (§2.6, Chinese area; q-stones count for nobody) ----------
static int areaMargin(const Board& bd, const Display& D) { // black area − white area
  int nb = 0, nw = 0; bool seen[MAXC]; memset(seen, 0, bd.N);
  for (int p = 0; p < bd.N; p++) { if (D.kind[p] == B) nb++; else if (D.kind[p] == W) nw++; }
  int stack[MAXC], cells[MAXC];
  for (int p = 0; p < bd.N; p++) { if (D.kind[p] != EMPTY || seen[p]) continue;
    int sp = 0, nc = 0; stack[sp++] = p; seen[p] = true; bool rb = false, rw = false;
    while (sp) { int u = stack[--sp]; cells[nc++] = u;
      for (int a = 0; a < bd.nnb[u]; a++) { int q = bd.nbr[u][a];
        if (D.kind[q] == EMPTY) { if (!seen[q]) { seen[q] = true; stack[sp++] = q; } }
        else if (D.kind[q] == B) rb = true; else if (D.kind[q] == W) rw = true; } }
    if (rb && !rw) nb += nc; else if (rw && !rb) nw += nc; }
  return nb - nw;
}

struct Rng { std::mt19937_64 g; Rng(uint64_t s) : g(s) {} int below(int k) { return (int)(g() % (uint64_t)k); } };

static int g_n = 5; // board side, SGO_N (environment)
struct Opts { int n = g_n; bool ko = false; double komi = 0.0; int cap = 200; int pdepth = 0; }; // pdepth: playout length bound (SGo turns / Go plies), 0 = to the end

// ---------- fast position: the display with an incrementally maintained chain table ----------
// Chains (same-kind components, q-stones included) are circular lists through nxt[], named by a representative
// cell; liberties are pseudo-liberties (one per stone / empty-neighbour pair) with the sum / sum-of-squares test
// for "exactly one distinct liberty" (libego's trick).  The display D stays the source of truth: the capture
// conditions are evaluated on D by the functions above, only for the libertyless chains the table points at.
// Validated against the slow functions by `sgo difftest` (lockstep random games) and the Lean sheets.
static inline uint64_t mix64(uint64_t x) { x += 0x9e3779b97f4a7c15ULL; x = (x ^ (x >> 30)) * 0xbf58476d1ce4e5b9ULL; x = (x ^ (x >> 27)) * 0x94d049bb133111ebULL; return x ^ (x >> 31); }
static inline uint64_t cellHash(int cell, int kind, int stamp) { return mix64(((uint64_t)cell << 20) | ((uint64_t)kind << 16) | (uint64_t)(uint16_t)stamp); }
// the stones removed and the q-stones recolored during the current resolution (read by sgoTurn for the fiat ko)
struct TurnLog { int16_t remCell[MAXC], remKind[MAXC], remStamp[MAXC]; int nrem; int16_t recCell[MAXC]; int nrec; };
static TurnLog g_log;
struct Pos {
  Display D; uint64_t hash; // hash of the display (xor of cellHash over the stones)
  int16_t cid[MAXC], nxt[MAXC], nst[MAXC], plib[MAXC];
  int16_t mx[MAXC]; // per representative: an upper bound of the largest stamp among the chain's stones and the stones adjacent to it
  int32_t lsum[MAXC]; int64_t lsq[MAXC];
  int16_t emp[MAXC], epos[MAXC], nemp;      // the empty intersections, and each cell's index in emp (-1 if occupied)
  int16_t zlist[MAXC], zidx[MAXC], nz;      // the representatives of the libertyless chains, and each representative's index (-1 if none)
  void clear(int N) { D.clear(N); hash = 0; nemp = N; nz = 0; for (int i = 0; i < N; i++) { cid[i] = -1; emp[i] = i; epos[i] = i; zidx[i] = -1; } }
  void empRemove(int i) { int j = epos[i]; int last = emp[--nemp]; emp[j] = last; epos[last] = j; epos[i] = -1; }
  void empAdd(int i) { epos[i] = nemp; emp[nemp++] = i; }
  void zAdd(int r) { if (zidx[r] < 0) { zidx[r] = nz; zlist[nz++] = r; } }
  void zRemove(int r) { int j = zidx[r]; if (j < 0) return; int last = zlist[--nz]; zlist[j] = last; zidx[last] = j; zidx[r] = -1; }
  bool atari(int r) const { return plib[r] > 0 && (int64_t)plib[r] * lsq[r] == (int64_t)lsum[r] * lsum[r]; }
  bool onlyLibIs(int r, int i) const { return atari(r) && lsum[r] == (int32_t)plib[r] * i; }
  void addLib(int r, int q) { if (plib[r] == 0) zRemove(r); plib[r]++; lsum[r] += q; lsq[r] += (int64_t)q * q; }
  void subLib(int r, int q) { plib[r]--; lsum[r] -= q; lsq[r] -= (int64_t)q * q; if (plib[r] == 0) zAdd(r); }
  int merge(int a, int b) { // two representatives, a != b; returns the representative of the union
    if (nst[b] > nst[a]) std::swap(a, b);
    int s = b; do { cid[s] = a; s = nxt[s]; } while (s != b);
    std::swap(nxt[a], nxt[b]);
    nst[a] += nst[b]; plib[a] += plib[b]; lsum[a] += lsum[b]; lsq[a] += lsq[b]; if (mx[b] > mx[a]) mx[a] = mx[b];
    zRemove(b); if (plib[a] == 0) zAdd(a); else zRemove(a);
    return a;
  }
  int place(const Board& bd, int i, int k, int t) { // an empty i; returns the representative of the stone's chain
    D.kind[i] = k; D.stamp[i] = t; cid[i] = i; nxt[i] = i; nst[i] = 1; plib[i] = 0; lsum[i] = 0; lsq[i] = 0; mx[i] = t; empRemove(i); hash ^= cellHash(i, k, t);
    for (int a = 0; a < bd.nnb[i]; a++) { int q = bd.nbr[i][a]; if (D.kind[q] == EMPTY) addLib(i, q); else { int r = cid[q]; subLib(r, i); if (t > mx[r]) mx[r] = t; if (D.stamp[q] > mx[i]) mx[i] = D.stamp[q]; } }
    if (plib[i] == 0) zAdd(i);
    int rep = i;
    for (int a = 0; a < bd.nnb[i]; a++) { int q = bd.nbr[i][a]; if (D.kind[q] == k && cid[q] != rep) rep = merge(rep, cid[q]); }
    return rep;
  }
  int removeChain(const Board& bd, int r, int* removed, int* nrem) { // empties the chain; returns its size
    int cells[MAXC]; int n = 0; int s = r; do { cells[n++] = s; s = nxt[s]; } while (s != r);
    zRemove(r);
    for (int u = 0; u < n; u++) { int c = cells[u]; hash ^= cellHash(c, D.kind[c], D.stamp[c]);
      g_log.remCell[g_log.nrem] = c; g_log.remKind[g_log.nrem] = D.kind[c]; g_log.remStamp[g_log.nrem] = D.stamp[c]; g_log.nrem++;
      D.kind[c] = EMPTY; D.stamp[c] = 0; cid[c] = -1; empAdd(c); if (removed && nrem) removed[(*nrem)++] = c; }
    for (int u = 0; u < n; u++) { int c = cells[u]; for (int a = 0; a < bd.nnb[c]; a++) { int q = bd.nbr[c][a]; if (cid[q] >= 0) addLib(cid[q], c); } }
    return n;
  }
  void recolor(int c, int k) { hash ^= cellHash(c, D.kind[c], D.stamp[c]); D.kind[c] = k; hash ^= cellHash(c, k, D.stamp[c]); g_log.recCell[g_log.nrec++] = c; }
  uint64_t fullHash() const { uint64_t h = 0; for (int i = 0; i < D.N; i++) if (D.kind[i] != EMPTY) h ^= cellHash(i, D.kind[i], D.stamp[i]); return h; }
  void rebuild(const Board& bd) { // the table from the display
    nemp = 0; nz = 0; hash = fullHash();
    for (int i = 0; i < D.N; i++) { cid[i] = -1; zidx[i] = -1; if (D.kind[i] == EMPTY) { epos[i] = nemp; emp[nemp++] = i; } else epos[i] = -1; }
    for (int i = 0; i < D.N; i++) { if (D.kind[i] == EMPTY || cid[i] >= 0) continue;
      int k = D.kind[i]; int stack[MAXC], sp = 0; stack[sp++] = i; cid[i] = i; int prev = i; nst[i] = 0; plib[i] = 0; lsum[i] = 0; lsq[i] = 0; mx[i] = 0;
      while (sp) { int p = stack[--sp]; nst[i]++; if (p != i) { nxt[prev] = p; prev = p; } if (D.stamp[p] > mx[i]) mx[i] = D.stamp[p];
        for (int a = 0; a < bd.nnb[p]; a++) { int q = bd.nbr[p][a]; if (D.kind[q] == EMPTY) addLib(i, q); else { if (D.stamp[q] > mx[i]) mx[i] = D.stamp[q]; if (D.kind[q] == k && cid[q] < 0) { cid[q] = i; stack[sp++] = q; } } } }
      nxt[prev] = i; if (plib[i] == 0) zAdd(i); }
  }
  bool sameTable(const Board& bd, const Pos& Q) const { // same partition and the same liberty statistics per cell; consistent lists
    if (nemp != Q.nemp || nz != Q.nz || hash != fullHash()) return false;
    for (int i = 0; i < D.N; i++) { if ((D.kind[i] == EMPTY) != (epos[i] >= 0) || (epos[i] >= 0 && emp[epos[i]] != i)) return false;
      if (cid[i] == i) { if ((plib[i] == 0) != (zidx[i] >= 0) || (zidx[i] >= 0 && zlist[zidx[i]] != i)) return false; } else if (zidx[i] >= 0) return false; }
    for (int i = 0; i < D.N; i++) { if ((cid[i] < 0) != (Q.cid[i] < 0)) return false; if (cid[i] < 0) continue;
      int r = cid[i], s = Q.cid[i];
      if (nst[r] != Q.nst[s] || plib[r] != Q.plib[s] || lsum[r] != Q.lsum[s] || lsq[r] != Q.lsq[s] || mx[r] < Q.mx[s]) return false;
      for (int a = 0; a < bd.nnb[i]; a++) { int q = bd.nbr[i][a]; if (Q.cid[q] < 0) continue; if ((cid[q] == r) != (Q.cid[q] == s)) return false; } }
    return true;
  }
};

// playout policy legality for color c at an empty i: not the mover's own single point eye, not classical suicide
// (the classical read of the display: q-stones are occupied, neither own nor opposite; a standing libertyless
// opposite chain counts as captured by the placement, as in the slow classicalSuicide)
// SGO_EYEDEF=1: an own single-point eye is a policy move when an adjacent own chain has that point as its only liberty,
// i.e. when the opponent could capture by playing there — in SGo the ko / snapback defense is to play that point too
static bool g_eyedef = false;
static bool legalPolicy(const Board& bd, const Pos& P, int c, int i) {
  bool eye = true, lib = false;
  for (int a = 0; a < bd.nnb[i]; a++) { int k = P.D.kind[bd.nbr[i][a]]; if (k != c) eye = false; if (k == EMPTY) lib = true; }
  if (eye) { if (!g_eyedef) return false; for (int a = 0; a < bd.nnb[i]; a++) if (P.onlyLibIs(P.cid[bd.nbr[i][a]], i)) return true; return false; }
  if (lib) return true;
  for (int a = 0; a < bd.nnb[i]; a++) { int q = bd.nbr[i][a]; int k = P.D.kind[q]; int r = P.cid[q];
    if (k == opp(c)) { if (P.plib[r] == 0 || P.onlyLibIs(r, i)) return true; }
    else if (k == c) { if (P.plib[r] > 0 && !P.atari(r)) return true; } }
  return false;
}
static int policyMovesF(const Board& bd, const Pos& P, int c, int koPoint, int* out) {
  int k = 0;
  for (int i = 0; i < bd.N; i++) if (P.D.kind[i] == EMPTY && i != koPoint && legalPolicy(bd, P, c, i)) out[k++] = i;
  return k;
}
// a uniformly random policy move (the empty intersections are sampled without replacement until a legal one is
// found; the first legal one found is uniform over the legal ones), -1 = pass when none
static int randomMoveF(const Board& bd, const Pos& P, int c, int ko, Rng& rng) {
  if (P.nemp == 0) return -1;
  for (int tries = 0; tries < 6; tries++) { int i = P.emp[rng.below(P.nemp)]; if (i != ko && legalPolicy(bd, P, c, i)) return i; } // with replacement: each success is uniform over the legal moves
  int cand[MAXC]; int k = 0;
  for (int u = 0; u < P.nemp; u++) if (P.emp[u] != ko) cand[k++] = P.emp[u];
  while (k > 0) { int j = rng.below(k); int i = cand[j]; cand[j] = cand[--k]; if (legalPolicy(bd, P, c, i)) return i; }
  return -1;
}
// the slow policy, kept for the differential test
static bool ownEye(const Board& bd, const Display& D, int c, int i) {
  for (int a = 0; a < bd.nnb[i]; a++) if (D.kind[bd.nbr[i][a]] != c) return false;
  return true;
}
static bool classicalSuicide(const Board& bd, const Display& Dc_, int c, int i) {
  for (int a = 0; a < bd.nnb[i]; a++) if (Dc_.kind[bd.nbr[i][a]] == EMPTY) return false;
  Display& D = const_cast<Display&>(Dc_); // the stone is placed and removed again: D is unchanged on return
  D.kind[i] = c; Comp cc; bool r = true;
  for (int a = 0; a < bd.nnb[i] && r; a++) { int q = bd.nbr[i][a]; if (D.kind[q] == opp(c)) { component(bd, D, q, cc); if (noLib(bd, D, cc)) r = false; } }
  if (r) { component(bd, D, i, cc); r = noLib(bd, D, cc); }
  D.kind[i] = EMPTY; return r;
}
static int policyMoves(const Board& bd, const Display& D, int c, int koPoint, int* out) {
  int k = 0;
  for (int i = 0; i < bd.N; i++) { if (D.kind[i] != EMPTY || i == koPoint) continue; if (ownEye(bd, D, c, i)) continue; if (classicalSuicide(bd, D, c, i)) continue; out[k++] = i; }
  return k;
}

// ---------- the SGo resolution on a Pos ----------
// def_trapped / def_captured read through the chain table (a chain is the same-kind component through any of its
// stones; noLib is plib == 0).  Mirrors isCaptured / trappedOnTurn / stoneTrappedBy above clause by clause.
static int maxStampAround(const Board& bd, const Pos& P, int r, int mark, int16_t* seen) { // largest stamp among the chain r and the stones adjacent to it; seen[cell] = mark marks the chain
  int mxv = 0; int s = r; do { seen[s] = mark; s = P.nxt[s]; } while (s != r);
  s = r; do { if (P.D.stamp[s] > mxv) mxv = P.D.stamp[s];
    for (int a = 0; a < bd.nnb[s]; a++) { int q = bd.nbr[s][a]; if (P.D.kind[q] != EMPTY && seen[q] != mark && P.D.stamp[q] > mxv) mxv = P.D.stamp[q]; }
    s = P.nxt[s]; } while (s != r);
  return mxv;
}
static bool trappedOnTurnF(const Board& bd, const Pos& P, int r, int t, int mark, int16_t* seen) {
  if (P.plib[r] != 0) return false;
  return maxStampAround(bd, P, r, mark, seen) == t;
}
// "trapped by attacker on turn t" for the stone z: a q-stone read as the defender's color (its component is then
// z together with the defender chains adjacent to z)
static bool stoneTrappedByF(const Board& bd, const Pos& P, int z, int attacker, int t, int mark, int16_t* seen) {
  int defender = opp(attacker);
  if (P.D.kind[z] == defender) return trappedOnTurnF(bd, P, P.cid[z], t, mark, seen);
  if (P.D.kind[z] != R) return false;
  // liberties: z has no empty neighbour and every adjacent defender chain has none
  for (int a = 0; a < bd.nnb[z]; a++) { int q = bd.nbr[z][a]; if (P.D.kind[q] == EMPTY) return false; if (P.D.kind[q] == defender && P.plib[P.cid[q]] != 0) return false; }
  // the union: z and the adjacent defender chains; then the largest stamp over it and its neighbours
  seen[z] = mark; int mxv = P.D.stamp[z];
  for (int a = 0; a < bd.nnb[z]; a++) { int q = bd.nbr[z][a]; if (P.D.kind[q] == defender && seen[q] != mark) { int r = P.cid[q]; int s = r; do { seen[s] = mark; s = P.nxt[s]; } while (s != r); } }
  for (int a = 0; a < bd.nnb[z]; a++) { int q = bd.nbr[z][a]; if (P.D.kind[q] != EMPTY && seen[q] != mark && P.D.stamp[q] > mxv) mxv = P.D.stamp[q]; }
  for (int a = 0; a < bd.nnb[z]; a++) { int q = bd.nbr[z][a]; if (P.D.kind[q] != defender) continue; int r = P.cid[q]; int s = r;
    do { if (P.D.stamp[s] > mxv) mxv = P.D.stamp[s];
      for (int b = 0; b < bd.nnb[s]; b++) { int u = bd.nbr[s][b]; if (P.D.kind[u] != EMPTY && seen[u] != mark && P.D.stamp[u] > mxv) mxv = P.D.stamp[u]; }
      s = P.nxt[s]; } while (s != r); }
  return mxv == t;
}
static bool g_dbg = false;
static bool isCapturedF(const Board& bd, const Pos& P, int rep, int c, int t) {
  static int16_t seen[MAXC]; static int markCounter = 0; // scratch marks (single-threaded)
  // a call uses at most 2 + 2*MAXC marks; the array is cleared only here, never in the middle of a call
  if (markCounter > 30000 - 2 * MAXC - 8) { memset(seen, 0, sizeof(seen)); markCounter = 0; }
  auto fresh = [&]() { return ++markCounter; };
  int m0 = fresh();
  if (!trappedOnTurnF(bd, P, rep, t, m0, seen)) { if (g_dbg) fprintf(stderr, "F: not trapped on turn\n"); return false; } // (1); seen == m0 marks the chain now
  // adjacent stones (occupied, outside the chain), deduplicated
  int adj[MAXC]; int nadj = 0; int m1 = fresh();
  { int s = rep; do { for (int a = 0; a < bd.nnb[s]; a++) { int q = bd.nbr[s][a]; if (P.D.kind[q] != EMPTY && seen[q] != m0 && seen[q] != m1) { seen[q] = m1; adj[nadj++] = q; } } s = P.nxt[s]; } while (s != rep); }
  // (2) cond_unambiguous0: a q-stone adjacent to C adjacent to another trapped component ⇒ that component has C's color
  for (int u = 0; u < nadj; u++) { int r = adj[u]; if (P.D.kind[r] != R) continue;
    for (int b = 0; b < bd.nnb[r]; b++) { int z = bd.nbr[r][b]; int k = P.D.kind[z]; if (k != B && k != W) continue;
      if (P.cid[z] != rep && P.plib[P.cid[z]] == 0 && k != c) { if (g_dbg) fprintf(stderr, "F: cond 2 fails at %d\n", z); return false; } } }
  // (3a)
  bool a3 = true;
  for (int u = 0; u < nadj && a3; u++) { int z = adj[u]; int k = P.D.kind[z];
    if ((k == opp(c) || k == R) && stoneTrappedByF(bd, P, z, c, t, fresh(), seen)) a3 = false; }
  if (g_dbg) { fprintf(stderr, "F: nadj=%d:", nadj); for (int u = 0; u < nadj; u++) fprintf(stderr, " %d", adj[u]); fprintf(stderr, " a3=%d\n", a3); }
  if (a3) return true;
  // (3b) suicidal capture: no stone of C created this turn; every adjacent stone trapped on this turn lies in a
  // component containing a stone created this turn that is not a q-stone (SGO_SIMP drops the q-stone clause)
  { int s = rep; do { if (P.D.stamp[s] == t) { if (g_dbg) fprintf(stderr, "F: fresh stone in C at %d\n", s); return false; } s = P.nxt[s]; } while (s != rep); }
  for (int u = 0; u < nadj; u++) { int z = adj[u]; int r = P.cid[z];
    bool tr = trappedOnTurnF(bd, P, r, t, fresh(), seen);
    if (g_dbg) fprintf(stderr, "F: 3b z=%d chain %d trapped=%d\n", z, r, tr);
    if (tr) {
      bool fr = false; int s = r; do { if (P.D.stamp[s] == t && (g_simp || P.D.kind[s] != R)) { fr = true; break; } s = P.nxt[s]; } while (s != r);
      if (!fr) { if (g_dbg) fprintf(stderr, "F: 3b fails at z=%d\n", z); return false; } } }
  return true;
}
// the basic capture reduction at turn t: evaluates def_captured on the libertyless black and white chains (the
// only candidates: condition 1 needs no liberties), then removes and recolors as the printed rule says
static bool g_check = false; // SGO_CHECK=1: cross-check the chain-table evaluation against the slow isCaptured at every turn
static void checkCaptured(const Board& bd, const Pos& P, int t) {
  Comp comp;
  for (int p = 0; p < bd.N; p++) { if (P.cid[p] != p) continue; int k = P.D.kind[p]; if ((k != B && k != W) || P.plib[p] != 0) continue;
    comp.sz = 0; memset(comp.mark, 0, bd.N); int s = p; do { comp.cells[comp.sz++] = s; comp.mark[s] = true; s = P.nxt[s]; } while (s != p);
    bool slow = isCaptured(bd, P.D, comp, k, t); bool fast = P.mx[p] >= t && isCapturedF(bd, P, p, k, t);
    if (slow != fast) { fprintf(stderr, "CHECK FAILED: chain at %d kind %d stage %d slow=%d fast=%d (mx=%d)\n", p, k, t, slow, fast, P.mx[p]);
      int n = bd.n; for (int x = 0; x < n; x++) { for (int y = 0; y < n; y++) { int i = x * n + y; if (P.D.kind[i]) fprintf(stderr, "%c%-4d", ".bwr"[P.D.kind[i]], P.D.stamp[i]); else fprintf(stderr, ".    "); } fprintf(stderr, "\n"); }
      // clause by clause
      static int16_t seen[MAXC]; int mk = 1; memset(seen, 0, sizeof(seen));
      fprintf(stderr, "slow trappedOnTurn=%d fast=%d\n", trappedOnTurn(bd, P.D, comp, t), trappedOnTurnF(bd, P, p, t, mk++, seen));
      for (int u = 0; u < comp.sz; u++) { int q = comp.cells[u]; for (int a = 0; a < bd.nnb[q]; a++) { int z = bd.nbr[q][a]; if (P.D.kind[z] == EMPTY || comp.mark[z]) continue;
        Comp tmp; bool sl = stoneTrappedBy(bd, P.D, z, k, t, tmp); bool fs = stoneTrappedByF(bd, P, z, k, t, mk++, seen);
        Comp dc; component(bd, P.D, z, dc); bool sl2 = trappedOnTurn(bd, P.D, dc, t); bool fs2 = trappedOnTurnF(bd, P, P.cid[z], t, mk++, seen);
        fprintf(stderr, "adj z=%d kind %d: stoneTrappedBy slow=%d fast=%d; trappedOnTurn(comp z) slow=%d fast=%d; plib=%d\n", z, P.D.kind[z], sl, fs, sl2, fs2, P.plib[P.cid[z]]); } }
      g_dbg = true; isCapturedF(bd, P, p, k, t); exit(3); } }
}
static bool basicCapF(const Board& bd, Pos& P, int t) {
  if (g_check) checkCaptured(bd, P, t);
  // candidates: libertyless black / white chains whose stamp bound reaches t (trapped on turn t needs the largest stamp == t)
  if (P.nz == 0) return false;
  int cand[MAXC]; int ncand = 0;
  for (int u = 0; u < P.nz; u++) { int p = P.zlist[u]; if (P.mx[p] < t) continue; int k = P.D.kind[p]; if (k == B || k == W) cand[ncand++] = p; }
  if (ncand == 0) return false;
  int reps[MAXC]; int nr = 0;
  for (int u0 = 0; u0 < ncand; u0++) { int p = cand[u0]; if (isCapturedF(bd, P, p, P.D.kind[p], t)) reps[nr++] = p; }
  if (nr == 0) return false;
  bool capB[MAXC], capW[MAXC]; memset(capB, 0, bd.N); memset(capW, 0, bd.N);
  for (int u = 0; u < nr; u++) { int p = reps[u]; int k = P.D.kind[p]; int s = p; do { (k == B ? capB : capW)[s] = true; s = P.nxt[s]; } while (s != p); }
  int rec[MAXC], reck[MAXC]; int nrec = 0; // q-stones adjacent to a captured white chain resolve black, else adjacent to a captured black chain white
  for (int p = 0; p < bd.N; p++) { if (P.D.kind[p] != R) continue; bool aw = false, ab = false;
    for (int a = 0; a < bd.nnb[p]; a++) { int q = bd.nbr[p][a]; if (capW[q]) aw = true; if (capB[q]) ab = true; }
    if (aw) { rec[nrec] = p; reck[nrec++] = B; } else if (ab) { rec[nrec] = p; reck[nrec++] = W; } }
  for (int u = 0; u < nr; u++) P.removeChain(bd, reps[u], nullptr, nullptr);
  if (nrec) { for (int u = 0; u < nrec; u++) P.recolor(rec[u], reck[u]); P.rebuild(bd); }
  return true;
}
static bool capFixF(const Board& bd, Pos& P, int t) {
  bool any = false;
  for (int fuel = 0; fuel <= bd.N; fuel++) { if (!basicCapF(bd, P, t)) break; any = true; }
  return any;
}
static bool g_nocap = false; // SGO_NOCAP=1: the objective reduction disabled (placement only)
static bool g_koStats = false; // SGO_KO=1: the fiat simple ko in the statistics modes (table, eqplay, greedygo)
static int g_depth = 0, g_qCreated = 0; // per-turn depth (stages that changed the display) and q-stones created, read by the statistics
static void resolveTurnF(const Board& bd, Pos& P, int t, int m0, int m1) {
  g_log.nrem = 0; g_log.nrec = 0; g_depth = 0;
  if (m0 >= 0 && m1 >= 0) { if (m0 == m1) { int k = conflictKind(P.D, m0); if (k == R) g_qCreated++; P.place(bd, m0, k, t); } else { P.place(bd, m0, B, t); P.place(bd, m1, W, t); } }
  else if (m0 >= 0) P.place(bd, m0, B, t);
  else if (m1 >= 0) P.place(bd, m1, W, t);
  if (g_nocap) return;
  for (int s = t; s >= 1; s--) { if (!capFixF(bd, P, s)) return; g_depth++; }
}
// one classical move on a Pos (goMove's semantics: captures, then suicide)
static bool goMoveF(const Board& bd, Pos& P, int color, int i, int* ncap, int* capPoint) {
  if (P.D.kind[i] != EMPTY) return false;
  g_log.nrem = 0; g_log.nrec = 0;
  int rep = P.place(bd, i, color, 0);
  int removed[MAXC]; int nrem = 0, cp = -1;
  for (int a = 0; a < bd.nnb[i]; a++) { int q = bd.nbr[i][a]; if (P.D.kind[q] == opp(color) && P.plib[P.cid[q]] == 0) { int before = nrem; P.removeChain(bd, P.cid[q], removed, &nrem); cp = removed[before]; } }
  if (P.plib[rep] == 0) P.removeChain(bd, rep, nullptr, nullptr);
  if (ncap) *ncap = nrem; if (capPoint) *capPoint = (nrem == 1 ? cp : -1);
  return true;
}

// ---------- the entanglement (SgoSerial.lean): branches, the serialization map P, Sim(Go) evolution, pruning ----------
// A branch is a classical diagram, kept as a Display with zero stamps.  Not used by the agents: game-level bookkeeping
// for the statistics (q-stones, branch counts), validated against the Lean serial sheet (entsS column).
struct Ent { std::vector<Display> b; bool defined = true; };
static bool sameKinds(const Display& x, const Display& y, int N) { for (int i = 0; i < N; i++) if (x.kind[i] != y.kind[i]) return false; return true; }
static void pushDedup(std::vector<Display>& v, const Display& d, int N) { for (auto& e : v) if (sameKinds(e, d, N)) return; v.push_back(d); }
// one # step: pass changes nothing; a move is goMove (none if the intersection is occupied)
static bool bStep(const Board& bd, Display& d, int c, int m) { if (m < 0) return true; if (d.kind[m] != EMPTY) return false; goMove(bd, d, c, m, nullptr, nullptr); return true; }
static bool bStep2(const Board& bd, Display d, int c0, int c1, int x0, int x1, Display& out) { if (!bStep(bd, d, c0, x0)) return false; if (!bStep(bd, d, c1, x1)) return false; out = d; return true; }
// the serialization map P (the four priority cases of serialP); false = undefined
static bool serialP(const Board& bd, const Display& a, int m0, int m1, std::vector<Display>& out) {
  int N = bd.N; Display x, y; bool hx = bStep2(bd, a, B, W, m0, m1, x), hy = bStep2(bd, a, W, B, m1, m0, y);
  out.clear();
  if (hx && hy) { pushDedup(out, x, N); pushDedup(out, y, N); return true; }
  if (hx) { Display y2 = a; if (!bStep(bd, y2, W, m1)) return false; pushDedup(out, x, N); pushDedup(out, y2, N); return true; }
  if (hy) { Display x2 = a; if (!bStep(bd, x2, B, m0)) return false; pushDedup(out, x2, N); pushDedup(out, y, N); return true; }
  Display x3 = a, y3 = a; if (!bStep(bd, x3, B, m0) || !bStep(bd, y3, W, m1)) return false;
  pushDedup(out, x3, N); pushDedup(out, y3, N); return true;
}
static bool compatibleB(const Board& bd, const Display& D, const Display& b) {
  for (int i = 0; i < bd.N; i++) { int k = b.kind[i]; if (k == EMPTY) continue; int dk = D.kind[i]; if (dk == EMPTY) return false; if (dk != R && dk != k) return false; }
  return true;
}
// E_SGo on the entanglement: Sim(Go) evolution (union of the P's, deduplicated), then the pruning by the resolved display
static void entStep(const Board& bd, Ent& E, const Display& Dafter, int m0, int m1) {
  if (!E.defined) return;
  std::vector<Display> all, part;
  for (auto& a : E.b) { if (!serialP(bd, a, m0, m1, part)) { E.defined = false; return; } for (auto& d : part) pushDedup(all, d, bd.N); }
  E.b.clear(); for (auto& d : all) if (compatibleB(bd, Dafter, d)) E.b.push_back(d);
}
static void entInit(Ent& E, int N) { E.b.clear(); Display d; d.clear(N); E.b.push_back(d); E.defined = true; }

// ---------- play ----------
struct SGoGame {
  Pos P; int next; uint64_t prevHash; bool ended; int koB, koW; // ko points for Black / White (fiat rule), -1 none
  void init(int N) { P.clear(N); prevHash = ~0ULL; next = 1; ended = false; koB = koW = -1; }
};
static int singleLiberty(const Board& bd, const Pos& P, int i) { // the one empty neighbour of i, or -1 if not exactly one
  int libs = 0, lib = -1; for (int a = 0; a < bd.nnb[i]; a++) if (P.D.kind[bd.nbr[i][a]] == EMPTY) { libs++; lib = bd.nbr[i][a]; }
  return libs == 1 ? lib : -1;
}
// one SGo turn with the printed end rules (+ cap) and the optional fiat ko
static void sgoTurn(const Board& bd, const Opts& o, SGoGame& g, int m0, int m1) {
  uint64_t h0 = g.P.hash; int turn = g.next;
  Display before; if (g_check) before = g.P.D;
  resolveTurnF(bd, g.P, turn, m0, m1);
  // fiat ko: a player whose single stone at j was removed this turn, by a turn on which the opponent placed a single
  // classical stone that now stands alone with j as its only liberty, may not play j next turn.  "Removed" is read
  // as the slow engine read it off the displays: a stone of that color before the turn and not after — so a stone
  // placed this turn, or a q-stone recolored this turn, does not count.
  g.koB = g.koW = -1;
  if (o.ko) {
    int remB = 0, remW = 0, jB = -1, jW = -1;
    for (int u = 0; u < g_log.nrem; u++) { int c = g_log.remCell[u]; if (g_log.remStamp[u] == turn) continue;
      bool rec = false; for (int v = 0; v < g_log.nrec && !rec; v++) if (g_log.recCell[v] == c) rec = true; if (rec) continue;
      if (g_log.remKind[u] == B) { remB++; if (c > jB) jB = c; } else if (g_log.remKind[u] == W) { remW++; if (c > jW) jW = c; } }
    if (g_check) { int rb = 0, rw = 0, xb = -1, xw = -1;
      for (int p = 0; p < bd.N; p++) { if (before.kind[p] == B && g.P.D.kind[p] != B) { rb++; xb = p; } if (before.kind[p] == W && g.P.D.kind[p] != W) { rw++; xw = p; } }
      if (rb != remB || rw != remW || xb != jB || xw != jW) { fprintf(stderr, "CHECK FAILED: removal log %d/%d %d/%d j %d/%d %d/%d\n", rb, remB, rw, remW, xb, jB, xw, jW); exit(3); } }
    if (remB == 1 && m1 >= 0 && m1 != m0 && g.P.D.kind[m1] == W && g.P.nst[g.P.cid[m1]] == 1 && singleLiberty(bd, g.P, m1) == jB) g.koB = jB;
    if (remW == 1 && m0 >= 0 && m0 != m1 && g.P.D.kind[m0] == B && g.P.nst[g.P.cid[m0]] == 1 && singleLiberty(bd, g.P, m0) == jW) g.koW = jW;
  }
  g.next++;
  // end rules: display unchanged after each of two consecutive turns; no empty intersection; cap
  bool unchanged2 = (g.P.hash == h0) && (h0 == g.prevHash);
  if (g_check && (unchanged2 != ((g.P.D == before) && g.prevHash == h0))) { fprintf(stderr, "CHECK FAILED: unchanged rule\n"); exit(3); }
  g.prevHash = h0;
  bool full = (g.P.nemp == 0);
  bool doublePass = (m0 < 0 && m1 < 0); // the formal finality: a double pass turn ends the game
  if (doublePass || unchanged2 || full || g.next > o.cap) g.ended = true;
}
// random continuation from a state; returns black margin
static int sgoPlayout(const Board& bd, const Opts& o, SGoGame g, Rng& rng) {
  int steps = 0;
  while (!g.ended && (o.pdepth == 0 || steps < o.pdepth)) { int m0 = randomMoveF(bd, g.P, B, g.koB, rng), m1 = randomMoveF(bd, g.P, W, g.koW, rng); sgoTurn(bd, o, g, m0, m1); steps++; }
  return areaMargin(bd, g.P.D);
}
// MC agent for SGo: menu of five policy moves, B playouts each with a random opponent, best mean margin
static int sgoAgent(const Board& bd, const Opts& o, const SGoGame& g, int c, int budget, Rng& rng) {
  int mv[MAXC]; int k = policyMovesF(bd, g.P, c, c == B ? g.koB : g.koW, mv);
  if (k == 0) return -1;
  for (int i = 0; i < k; i++) { int j = i + rng.below(k - i); std::swap(mv[i], mv[j]); } // random menu of up to five
  int menu = k < 5 ? k : 5;
  if (budget == 0) return mv[rng.below(menu)];
  double best = -1e9; int bestMv = mv[0]; int sign = (c == B ? 1 : -1);
  for (int m = 0; m < menu; m++) {
    double tot = 0;
    for (int r = 0; r < budget; r++) {
      SGoGame g2 = g; int om = randomMoveF(bd, g2.P, opp(c), c == B ? g2.koW : g2.koB, rng);
      sgoTurn(bd, o, g2, c == B ? mv[m] : om, c == B ? om : mv[m]);
      tot += sign * sgoPlayout(bd, o, g2, rng);
    }
    double mean = tot / budget;
    if (mean > best + 1e-9 || (std::fabs(mean - best) <= 1e-9 && rng.below(2))) { best = mean; bestMv = mv[m]; }
  }
  return bestMv;
}

// classical Go game state
struct GoGame { Pos P; int toMove; int passes; bool ended; int ko; int turns; void init(int N) { P.clear(N); toMove = B; passes = 0; ended = false; ko = -1; turns = 0; } };
static void goTurn(const Board& bd, const Opts& o, GoGame& g, int m) {
  g.turns++;
  if (m < 0) { g.passes++; g.ko = -1; if (g.passes >= 2) g.ended = true; }
  else { int nc, cp; goMoveF(bd, g.P, g.toMove, m, &nc, &cp); g.passes = 0; g.ko = -1;
    if (o.ko && nc == 1 && g.P.D.kind[m] != EMPTY && g.P.nst[g.P.cid[m]] == 1 && singleLiberty(bd, g.P, m) == cp) g.ko = cp; }
  g.toMove = opp(g.toMove);
  if (g.turns >= o.cap) g.ended = true;
}
static double goMarginB(const Board& bd, const Opts& o, const Display& D) { return areaMargin(bd, D) - o.komi; }
static double goPlayout(const Board& bd, const Opts& o, GoGame g, Rng& rng) {
  int steps = 0;
  while (!g.ended && (o.pdepth == 0 || steps < o.pdepth)) { int m = randomMoveF(bd, g.P, g.toMove, g.ko, rng); goTurn(bd, o, g, m); steps++; }
  return goMarginB(bd, o, g.P.D);
}
// SGO_SUPERKO=1: positional superko for the actual Go games of match mode — a move that recreates an earlier
// whole-board position of the game is illegal (passes are always legal); the playouts keep the simple ko.  The
// agent's random menu of five is drawn from the moves legal under superko (hist = the positions of the game so far).
static bool g_superko = false;
static int goAgent(const Board& bd, const Opts& o, const GoGame& g, int budget, Rng& rng, const std::unordered_set<uint64_t>* hist = nullptr) {
  int c = g.toMove; int mv[MAXC]; int k = policyMovesF(bd, g.P, c, g.ko, mv);
  for (int i = 0; i < k; i++) { int j = i + rng.below(k - i); std::swap(mv[i], mv[j]); }
  if (hist) { int kept = 0; for (int i = 0; i < k && kept < 5; i++) { GoGame g2 = g; goTurn(bd, o, g2, mv[i]); if (hist->count(g2.P.hash)) continue; mv[kept++] = mv[i]; } k = kept; }
  if (k == 0) return -1;
  int menu = k < 5 ? k : 5;
  if (budget == 0) return mv[rng.below(menu)];
  double best = -1e9; int bestMv = mv[0]; int sign = (c == B ? 1 : -1);
  for (int m = 0; m < menu; m++) {
    double tot = 0;
    for (int r = 0; r < budget; r++) { GoGame g2 = g; goTurn(bd, o, g2, mv[m]); tot += sign * goPlayout(bd, o, g2, rng); }
    double mean = tot / budget;
    if (mean > best + 1e-9 || (std::fabs(mean - best) <= 1e-9 && rng.below(2))) { best = mean; bestMv = mv[m]; }
  }
  return bestMv;
}

// a game between budgets bb (Black) and bw (White); returns black margin and stats
struct GameRes { double margin; int turns; };
static GameRes playSGo(const Board& bd, const Opts& o, int bb, int bw, Rng& rng) {
  SGoGame g; g.init(bd.N);
  while (!g.ended) { int m0 = sgoAgent(bd, o, g, B, bb, rng); int m1 = sgoAgent(bd, o, g, W, bw, rng); sgoTurn(bd, o, g, m0, m1); }
  return { (double)areaMargin(bd, g.P.D), g.next - 1 };
}
static GameRes playGo(const Board& bd, const Opts& o, int bb, int bw, Rng& rng) {
  GoGame g; g.init(bd.N); std::unordered_set<uint64_t> hist; if (g_superko) hist.insert(g.P.hash);
  while (!g.ended) { int m = goAgent(bd, o, g, g.toMove == B ? bb : bw, rng, g_superko ? &hist : nullptr); goTurn(bd, o, g, m);
    if (g_superko && m >= 0) { if (hist.count(g.P.hash)) { fprintf(stderr, "SUPERKO VIOLATED\n"); exit(3); } hist.insert(g.P.hash); } }
  return { goMarginB(bd, o, g.P.D), g.turns };
}

// ---------- statistics of a game (the tables of sgo.tex) ----------
struct GStats { double margin = 0; int turns = 0; bool own = false; int qCreated = 0, qFinal = 0, peakDepth = 0, peakBranches = 0, finalBranches = 0; };
static int countKind(const Display& D, int N, int k) { int c = 0; for (int i = 0; i < N; i++) if (D.kind[i] == k) c++; return c; }
// uniformly random play over all legal (= empty) intersections, passing only when none (the convention of §2.2)
static int uniformMove(const Board& bd, const Display& D, Rng& rng) { int emp[MAXC], k = 0; for (int i = 0; i < bd.N; i++) if (D.kind[i] == EMPTY) emp[k++] = i; return k ? emp[rng.below(k)] : -1; }
static GStats randomSGo(const Board& bd, const Opts& o, Rng& rng, bool branches) {
  SGoGame g; g.init(bd.N); Ent E; if (branches) entInit(E, bd.N); GStats st; st.peakBranches = st.finalBranches = 1;
  while (!g.ended) { int m0 = uniformMove(bd, g.P.D, rng), m1 = uniformMove(bd, g.P.D, rng); int q0 = g_qCreated; if (g_divlog && m0 >= 0 && m0 == m1) g_confClass[conflictClass(g.P.D, m0)]++; sgoTurn(bd, o, g, m0, m1); st.qCreated += g_qCreated - q0;
    if (g_depth > st.peakDepth) st.peakDepth = g_depth;
    if (branches) { entStep(bd, E, g.P.D, m0, m1); if ((int)E.b.size() > st.peakBranches) st.peakBranches = E.b.size(); } }
  st.turns = g.next - 1; st.own = (st.turns < o.cap); st.margin = areaMargin(bd, g.P.D); st.qFinal = countKind(g.P.D, bd.N, R);
  if (branches) st.finalBranches = E.b.size();
  return st;
}
static GStats randomGo(const Board& bd, const Opts& o, Rng& rng) { // o.cap in plies
  GoGame g; g.init(bd.N); GStats st;
  while (!g.ended) { int m = uniformMove(bd, g.P.D, rng); goTurn(bd, o, g, m); }
  st.turns = g.turns; st.own = (g.turns < o.cap); st.margin = goMarginB(bd, o, g.P.D); return st;
}
// a 2-player zero-sum matrix game: Black (rows) maximizes M; returns the value and the optimal mixed strategies
// (dual simplex on M shifted positive, Bland's rule; m, n <= 5)
static double solveZeroSum(const double M[5][5], int m, int n, double* x, double* y) {
  double mn = 1e18; for (int i = 0; i < m; i++) for (int j = 0; j < n; j++) mn = std::min(mn, M[i][j]);
  double c = 1.0 - mn; // M' = M + c >= 1 > 0
  // dual: max sum y_j  s.t.  sum_j M'[i][j] y_j <= 1 (i < m), y >= 0.  Tableau: m rows, n + m columns + rhs.
  const int MC = 12; double T[6][MC]; int basis[5]; int cols = n + m;
  for (int i = 0; i < m; i++) { for (int j = 0; j < n; j++) T[i][j] = M[i][j] + c; for (int k = 0; k < m; k++) T[i][n + k] = (i == k); T[i][cols] = 1.0; basis[i] = n + i; }
  // objective row: maximize sum y  ->  z - sum y = 0; store reduced costs r_j (we maximize: enter while some r_j < 0)
  double obj[MC]; for (int j = 0; j < cols; j++) obj[j] = (j < n) ? -1.0 : 0.0; obj[cols] = 0.0;
  for (int it = 0; it < 200; it++) {
    int e = -1; for (int j = 0; j < cols; j++) if (obj[j] < -1e-12) { e = j; break; } // Bland: lowest index
    if (e < 0) break;
    int l = -1; double best = 1e18; for (int i = 0; i < m; i++) if (T[i][e] > 1e-12) { double r = T[i][cols] / T[i][e]; if (r < best - 1e-12 || (std::fabs(r - best) <= 1e-12 && basis[i] < basis[l])) { best = r; l = i; } }
    if (l < 0) break; // unbounded (cannot happen: M' > 0)
    double p = T[l][e]; for (int j = 0; j <= cols; j++) T[l][j] /= p;
    for (int i = 0; i < m; i++) if (i != l && std::fabs(T[i][e]) > 1e-15) { double f = T[i][e]; for (int j = 0; j <= cols; j++) T[i][j] -= f * T[l][j]; }
    { double f = obj[e]; for (int j = 0; j <= cols; j++) obj[j] -= f * T[l][j]; }
    basis[l] = e;
  }
  double ys[5] = {0, 0, 0, 0, 0}; for (int i = 0; i < m; i++) if (basis[i] < n) ys[basis[i]] = T[i][cols];
  double xs[5]; for (int i = 0; i < m; i++) xs[i] = obj[n + i]; // the duals = reduced costs of the slacks
  double sy = 0, sx = 0; for (int j = 0; j < n; j++) sy += ys[j]; for (int i = 0; i < m; i++) sx += xs[i];
  if (sy <= 1e-12 || sx <= 1e-12) { for (int i = 0; i < m; i++) x[i] = 1.0 / m; for (int j = 0; j < n; j++) y[j] = 1.0 / n; return 0; }
  for (int j = 0; j < n; j++) y[j] = ys[j] / sy; for (int i = 0; i < m; i++) x[i] = std::max(0.0, xs[i]) / sx;
  return 1.0 / sy - c;
}
// the same solver for a matrix of any size (vectors); used by the exact solver of pos mode
static double solveZeroSumG(const std::vector<std::vector<double>>& M, std::vector<double>& x, std::vector<double>& y) {
  int m = M.size(), n = M[0].size(); x.assign(m, 0); y.assign(n, 0);
  double mn = 1e18; for (int i = 0; i < m; i++) for (int j = 0; j < n; j++) mn = std::min(mn, M[i][j]);
  double c = 1.0 - mn; int cols = n + m;
  std::vector<std::vector<double>> T(m, std::vector<double>(cols + 1)); std::vector<int> basis(m);
  for (int i = 0; i < m; i++) { for (int j = 0; j < n; j++) T[i][j] = M[i][j] + c; for (int k = 0; k < m; k++) T[i][n + k] = (i == k); T[i][cols] = 1.0; basis[i] = n + i; }
  std::vector<double> obj(cols + 1); for (int j = 0; j < cols; j++) obj[j] = (j < n) ? -1.0 : 0.0; obj[cols] = 0.0;
  for (int it = 0; it < 2000; it++) {
    int e = -1; for (int j = 0; j < cols; j++) if (obj[j] < -1e-12) { e = j; break; }
    if (e < 0) break;
    int l = -1; double best = 1e18; for (int i = 0; i < m; i++) if (T[i][e] > 1e-12) { double r = T[i][cols] / T[i][e]; if (r < best - 1e-12 || (std::fabs(r - best) <= 1e-12 && basis[i] < basis[l])) { best = r; l = i; } }
    if (l < 0) break;
    double p = T[l][e]; for (int j = 0; j <= cols; j++) T[l][j] /= p;
    for (int i = 0; i < m; i++) if (i != l && std::fabs(T[i][e]) > 1e-15) { double f = T[i][e]; for (int j = 0; j <= cols; j++) T[i][j] -= f * T[l][j]; }
    { double f = obj[e]; for (int j = 0; j <= cols; j++) obj[j] -= f * T[l][j]; }
    basis[l] = e;
  }
  std::vector<double> ys(n, 0.0), xs(m, 0.0); for (int i = 0; i < m; i++) if (basis[i] < n) ys[basis[i]] = T[i][cols];
  for (int i = 0; i < m; i++) xs[i] = obj[n + i];
  double sy = 0, sx = 0; for (int j = 0; j < n; j++) sy += ys[j]; for (int i = 0; i < m; i++) sx += xs[i];
  if (sy <= 1e-12 || sx <= 1e-12) { for (int i = 0; i < m; i++) x[i] = 1.0 / m; for (int j = 0; j < n; j++) y[j] = 1.0 / n; return 0; }
  for (int j = 0; j < n; j++) y[j] = ys[j] / sy; for (int i = 0; i < m; i++) x[i] = std::max(0.0, xs[i]) / sx;
  return 1.0 / sy - c;
}
// exact value of a position to a horizon: every empty point and the pass for both sides, the matrix game of the
// continuation values (recursively), memoized on the full state (display with stamps, previous hash, turn)
static std::unordered_map<std::string, double> g_solveMemo; static long g_solveNodes = 0;
static double solveExact(const Board& bd, const Opts& o, const SGoGame& g, int depth, std::vector<int>* mvOut, std::vector<std::vector<double>>* Mout, std::vector<double>* xOut, std::vector<double>* yOut) {
  if (g.ended || depth == 0) return areaMargin(bd, g.P.D);
  std::string key; key.reserve(3 * bd.N + 16);
  for (int i = 0; i < bd.N; i++) { key += (char)g.P.D.kind[i]; key += (char)(g.P.D.stamp[i] & 255); key += (char)(g.P.D.stamp[i] >> 8); }
  key += std::to_string(g.prevHash); key += '|'; key += std::to_string(g.next); key += '|'; key += std::to_string(depth);
  if (!mvOut) { auto it = g_solveMemo.find(key); if (it != g_solveMemo.end()) return it->second; }
  g_solveNodes++;
  std::vector<int> mv; mv.push_back(-1); for (int i = 0; i < bd.N; i++) if (g.P.D.kind[i] == EMPTY) mv.push_back(i);
  int k = mv.size(); std::vector<std::vector<double>> M(k, std::vector<double>(k));
  for (int i = 0; i < k; i++) for (int j = 0; j < k; j++) { SGoGame g2 = g; sgoTurn(bd, o, g2, mv[i], mv[j]); M[i][j] = solveExact(bd, o, g2, depth - 1, nullptr, nullptr, nullptr, nullptr); }
  std::vector<double> x, y; double v = solveZeroSumG(M, x, y);
  if (mvOut) { *mvOut = mv; *Mout = M; *xOut = x; *yOut = y; }
  g_solveMemo[key] = v; return v;
}
static int sampleIdx(const double* p, int k, Rng& rng) { double u = (rng.g() % 1000000) / 1000000.0, acc = 0; for (int i = 0; i < k; i++) { acc += p[i]; if (u < acc) return i; } return k - 1; }
// equilibrium guided play (§7.1): random menus of five, the 5x5 matrix of mean final margins over R policy playouts,
// each player samples an optimal mixed strategy.  Records the fraction of turns without a pure saddle point, the
// within-turn value spread, and the same saddle test at fivefold rollouts on every tenth turn (the control sample).
struct EqStats { long turns = 0, mixed = 0, ctrlTurns = 0, ctrlMixed = 0; double spreadSum = 0; };
static bool pureSaddle(const double M[5][5], int m, int n) {
  double maxmin = -1e18, minmax = 1e18;
  for (int i = 0; i < m; i++) { double mn = 1e18; for (int j = 0; j < n; j++) mn = std::min(mn, M[i][j]); maxmin = std::max(maxmin, mn); }
  for (int j = 0; j < n; j++) { double mx = -1e18; for (int i = 0; i < m; i++) mx = std::max(mx, M[i][j]); minmax = std::min(minmax, mx); }
  return std::fabs(maxmin - minmax) < 1e-9;
}
static void eqMatrix(const Board& bd, const Opts& o, const SGoGame& g, const int* mv0, int k0, const int* mv1, int k1, int Rr, Rng& rng, double M[5][5]) {
  for (int i = 0; i < k0; i++) for (int j = 0; j < k1; j++) { double tot = 0;
    for (int r = 0; r < Rr; r++) { SGoGame g2 = g; sgoTurn(bd, o, g2, mv0[i], mv1[j]); tot += sgoPlayout(bd, o, g2, rng); }
    M[i][j] = tot / Rr; }
}
static void showWindow(const Display& D, int n, int i, int t, int cls, const char* note) {
  int x0 = i / n, y0 = i % n;
  fprintf(stderr, "turn %d conflict at %c%d (class %d%s): rows %d..%d, cols %c..%c\n", t, 'A' + y0, x0 + 1, cls, note, std::max(0, x0 - 2) + 1, std::min(n - 1, x0 + 2) + 1, 'A' + std::max(0, y0 - 2), 'A' + std::min(n - 1, y0 + 2));
  for (int x = std::max(0, x0 - 2); x <= std::min(n - 1, x0 + 2); x++) { fprintf(stderr, "  ");
    for (int y = std::max(0, y0 - 2); y <= std::min(n - 1, y0 + 2); y++) { int j = x * n + y; fprintf(stderr, "%c", j == i ? '*' : ".BWQ"[D.kind[j]]); } fprintf(stderr, "\n"); }
}
static GStats eqGuidedSGo(const Board& bd, const Opts& o, int Rr, Rng& rng, EqStats& eq, bool branches, const SGoGame* start = nullptr) {
  SGoGame g; if (start) g = *start; else g.init(bd.N); Ent E; if (branches) entInit(E, bd.N); GStats st; st.peakBranches = st.finalBranches = 1; long turn = 0;
  while (!g.ended) {
    int all0[MAXC], all1[MAXC]; int n0 = policyMovesF(bd, g.P, B, g.koB, all0), n1 = policyMovesF(bd, g.P, W, g.koW, all1);
    for (int i = 0; i < n0; i++) { int j = i + rng.below(n0 - i); std::swap(all0[i], all0[j]); }
    for (int i = 0; i < n1; i++) { int j = i + rng.below(n1 - i); std::swap(all1[i], all1[j]); }
    int mv0[5], mv1[5]; int k0 = std::min(n0, 5), k1 = std::min(n1, 5);
    for (int i = 0; i < k0; i++) mv0[i] = all0[i]; for (int j = 0; j < k1; j++) mv1[j] = all1[j];
    if (k0 == 0) { mv0[0] = -1; k0 = 1; } if (k1 == 0) { mv1[0] = -1; k1 = 1; } // no policy move: the pass
    double M[5][5]; eqMatrix(bd, o, g, mv0, k0, mv1, k1, Rr, rng, M);
    double x[5], y[5]; solveZeroSum(M, k0, k1, x, y);
    int m0 = mv0[sampleIdx(x, k0, rng)], m1 = mv1[sampleIdx(y, k1, rng)];
    if (k0 > 1 && k1 > 1) { eq.turns++; if (!pureSaddle(M, k0, k1)) eq.mixed++;
      double mx = -1e18, mn = 1e18; for (int i = 0; i < k0; i++) for (int j = 0; j < k1; j++) { mx = std::max(mx, M[i][j]); mn = std::min(mn, M[i][j]); } eq.spreadSum += mx - mn;
      if (turn % 10 == 0) { double M5[5][5]; eqMatrix(bd, o, g, mv0, k0, mv1, k1, 5 * Rr, rng, M5); eq.ctrlTurns++; if (!pureSaddle(M5, k0, k1)) eq.ctrlMixed++; } }
    if (g_divlog && m0 >= 0 && m0 == m1) { int cls = conflictClass(g.P.D, m0); g_confClass[cls]++;
      if (cls == 3 && g_divShown < 12) { g_divShown++; showWindow(g.P.D, o.n, m0, g.next, cls, ", divergent: August gives the local color, December a q-stone"); } }
    int q0 = g_qCreated; sgoTurn(bd, o, g, m0, m1); st.qCreated += g_qCreated - q0; turn++;
    if (g_depth > st.peakDepth) st.peakDepth = g_depth;
    if (branches) { entStep(bd, E, g.P.D, m0, m1); if ((int)E.b.size() > st.peakBranches) st.peakBranches = E.b.size(); }
    if (getenv("SGO_TRACECAP") && g.next > o.cap - 4) { fprintf(stderr, "turn %d moves %d/%d menus %d/%d\n", g.next - 1, m0, m1, k0, k1);
      for (int x = 0; x < o.n; x++) { for (int yy = 0; yy < o.n; yy++) { int i = x * o.n + yy; if (g.P.D.kind[i]) fprintf(stderr, "%c%-4d", ".bwr"[g.P.D.kind[i]], g.P.D.stamp[i]); else fprintf(stderr, ".    "); } fprintf(stderr, "\n"); } }
  }
  st.turns = g.next - 1; st.own = (st.turns < o.cap); st.margin = areaMargin(bd, g.P.D); st.qFinal = countKind(g.P.D, bd.N, R);
  if (branches) st.finalBranches = E.b.size();
  return st;
}
// greedy rollout guided Go (§7.2): up to six random candidates and the pass, twelve policy playouts each, the best mean
static GStats greedyGo(const Board& bd, const Opts& o, int cands, int rolls, Rng& rng) {
  GoGame g; g.init(bd.N); GStats st; std::unordered_set<uint64_t> hist; if (g_superko) hist.insert(g.P.hash);
  while (!g.ended) { int c = g.toMove; int all[MAXC]; int k = policyMovesF(bd, g.P, c, g.ko, all);
    for (int i = 0; i < k; i++) { int j = i + rng.below(k - i); std::swap(all[i], all[j]); }
    if (g_superko) { int kept = 0; for (int i = 0; i < k && kept < cands; i++) { GoGame g2 = g; goTurn(bd, o, g2, all[i]); if (hist.count(g2.P.hash)) continue; all[kept++] = all[i]; } k = kept; } // SGO_SUPERKO: candidates legal under positional superko
    int menu = std::min(k, cands); int sign = (c == B ? 1 : -1); double best = -1e18; int bestMv = -1;
    for (int m = -1; m < menu; m++) { int mv = (m < 0 ? -1 : all[m]); double tot = 0;
      for (int r = 0; r < rolls; r++) { GoGame g2 = g; goTurn(bd, o, g2, mv); tot += sign * goPlayout(bd, o, g2, rng); }
      double mean = tot / rolls; if (mean > best + 1e-9 || (std::fabs(mean - best) <= 1e-9 && rng.below(2))) { best = mean; bestMv = mv; } }
    goTurn(bd, o, g, bestMv); if (g_superko && bestMv >= 0) { if (hist.count(g.P.hash)) { fprintf(stderr, "SUPERKO VIOLATED\n"); exit(3); } hist.insert(g.P.hash); } }
  st.turns = g.turns; st.own = (g.turns < o.cap); st.margin = goMarginB(bd, o, g.P.D); return st;
}
static void printTable(const char* label, std::vector<GStats>& v, bool sgo, bool branches) {
  int n = v.size(); double mg = 0, sg = 0, tn = 0, tnOwn = 0, qc = 0, qf = 0, pd = 0, pb = 0, fb = 0; int dr = 0, own = 0, maxDepth = 0, maxBr = 0;
  for (auto& s : v) { mg += std::fabs(s.margin); sg += s.margin; if (s.margin == 0) dr++; if (s.own) { own++; tnOwn += s.turns; } tn += s.turns; qc += s.qCreated; qf += s.qFinal; pd += s.peakDepth; pb += s.peakBranches; fb += s.finalBranches; maxDepth = std::max(maxDepth, s.peakDepth); maxBr = std::max(maxBr, s.peakBranches); }
  printf("TABLE %s games=%d meanmargin=%.1f signedmargin=%+.2f draws=%.1f%% own=%.1f%% meanturns=%.1f meanturns_own=%.1f", label, n, mg / n, sg / n, 100.0 * dr / n, 100.0 * own / n, tn / n, own ? tnOwn / own : 0.0);
  if (sgo) printf(" qcreated=%.1f qfinal=%.1f peakdepth=%.2f maxdepth=%d", qc / n, qf / n, pd / n, maxDepth);
  if (sgo && branches) printf(" peakbranches=%.1f finalbranches=%.1f maxbranches=%d", pb / n, fb / n, maxBr);
  printf("\n");
}

// ---------- differential test: the fast layer against the slow functions, in lockstep random games ----------
static int diffTest(int games, uint64_t seed) {
  int bad = 0, turnsAll = 0; Rng rng(seed);
  int sides[] = {3, 4, 5, 7, 9};
  for (int gi = 0; gi < games; gi++) {
    int n = sides[gi % 5]; Board bd(n); g_place = (gi / 5) % 2 == 0 ? 1 : 3;
    // SGo: random policy moves chosen with the slow enumeration, applied to both engines
    { Display D; D.clear(n * n); Pos P; P.clear(n * n); int t = 1; int mv[MAXC];
      for (int turn = 0; turn < 3 * n * n && t < 400; turn++) {
        int k0 = policyMoves(bd, D, B, -1, mv); int m0 = k0 ? mv[rng.below(k0)] : -1;
        int k1 = policyMoves(bd, D, W, -1, mv); int m1 = k1 ? mv[rng.below(k1)] : -1;
        // the fast legality must agree cell by cell
        for (int i = 0; i < n * n; i++) if (D.kind[i] == EMPTY) for (int c = B; c <= W; c++) {
          bool slow = !ownEye(bd, D, c, i) && !classicalSuicide(bd, D, c, i), fast = legalPolicy(bd, P, c, i);
          if (slow != fast) { printf("DIFF legality sgo game %d turn %d cell %d color %d slow=%d fast=%d\n", gi, turn, i, c, slow, fast); bad++; } }
        if (m0 < 0 && m1 < 0) break;
        Display before = D;
        resolveTurn(bd, D, t, m0, m1); resolveTurnF(bd, P, t, m0, m1); t++; turnsAll++;
        if (!(D == P.D)) { printf("DIFF display sgo game %d turn %d (n=%d place=%d)\n", gi, turn, n, g_place); bad++; break; }
        Pos Q = P; Q.rebuild(bd); if (!P.sameTable(bd, Q)) { printf("DIFF chain table sgo game %d turn %d\n", gi, turn); bad++; break; }
        (void)before;
      } }
    // Go: alternate colors
    { Display D; D.clear(n * n); Pos P; P.clear(n * n); int c = B; int mv[MAXC];
      for (int ply = 0; ply < 6 * n * n; ply++) {
        int k = policyMoves(bd, D, c, -1, mv); if (k == 0) break; int m = mv[rng.below(k)];
        for (int i = 0; i < n * n; i++) if (D.kind[i] == EMPTY) { bool slow = !ownEye(bd, D, c, i) && !classicalSuicide(bd, D, c, i), fast = legalPolicy(bd, P, c, i);
          if (slow != fast) { printf("DIFF legality go game %d ply %d cell %d slow=%d fast=%d\n", gi, ply, i, slow, fast); bad++; } }
        int nc1, cp1, nc2, cp2; goMove(bd, D, c, m, &nc1, &cp1); goMoveF(bd, P, c, m, &nc2, &cp2); turnsAll++;
        if (!(D == P.D) || nc1 != nc2 || cp1 != cp2) { printf("DIFF go game %d ply %d (n=%d) nc %d/%d cp %d/%d\n", gi, ply, n, nc1, nc2, cp1, cp2); bad++; break; }
        Pos Q = P; Q.rebuild(bd); if (!P.sameTable(bd, Q)) { printf("DIFF chain table go game %d ply %d\n", gi, ply); bad++; break; }
        c = opp(c);
      } }
  }
  printf("difftest: %d games (sgo+go), %d turns/plies, %d differences\n", games, turnsAll, bad); return bad;
}

// ---------- tests against the Lean sheets ----------
static int decodeKind(char ch) { return ch == 'b' ? B : ch == 'w' ? W : ch == 'r' ? R : EMPTY; }
static char encKind(int k) { return k == B ? 'b' : k == W ? 'w' : k == R ? 'r' : '.'; }

static int runDispTests(const char* path) {
  Board bd(3); std::ifstream f(path); std::string cells, stamps, ec, es; int t, a0, a1; int bad = 0, tot = 0;
  while (f >> cells >> stamps >> t >> a0 >> a1 >> ec >> es) {
    Display D; D.clear(9);
    for (int i = 0; i < 9; i++) { D.kind[i] = decodeKind(cells[i]); D.stamp[i] = D.kind[i] ? stamps[i] - '0' : 0; }
    resolveTurn(bd, D, t, a0 >= 9 ? -1 : a0, a1 >= 9 ? -1 : a1);
    std::string rc, rs;
    for (int i = 0; i < 9; i++) { rc += encKind(D.kind[i]); rs += char('0' + (D.kind[i] ? D.stamp[i] % 10 : 0)); }
    tot++; if (rc != ec || rs != es) { bad++; if (bad <= 5) printf("DISP MISMATCH %s %s t=%d %d %d: got %s %s want %s %s\n", cells.c_str(), stamps.c_str(), t, a0, a1, rc.c_str(), rs.c_str(), ec.c_str(), es.c_str()); }
  }
  printf("disp tests: %d cases, %d mismatches\n", tot, bad); return bad;
}
static int runGoTests(const char* path) {
  Board bd(3); std::ifstream f(path); std::string s, exp; char c; int x, y; int bad = 0, tot = 0;
  while (f >> s >> c >> x >> y >> exp) {
    Display D; D.clear(9); for (int i = 0; i < 9; i++) D.kind[i] = decodeKind(s[i]);
    int i = (x % 3) * 3 + (y % 3);
    bool ok = goMove(bd, D, c == 'b' ? B : W, i, nullptr, nullptr);
    std::string r; if (!ok) r = "U"; else for (int p = 0; p < 9; p++) r += encKind(D.kind[p]);
    tot++; if (r != exp) { bad++; if (bad <= 5) printf("GO MISMATCH %s %c %d %d: got %s want %s\n", s.c_str(), c, x, y, r.c_str(), exp.c_str()); }
  }
  printf("go tests: %d cases, %d mismatches\n", tot, bad); return bad;
}
static std::vector<std::string> split(const std::string& s, char d) { std::vector<std::string> r; std::string cur; for (char ch : s) { if (ch == d) { r.push_back(cur); cur.clear(); } else cur += ch; } r.push_back(cur); return r; }
static int parseMv(const std::string& s) { return s == "p" ? -1 : atoi(s.c_str()); }
static int runSerialTests(const char* path) {
  std::ifstream f(path); std::string line; int bad = 0, tot = 0, turns = 0;
  while (std::getline(f, line)) {
    auto fld = split(line, '\t'); if (fld.size() < 6) continue;
    int n = atoi(fld[0].c_str()); Board bd(n);
    auto ms = split(fld[1], ';'), ds = split(fld[2], '|'), ps = split(fld[5], '|'); std::string fs = fld[4];
    Display D; D.clear(n * n); Pos P; P.clear(n * n); Ent E; entInit(E, n * n); auto es = split(fld[3], '|'); int next = 1; bool fin = false; bool ok = true; tot++;
    for (size_t k = 0; k < ms.size() && ok; k++) {
      // probes: must be unavailable at the pre-state
      if (!ps[k].empty()) for (auto& pr : split(ps[k], ' ')) { auto ab = split(pr, ':'); int a = parseMv(ab[0]), b = parseMv(ab[1]);
        bool avail = !fin && (a < 0 || (a < n * n && D.kind[a] == EMPTY)) && (b < 0 || (b < n * n && D.kind[b] == EMPTY));
        if (avail) { ok = false; printf("SERIAL probe available: case %d turn %zu %s\n", tot, k, pr.c_str()); } }
      auto ab = split(ms[k], ':'); int m0 = parseMv(ab[0]), m1 = parseMv(ab[1]);
      bool avail = !fin && (m0 < 0 || (m0 < n * n && D.kind[m0] == EMPTY)) && (m1 < 0 || (m1 < n * n && D.kind[m1] == EMPTY));
      if (!avail) { ok = false; printf("SERIAL move unavailable: case %d turn %zu\n", tot, k); break; }
      if (m0 < 0 && m1 < 0) { fin = true; next++; } else { resolveTurn(bd, D, next, m0, m1); resolveTurnF(bd, P, next, m0, m1); next++;
        if (!(D == P.D)) { ok = false; printf("SERIAL fast/slow divergence: case %d turn %zu\n", tot, k); }
        entStep(bd, E, P.D, m0, m1);
        // the entanglement against the sheet (set equality of the encoded branches)
        if (k < es.size()) { std::vector<std::string> want = split(es[k], ','), got; if (es[k].empty()) want.clear();
          for (auto& b : E.b) { std::string e; for (int i = 0; i < n * n; i++) e += (b.kind[i] == EMPTY ? '.' : encKind(b.kind[i])); got.push_back(e); }
          bool same = E.defined && got.size() == want.size();
          if (same) for (auto& w : want) { bool f = false; for (auto& g : got) if (g == w) f = true; if (!f) same = false; }
          if (!same) { ok = false; printf("SERIAL ENT MISMATCH case %d turn %zu: got %zu branches want %zu (%s)\n", tot, k, got.size(), want.size(), es[k].substr(0, 60).c_str()); } } }
      std::string enc; for (int i = 0; i < n * n; i++) { if (i) enc += ','; if (D.kind[i] == EMPTY) enc += '.'; else { enc += encKind(D.kind[i]); enc += std::to_string(D.stamp[i]); } }
      if (enc != ds[k] || fin != (fs[k] == '1')) { ok = false; printf("SERIAL MISMATCH case %d turn %zu: got %s fin=%d want %s fin=%c\n", tot, k, enc.c_str(), (int)fin, ds[k].c_str(), fs[k]); }
      turns++;
    }
    if (!ok) bad++;
  }
  printf("serial tests: %d games, %d turns, %d bad games\n", tot, turns, bad); return bad;
}

// ---------- play: policies, agents, ladder ----------
int main(int argc, char** argv) {
  if (const char* e = getenv("SGO_SIMP")) g_simp = (atoi(e) != 0);
  if (const char* e = getenv("SGO_CHECK")) g_check = (atoi(e) != 0);
  if (const char* e = getenv("SGO_NOCAP")) g_nocap = (atoi(e) != 0);
  if (const char* e = getenv("SGO_KO")) g_koStats = (atoi(e) != 0);
  if (const char* e = getenv("SGO_EYEDEF")) { g_eyedef = (atoi(e) != 0); if (g_eyedef) fprintf(stderr, "[policy: own eye allowed where the opponent could capture]\n"); }
  if (const char* e = getenv("SGO_SUPERKO")) { g_superko = (atoi(e) != 0); if (g_superko) fprintf(stderr, "[positional superko in the Go games]\n"); }
  if (const char* e = getenv("SGO_DIVLOG")) g_divlog = (atoi(e) != 0);
  if (const char* e = getenv("SGO_PLACE")) { g_place = atoi(e); if (g_place != 1 && g_place != 3 && g_place != 4) { fprintf(stderr, "bad SGO_PLACE\n"); return 2; } }
  if (g_place == 3) fprintf(stderr, "[three-tier placement resolution]\n");
  if (g_place == 4) fprintf(stderr, "[three-tier placement resolution, December 2025 wording: no adjacent q-stone for rule 2]\n");
  if (const char* e = getenv("SGO_N")) { g_n = atoi(e); if (g_n < 2 || g_n * g_n > MAXC) { fprintf(stderr, "bad SGO_N\n"); return 2; } }
  if (g_simp) fprintf(stderr, "[simplified capture condition: 3b without the q-stone clause]\n");
  // pos mode: analysis of a given position.  File: lines "n 9", "turn 5", "B D4 1" (color B/W/R, column letter, row
  // number from the bottom, stamp).  Commands:
  //   sgo pos <file> show                          the display
  //   sgo pos <file> resolve <m0> <m1>             the display after the joint move (coordinates or 'pass'), rule as set
  //   sgo pos <file> value <games> <R> [cap]       equilibrium guided continuations from the position: Black's mean margin
  //   sgo pos <file> matrix <R> <m0,..> <m1,..>    the one-turn matrix of mean final margins over R policy playouts, the value and the optimal mixtures
  //   sgo pos <file> matrixeq <games> <R> <m0,..> <m1,..>   the same matrix with equilibrium guided continuations per entry
  if (argc >= 4 && std::string(argv[1]) == "pos") {
    std::ifstream f(argv[2]); std::string line; int n = 9, h = 0, turn = 1; std::vector<std::tuple<int,int,int>> stones;
    auto coord = [&](const std::string& sIn, int nn) -> int { if (sIn == "pass" || sIn == "p") return -1; int c = toupper(sIn[0]) - 'A'; int r = atoi(sIn.c_str() + 1); return (r - 1) * nn + c; };
    while (std::getline(f, line)) { std::istringstream is(line); std::string k; is >> k; if (k == "n") is >> n; else if (k == "h") is >> h; else if (k == "turn") is >> turn;
      else if (k == "B" || k == "W" || k == "R") { std::string c; int st = 0; is >> c >> st; stones.push_back({k == "B" ? B : (k == "W" ? W : R), coord(c, n), st}); } }
    g_n = n; Opts o; o.n = n; Board bd(n, h); h = bd.h; SGoGame g; g.init(bd.N); // "h <rows>" in the file gives a rectangular board of n columns
    for (auto& t3 : stones) { int k, i, st; std::tie(k, i, st) = t3; g.P.place(bd, i, k, st); } g.next = turn;
    auto showD = [&](const Display& D) { for (int r = h; r >= 1; r--) { printf("%2d ", r); for (int c = 0; c < n; c++) { int i = (r - 1) * n + c; printf(" %c", ".BWQ"[D.kind[i]]); } printf("\n"); } printf("   "); for (int c = 0; c < n; c++) printf(" %c", 'A' + c); printf("\n"); };
    auto splitMoves = [&](const std::string& lst) { std::vector<int> v; for (auto& p : split(lst, ',')) v.push_back(coord(p, n)); return v; };
    auto name = [&](int i) { static char bufs[4][16]; static int w = 0; char* buf = bufs[w++ & 3]; if (i < 0) return (const char*)"pass"; snprintf(buf, 16, "%c%d", 'A' + i % n, i / n + 1); return (const char*)buf; }; // rotating buffers: two names in one printf
    std::string cmd = argv[3];
    if (cmd == "show") { showD(g.P.D); return 0; }
    // exact solution to a horizon: sgo pos <file> solve <depth> [pass is included; every empty point for both sides]
    if (cmd == "solve" && argc >= 5) { int depth = atoi(argv[4]); o.cap = 1000000; g_solveMemo.clear(); g_solveNodes = 0;
      std::vector<int> mv; std::vector<std::vector<double>> M; std::vector<double> x, y;
      double v = solveExact(bd, o, g, depth, &mv, &M, &x, &y); int k = mv.size();
      printf("SOLVE rule=%d depth=%d (exact to the horizon; leaves scored by area; Black rows x White columns)\n        ", g_place, depth);
      for (int j = 0; j < k; j++) printf("%8s", name(mv[j])); printf("\n");
      for (int i = 0; i < k; i++) { printf("%8s", name(mv[i])); for (int j = 0; j < k; j++) printf("%8.2f", M[i][j]); printf("   x=%.3f\n", x[i]); }
      printf("        "); for (int j = 0; j < k; j++) printf("%8.3f", y[j]); printf("   <- y\nvalue %+.3f, nodes %ld\n", v, g_solveNodes); return 0; }
    if (cmd == "resolve" && argc >= 6) { int m0 = coord(argv[4], n), m1 = coord(argv[5], n); SGoGame g2 = g; sgoTurn(bd, o, g2, m0, m1); printf("after %s/%s (turn %d, placement rule %d):\n", name(m0), name(m1), turn, g_place); showD(g2.P.D); printf("area margin (black - white) %d\n", areaMargin(bd, g2.P.D)); return 0; }
    if (cmd == "value" && argc >= 6) { int games = atoi(argv[4]), Rr = atoi(argv[5]); o.cap = argc >= 7 ? atoi(argv[6]) : turn + 300; EqStats eq; double sum = 0, sq = 0; int capped = 0;
      for (int gnum = 0; gnum < games; gnum++) { Rng rng(mix64(4242ULL * (gnum + 1))); GStats st = eqGuidedSGo(bd, o, Rr, rng, eq, false, &g); sum += st.margin; sq += st.margin * st.margin; if (!st.own) capped++; }
      double mean = sum / games, sd = std::sqrt(std::max(0.0, sq / games - mean * mean)); printf("VALUE rule=%d games=%d R=%d mean=%+.2f se=%.2f sd=%.1f capped=%d\n", g_place, games, Rr, mean, sd / std::sqrt((double)games), sd, capped); return 0; }
    if ((cmd == "matrix" || cmd == "matrixeq") && argc >= 7) {
      int Rr, games = 0; std::vector<int> mv0, mv1;
      if (cmd == "matrix") { Rr = atoi(argv[4]); mv0 = splitMoves(argv[5]); mv1 = splitMoves(argv[6]); } else { games = atoi(argv[4]); Rr = atoi(argv[5]); mv0 = splitMoves(argv[6]); mv1 = splitMoves(argv[7]); }
      int k0 = mv0.size(), k1 = mv1.size(); double M[5][5]; o.cap = turn + 300;
      for (int i = 0; i < k0; i++) for (int j = 0; j < k1; j++) { double tot = 0; int cnt = cmd == "matrix" ? Rr : games;
        for (int r = 0; r < cnt; r++) { Rng rng(mix64(777ULL * (r + 1) + 31 * i + 7 * j)); SGoGame g2 = g; sgoTurn(bd, o, g2, mv0[i], mv1[j]);
          if (cmd == "matrix") tot += sgoPlayout(bd, o, g2, rng); else { EqStats eq; tot += eqGuidedSGo(bd, o, Rr, rng, eq, false, &g2).margin; } }
        M[i][j] = tot / cnt; }
      double x[5], y[5]; double v = solveZeroSum(M, k0, k1, x, y);
      printf("MATRIX rule=%d (%s, Black rows x White columns; entries = Black's mean final margin)\n        ", g_place, cmd == "matrix" ? "policy playouts" : "equilibrium guided continuations");
      for (int j = 0; j < k1; j++) printf("%8s", name(mv1[j])); printf("\n");
      for (int i = 0; i < k0; i++) { printf("%8s", name(mv0[i])); for (int j = 0; j < k1; j++) printf("%8.1f", M[i][j]); printf("   x=%.2f\n", x[i]); }
      printf("        "); for (int j = 0; j < k1; j++) printf("%8.2f", y[j]); printf("   <- y\nvalue %+.2f, pure saddle: %s\n", v, pureSaddle(M, k0, k1) ? "yes" : "no"); return 0; }
    fprintf(stderr, "pos: unknown command\n"); return 2;
  }
  // table mode: uniformly random play statistics (sgo.tex §2.2); bound in turns (SGo turns, Go move pairs); 0 = unbounded
  // usage: sgo table <sgo|go> <games> <bound> [seed] [branches 0/1]
  if (argc >= 5 && std::string(argv[1]) == "table") {
    std::string game = argv[2]; int games = atoi(argv[3]), bound = atoi(argv[4]); uint64_t seed = argc >= 6 ? strtoull(argv[5], nullptr, 10) : 3; bool br = argc >= 7 ? atoi(argv[6]) != 0 : true;
    Opts o; o.ko = g_koStats; o.cap = bound > 0 ? (game == "go" ? 2 * bound : bound) : 1000000; Board bd(o.n); std::vector<GStats> v;
    for (int gnum = 0; gnum < games; gnum++) { Rng rng(mix64(seed * 7919ULL + gnum)); GStats st = (game == "sgo") ? randomSGo(bd, o, rng, br) : randomGo(bd, o, rng); if (game == "go") st.turns = (st.turns + 1) / 2; v.push_back(st);
      if ((gnum + 1) % 100 == 0) fprintf(stderr, "%d/%d\n", gnum + 1, games); }
    char label[128]; snprintf(label, sizeof label, "random %s n=%d bound=%d", game.c_str(), o.n, bound); printTable(label, v, game == "sgo", br);
    if (g_divlog && game == "sgo") printf("CONFLICTS trapping=%ld both_or_none=%ld one_color=%ld one_color_and_qstone(divergent)=%ld per game: %.2f / %.2f / %.2f / %.3f\n", g_confClass[0], g_confClass[1], g_confClass[2], g_confClass[3], (double)g_confClass[0] / games, (double)g_confClass[1] / games, (double)g_confClass[2] / games, (double)g_confClass[3] / games);
    return 0;
  }
  // eqplay mode: equilibrium guided SGo (sgo.tex §7.1); usage: sgo eqplay <games> <rollouts per cell> [seed] [cap turns]
  if (argc >= 4 && std::string(argv[1]) == "eqplay") {
    int games = atoi(argv[2]), Rr = atoi(argv[3]); uint64_t seed = argc >= 5 ? strtoull(argv[4], nullptr, 10) : 5; Opts o; o.ko = g_koStats; o.cap = argc >= 6 ? atoi(argv[5]) : 400; Board bd(o.n);
    std::vector<GStats> v; EqStats eq; auto t0 = std::chrono::steady_clock::now();
    for (int gnum = 0; gnum < games; gnum++) { Rng rng(mix64(seed * 104729ULL + gnum)); v.push_back(eqGuidedSGo(bd, o, Rr, rng, eq, true));
      fprintf(stderr, "game %d/%d turns=%d margin=%.0f mixed=%.3f spread=%.1f  %.0fs\n", gnum + 1, games, v.back().turns, v.back().margin, eq.turns ? (double)eq.mixed / eq.turns : 0, eq.turns ? eq.spreadSum / eq.turns : 0, std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count()); }
    char label[128]; snprintf(label, sizeof label, "eqguided sgo n=%d R=%d ko=%d", o.n, Rr, (int)o.ko); printTable(label, v, true, true);
    { int h[6] = {0, 0, 0, 0, 0, 0}; for (auto& st : v) { int t = st.turns; h[t < 20 ? 0 : t < 40 ? 1 : t < 80 ? 2 : t < 160 ? 3 : t < o.cap ? 4 : 5]++; } printf("LENGTHS <20:%d <40:%d <80:%d <160:%d <cap:%d cap:%d\n", h[0], h[1], h[2], h[3], h[4], h[5]); }
    printf("EQ turns=%ld mixed=%.1f%% spread=%.1f control_turns=%ld control_mixed=%.1f%%\n", eq.turns, 100.0 * eq.mixed / std::max(1L, eq.turns), eq.spreadSum / std::max(1L, eq.turns), eq.ctrlTurns, 100.0 * eq.ctrlMixed / std::max(1L, eq.ctrlTurns));
    if (g_divlog) printf("CONFLICTS trapping=%ld both_or_none=%ld one_color=%ld one_color_and_qstone(divergent)=%ld per game: %.2f / %.2f / %.2f / %.3f\n", g_confClass[0], g_confClass[1], g_confClass[2], g_confClass[3], (double)g_confClass[0] / games, (double)g_confClass[1] / games, (double)g_confClass[2] / games, (double)g_confClass[3] / games);
    return 0;
  }
  // greedygo mode: greedy rollout guided Go (sgo.tex §7.2); usage: sgo greedygo <games> [candidates=6] [rollouts=12] [seed] [cap plies]
  if (argc >= 3 && std::string(argv[1]) == "greedygo") {
    int games = atoi(argv[2]); int cands = argc >= 4 ? atoi(argv[3]) : 6, rolls = argc >= 5 ? atoi(argv[4]) : 12; uint64_t seed = argc >= 6 ? strtoull(argv[5], nullptr, 10) : 5; Opts o; o.ko = g_koStats; o.cap = argc >= 7 ? atoi(argv[6]) : 800; Board bd(o.n);
    std::vector<GStats> v; for (int gnum = 0; gnum < games; gnum++) { Rng rng(mix64(seed * 15485863ULL + gnum)); GStats st = greedyGo(bd, o, cands, rolls, rng); st.turns = (st.turns + 1) / 2; v.push_back(st); if ((gnum + 1) % 20 == 0) fprintf(stderr, "%d/%d\n", gnum + 1, games); }
    char label[128]; snprintf(label, sizeof label, "greedy go n=%d cands=%d rolls=%d", o.n, cands, rolls); printTable(label, v, false, false); return 0;
  }
  if (argc >= 2 && std::string(argv[1]) == "difftest") { int games = argc >= 3 ? atoi(argv[2]) : 200; return diffTest(games, argc >= 4 ? strtoull(argv[3], nullptr, 10) : 5) ? 1 : 0; }
  if (argc >= 2 && std::string(argv[1]) == "test") {
    int bad = runDispTests("tests/disp.txt") + runGoTests("tests/go.txt") + runSerialTests("tests/serial.txt");
    printf("TOTAL mismatches: %d\n", bad); return bad ? 1 : 0;
  }
  // match mode: sgo match game ko budgetA budgetB games seed [komi] [cap]
  if (argc >= 7 && std::string(argv[1]) == "match") {
    std::string game = argv[2]; Opts o; o.ko = atoi(argv[3]) != 0; int ba = atoi(argv[4]), bb = atoi(argv[5]), games = atoi(argv[6]);
    uint64_t seed = argc >= 8 ? strtoull(argv[7], nullptr, 10) : 1; if (argc >= 9) o.komi = atof(argv[8]); if (argc >= 10) o.cap = atoi(argv[9]); if (argc >= 11) o.pdepth = atoi(argv[10]);
    Board bd(o.n);
    // SGO_LOG=<file> (environment): per-game results are appended there and a rerun resumes after the games already
    // logged; each game has its own seed, so the results do not depend on the order or the interruptions
    const char* logPath = getenv("SGO_LOG"); std::vector<char> done(games, 0);
    int strideK = 0, strideM = 1; if (const char* e = getenv("SGO_STRIDE")) sscanf(e, "%d/%d", &strideK, &strideM); // this process plays the games ≡ K mod M (several processes may share one log)
    double scoreA = 0; int wins = 0, draws = 0, losses = 0; double sumTurns = 0; double sumAbs = 0; int ndone = 0;
    auto account = [&](int gnum, double margin, int turns) { bool aBlack = (gnum % 2 == 0); double mA = aBlack ? margin : -margin;
      double sc = mA > 0 ? 1.0 : (mA < 0 ? 0.0 : 0.5); scoreA += sc; if (sc == 1) wins++; else if (sc == 0) losses++; else draws++;
      sumTurns += turns; sumAbs += std::fabs(margin); ndone++; return sc; };
    if (logPath) { std::ifstream lf(logPath); std::string line; while (std::getline(lf, line)) { int gnum, turns; double margin;
        if (sscanf(line.c_str(), "G %d %lf %d", &gnum, &margin, &turns) == 3 && gnum >= 0 && gnum < games && !done[gnum]) { done[gnum] = 1; account(gnum, margin, turns); } } }
    auto t0 = std::chrono::steady_clock::now();
    for (int gnum = 0; gnum < games; gnum++) {
      if (done[gnum] || (strideM > 1 && gnum % strideM != strideK)) continue;
      bool aBlack = (gnum % 2 == 0); Rng rng(mix64(seed * 1000003ULL + (uint64_t)gnum));
      GameRes r = (game == "sgo") ? playSGo(bd, o, aBlack ? ba : bb, aBlack ? bb : ba, rng) : playGo(bd, o, aBlack ? ba : bb, aBlack ? bb : ba, rng);
      double sc = account(gnum, r.margin, r.turns); double mA = aBlack ? r.margin : -r.margin;
      if (logPath) { FILE* lf = fopen(logPath, "a"); if (lf) { fprintf(lf, "G %d %.1f %d\n", gnum, r.margin, r.turns); fclose(lf); } }
      double el = std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count();
      fprintf(stderr, "game %d/%d A%s score=%.1f turns=%d margin=%.1f  [W%d D%d L%d]  %.0fs\n", ndone, games, aBlack ? "(B)" : "(W)", sc, r.turns, mA, wins, draws, losses, el);
    }
    if (logPath) { // the RESULT line is computed over the whole log, and printed only when every game is there
      std::fill(done.begin(), done.end(), 0); scoreA = 0; wins = draws = losses = 0; sumTurns = sumAbs = 0; ndone = 0;
      std::ifstream lf(logPath); std::string line; while (std::getline(lf, line)) { int gnum, turns; double margin;
        if (sscanf(line.c_str(), "G %d %lf %d", &gnum, &margin, &turns) == 3 && gnum >= 0 && gnum < games && !done[gnum]) { done[gnum] = 1; account(gnum, margin, turns); } }
      if (ndone < games) { fprintf(stderr, "partial: %d/%d games logged, no RESULT\n", ndone, games); return 0; } }
    double sA = scoreA / games; double sStrong = sA >= 0.5 ? sA : 1 - sA; double gap = 400 * std::log10(sStrong / (1 - sStrong)); if (sA < 0.5) gap = -gap;
    printf("RESULT game=%s ko=%d A=%d B=%d games=%d scoreA=%.3f W%d D%d L%d eloA-B=%+.0f meanturns=%.1f meanabsmargin=%.1f\n",
      game.c_str(), (int)o.ko, ba, bb, games, sA, wins, draws, losses, gap, sumTurns / games, sumAbs / games);
    return 0;
  }
  // stats mode: random self play statistics (policy play)
  if (argc >= 4 && std::string(argv[1]) == "stats") {
    std::string game = argv[2]; Opts o; o.ko = atoi(argv[3]) != 0; int games = argc >= 5 ? atoi(argv[4]) : 1000; Board bd(o.n); Rng rng(7);
    double sumTurns = 0, sumAbs = 0; int draws = 0, capped = 0;
    for (int gnum = 0; gnum < games; gnum++) { GameRes r = (game == "sgo") ? playSGo(bd, o, 0, 0, rng) : playGo(bd, o, 0, 0, rng); sumTurns += r.turns; sumAbs += std::fabs(r.margin); if (r.margin == 0) draws++; if (r.turns >= o.cap) capped++; }
    printf("stats game=%s ko=%d games=%d meanturns=%.1f meanabsmargin=%.1f draws=%.1f%% capped=%d\n", game.c_str(), (int)o.ko, games, sumTurns / games, sumAbs / games, 100.0 * draws / games, capped);
    return 0;
  }
  // ustats: the printed random-play convention — uniform over all legal board moves, passing only when none; bound 40
  if (argc >= 3 && std::string(argv[1]) == "ustats") {
    Opts o; o.cap = argc >= 5 ? atoi(argv[4]) : 40; Board bd(o.n); Rng rng(3); int games = argc >= 4 ? atoi(argv[3]) : 1000; std::string game = argv[2];
    double sumTurns = 0, sumAbs = 0; int draws = 0, own = 0;
    for (int gnum = 0; gnum < games; gnum++) {
      if (game == "sgo") { SGoGame g; g.init(bd.N);
        while (!g.ended) { int emp[MAXC], k = 0; for (int i = 0; i < bd.N; i++) if (g.P.D.kind[i] == EMPTY) emp[k++] = i;
          int m0 = k ? emp[rng.below(k)] : -1, m1 = k ? emp[rng.below(k)] : -1; sgoTurn(bd, o, g, m0, m1); }
        int tn = g.next - 1; sumTurns += tn; int m = areaMargin(bd, g.P.D); sumAbs += std::abs(m); if (m == 0) draws++; if (tn < o.cap) own++; }
      else { GoGame g; g.init(bd.N);
        while (!g.ended) { int emp[MAXC], k = 0; for (int i = 0; i < bd.N; i++) if (g.P.D.kind[i] == EMPTY) emp[k++] = i; int m = k ? emp[rng.below(k)] : -1; goTurn(bd, o, g, m); }
        sumTurns += g.turns; int m = areaMargin(bd, g.P.D); sumAbs += std::abs(m); if (m == 0) draws++; if (g.turns < o.cap) own++; }
    }
    printf("ustats game=%s games=%d meanabsmargin=%.1f draws=%.1f%% endedOnOwn=%.0f%% meanturns=%.1f\n", game.c_str(), games, sumAbs / games, 100.0 * draws / games, 100.0 * own / games, sumTurns / games);
    return 0;
  }
  // trace mode: find a capped policy game and print its last turns
  if (argc >= 4 && std::string(argv[1]) == "trace") {
    std::string game = argv[2]; Opts o; o.ko = atoi(argv[3]) != 0; Board bd(o.n); Rng rng(11);
    for (int gnum = 0; gnum < 5000; gnum++) {
      if (game == "sgo") {
        SGoGame g; g.init(bd.N); std::vector<Display> hist; std::vector<std::pair<int,int>> mvs;
        while (!g.ended) { int m0 = randomMoveF(bd, g.P, B, g.koB, rng), m1 = randomMoveF(bd, g.P, W, g.koW, rng); sgoTurn(bd, o, g, m0, m1); hist.push_back(g.P.D); mvs.push_back({m0, m1}); }
        if (g.next - 1 >= o.cap) {
          printf("capped sgo game %d, %zu turns; last 10:\n", gnum, hist.size());
          for (size_t k = hist.size() - 10; k < hist.size(); k++) { printf("turn %zu moves %d/%d\n", k + 1, mvs[k].first, mvs[k].second);
            for (int x = 0; x < o.n; x++) { for (int y = 0; y < o.n; y++) { int i = x * o.n + y; if (hist[k].kind[i]) printf("%c%-3d ", encKind(hist[k].kind[i]), hist[k].stamp[k > 0 ? i : i]); else printf(".    "); } printf("\n"); } }
          return 0; }
      } else {
        GoGame g; g.init(bd.N); std::vector<Display> hist; std::vector<int> mvs;
        while (!g.ended) { int m = randomMoveF(bd, g.P, g.toMove, g.ko, rng); goTurn(bd, o, g, m); hist.push_back(g.P.D); mvs.push_back(m); }
        if (g.turns >= o.cap) {
          printf("capped go game %d, %zu turns; last 8:\n", gnum, hist.size());
          for (size_t k = hist.size() - 8; k < hist.size(); k++) { printf("turn %zu move %d\n", k + 1, mvs[k]);
            for (int x = 0; x < o.n; x++) { for (int y = 0; y < o.n; y++) printf("%c", encKind(hist[k].kind[x * o.n + y])); printf("\n"); } }
          return 0; }
      }
    }
    return 0;
  }
  printf("usage: sgo test | sgo match <sgo|go> <ko 0/1> <budgetA> <budgetB> <games> [seed] [komi] [cap] [pdepth] | sgo stats <sgo|go> <ko> [games]\n");
  return 0;
}
