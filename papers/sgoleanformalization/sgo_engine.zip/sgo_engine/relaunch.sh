#!/bin/bash
# after a sandbox restart: relaunch the training loops (netloop5.sh dec / aug / simple / go) at their current
# generation, unless they are already running.  usage: relaunch.sh
cd /home/claude/eng
latest() { ls $1/g*.bin 2>/dev/null | sed 's/.*g\([0-9]*\)\.bin/\1/' | sort -n | tail -1; }
start() { # start <tag> <nets dir> <log suffix>: the latest net; one generation back when its progress match has not run yet
  local tag=$1 nets=$2 sfx=$3 k; k=$(latest $nets)
  if [ ! -f runs/net_ref${sfx}_g$k.txt ] && [ ! -f runs/net_eval${sfx}_g$k.txt ] && [ -f $nets/g$((k-1)).bin ]; then k=$((k-1)); fi
  echo "$tag loop from g$k"; setsid nohup ./netloop5.sh $tag $k 40 150 100 > runs/netloop_$tag.out 2>&1 < /dev/null &  # setsid: own scheduler autogroup, so the loops share the CPU equally
}
tags=${*:-go}   # which loops to (re)start: default the Go loop (A and B finished at g25, C on hold); e.g. relaunch.sh dec aug simple go
for t in $tags; do
  case $t in dec) pgrep -f 'netloop[345].sh dec' >/dev/null || start dec nets "";;
             aug) pgrep -f 'netloop[345].sh aug' >/dev/null || start aug nets_aug _aug;;
             simple) pgrep -f 'netloop[345].sh simple' >/dev/null || start simple nets_simple _simple;;
             go) [ -f runs/GO_PAUSED ] && { echo "go paused (runs/GO_PAUSED)"; continue; }
                 pgrep -f 'netloop5.sh go' >/dev/null || start go nets_go _go;; esac
done
# the MC-partner experiment (2026-11-13): league.sh runs the two league lines, then their tournaments, then resumes Go
if [ ! -f runs/LEAGUE_PAUSED ] && ! pgrep -f '/bin/bash ./league.sh' >/dev/null && [ ! -f runs/LEAGUE_DONE ]; then echo "league"; setsid nohup ./league.sh >> runs/league.out 2>&1 < /dev/null & fi
sleep 1; ps -eo pid,etime,args | grep -E 'sgonet|netloop' | grep -v grep | cut -c1-100
# the tournament refinements (2026-11-11): resumable; restart if neither finished and not running
if ! pgrep -f 'refine_AB.sh' >/dev/null && ! { grep -q '^REFINED 64' runs/tour_A17/results.txt && grep -q '^REFINED 64' runs/tour_B25/results.txt; }; then
  echo "refine_AB"; setsid nohup ./refine_AB.sh >> runs/refine_AB.out 2>&1 < /dev/null &
fi
# the Go tournament stage (2026-11-13): waits for g25, then tournament + refinement; resumable
if [ ! -f runs/GO_PAUSED ] && ! pgrep -f 'go_after25.sh' >/dev/null && [ ! -f runs/tour_G25/ALLDONE ]; then echo "go_after25"; setsid nohup ./go_after25.sh >> runs/go_after25.out 2>&1 < /dev/null & fi
