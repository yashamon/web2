#!/bin/bash
# The combined tournaments of the MC-partner experiment (2026-11-13), resumable.  Each is the original tournament's 14
# agents (6 MC agents, 8 self-play nets; their games are copied over, so only the new pairs are played) plus the 8
# league nets of that rule, 16 games per pair, then a Bradley-Terry fit and refinement to 64 games for pairs within 300 Elo.
#   tour_LA (rule A): + nets_lgA/g1 g4 g7 g10 g13 g17 g21 g25          (from tour_A17)
#   tour_LB (rule B): + nets_lgA/g1 g4 g7 g10 g13, nets_lgB/g17 g21 g25 (from tour_B25)
cd /home/claude/eng
seed_dir() { # seed_dir <new> <old>: the original pairs' game logs and result lines
  local d=runs/tour_$1 o=runs/tour_$2; mkdir -p $d
  if [ ! -f $d/.seeded ]; then cp $o/p*_*.games $d/; grep '^P ' $o/results.txt > $d/results.txt; touch $d/.seeded; fi
}
MC="mc0 mc3 mc26 mc205 mc819 mc3277"
net() { echo "net:$1/g$2.bin@100"; }
run() { # run <name> <place> <players...>
  local name=$1 place=$2; shift 2; local d=runs/tour_$name
  [ -f $d/ALLDONE ] && return
  grep -q '^DONE' $d/results.txt || SGO_PLACE=$place ./tournament.sh $name 16 "$@"
  grep -q '^DONE' $d/results.txt || return 1
  if ! grep -q '^REFINED 64' $d/results.txt; then
    python3 bt.py $d 0 100 0.1 > $d/bt.txt
    SGO_PLACE=$place ./refine.sh $name 64 300
  fi
  python3 bt.py $d 0 400 0.1 > $d/bt64.txt
  touch $d/ALLDONE
}
seed_dir LA A17
run LA 4 $MC $(for k in 1 4 7 10 13 17 21 25; do net nets $k; done) $(for k in 1 4 7 10 13 17 21 25; do net nets_lgA $k; done)
seed_dir LB B25
run LB 1 $MC $(for k in 1 4 7 10 13; do net nets $k; done) $(for k in 17 21 25; do net nets_simple $k; done) \
         $(for k in 1 4 7 10 13; do net nets_lgA $k; done) $(for k in 17 21 25; do net nets_lgB $k; done)
