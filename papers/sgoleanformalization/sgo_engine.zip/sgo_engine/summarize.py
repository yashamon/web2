#!/usr/bin/env python3
"""Sum the ladder RESULT lines in runs/<game>_ko<ko>.txt into a table.
Elo gap of a rung = 400*log10(s/(1-s)) for the stronger side's score s;
the ladder height = sum of the rung gaps (B over A, as printed in sgo.tex §7.3).
A 68% band per rung from the binomial standard error of the score."""
import math, re, sys, os

def rows(path):
    out = []
    if not os.path.exists(path):
        return out
    for line in open(path):
        if not line.startswith("RESULT"):
            continue
        kv = dict(re.findall(r"(?<![\w-])(\w+)=(\S+)", line))
        wdl = re.search(r"W(\d+) D(\d+) L(\d+)", line)
        out.append(dict(A=int(kv["A"]), B=int(kv["B"]), n=int(kv["games"]),
                        sA=float(kv["scoreA"]), W=int(wdl[1]), D=int(wdl[2]), L=int(wdl[3]),
                        turns=float(kv["meanturns"]), margin=float(kv["meanabsmargin"])))
    return out

def elo(s):
    s = min(max(s, 0.005), 0.995)
    return 400 * math.log10(s / (1 - s))

def band(sA, n):
    se = math.sqrt(max(sA * (1 - sA), 1e-4) / n)
    lo, hi = elo(1 - (sA + se)), elo(1 - (sA - se))
    return lo, hi

def main():
    ladders = [(f"{g.upper()}  ko={'on' if k else 'off'}  budget per candidate, cap 200", f"runs/{g}_ko{k}.txt")
               for g in ("sgo", "go") for k in (0, 1)]
    ladders += [("SGO  ko=off  SIMPLIFIED capture (3b without the q-stone clause), per-candidate budgets, cap 200", "runs/sgo_ko0_simp.txt"),
                ("SGO  ko=on   SIMPLIFIED capture (3b without the q-stone clause), per-candidate budgets, cap 200", "runs/sgo_ko1_simp.txt")]
    ladders += [("SGO  7x7  ko=on   printed rules, total budgets 16/128/1024/2048/4096 per turn, cap 200", "runs/sgo_ko1_n7_tot.txt"),
                ("GO   7x7  ko=on   total budgets, cap 200", "runs/go_ko1_n7_tot.txt"),
                ("SGO  5x5  ko=on   printed rules, total budgets, cap 200", "runs/sgo_ko1_n5_tot.txt"),
                ("GO   5x5  ko=on   total budgets, cap 200", "runs/go_ko1_n5_tot.txt")]
    ladders += [("SGO  7x7  ko=on   THREE-TIER placement (sgo.tex <= 2026-08-25), total budgets, cap 200", "runs/sgo_ko1_n7_p3_tot.txt"),
                ("SGO  5x5  ko=on   THREE-TIER placement, total budgets, cap 200", "runs/sgo_ko1_n5_p3_tot.txt")]
    ladders += [("SGO  13x13 ko=on  THREE-TIER placement, total budgets, cap 300 / playouts 250", "runs/sgo_ko1_n13_p3_tot.txt"),
                ("GO   13x13 ko=on  total budgets, cap 600 plies / playouts 400", "runs/go_ko1_n13_tot.txt")]
    ladders += [("SGO  11x11 ko=on  THREE-TIER placement, total budgets, adaptive samples (band <= 40), cap 250 / playouts 200", "runs/sgo_ko1_n11_p3_tot.txt"),
                ("GO   11x11 ko=on  total budgets, adaptive samples (band <= 40), cap 500 plies / playouts 350", "runs/go_ko1_n11_tot.txt")]
    ladders += [("SGO  11x11 ko=on  THREE-TIER, DECEMBER 2025 wording (no adjacent q-stone for rule 2), adaptive samples", "runs/sgo_ko1_n11_p4_tot.txt")]
    ladders += [("GO   11x11 POSITIONAL SUPERKO in the games (playouts simple ko), total budgets, adaptive samples (band <= 40), cap 500 plies / playouts 350", "runs/go_ko1_n11_sk_tot.txt")]
    ladders += [("SGO  ko=off  print convention (total budget, cap 40 turns)", "runs/sgo_ko0_print.txt"),
                ("GO  ko=off  print convention (total budget, cap 80 plies)", "runs/go_ko0_print.txt")]
    for label, path in ladders:
        if True:
            rs = rows(path)
            done = os.path.exists(path) and "DONE" in open(path).read()
            print(f"== {label}  {'(complete)' if done else '(partial)'}")
            print(f"{'rung':>12} {'games':>5} {'B score':>8} {'W-D-L (A)':>10} {'gap B-A':>8} {'68% band':>14} {'turns':>6} {'|margin|':>8}")
            total = 0.0
            for r in rs:
                gap = elo(1 - r["sA"])
                lo, hi = band(r["sA"], r["n"])
                total += gap
                print(f"{r['A']:>5}v{r['B']:<6} {r['n']:>5} {1-r['sA']:>8.3f} {r['W']:>3}-{r['D']}-{r['L']:<3} {gap:>+8.0f} [{lo:>+5.0f},{hi:>+5.0f}] {r['turns']:>6.1f} {r['margin']:>8.1f}")
            if rs:
                print(f"{'height':>12} {'':>5} {'':>8} {'':>10} {total:>+8.0f}")
            print()

if __name__ == "__main__":
    os.chdir(os.path.dirname(os.path.abspath(__file__)))
    main()
