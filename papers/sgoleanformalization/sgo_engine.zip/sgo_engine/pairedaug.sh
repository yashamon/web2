#!/bin/bash
# the August wording (SGO_PLACE=3) replayed with the seeds and game counts of the December eye-defense ladder of the
# same board: identical games up to the first divergent conflict; paired comparison by game number.
# usage: pairedaug.sh <n> <cap> <pdepth>   (reads runs/sgo_ko0_n<n>_p4_ed_tot.txt for the rungs and counts)
n=$1; cap=$2; pd=$3; export SGO_N=$n
dec=runs/sgo_ko0_n${n}_p4_ed_tot.txt; out=runs/sgo_ko0_n${n}_p3_ed_tot.txt; touch $out
seed=900
grep RESULT $dec | while read line; do
  seed=$((seed+1)); A=$(echo "$line" | sed -n 's/.* A=\([0-9]*\) .*/\1/p'); B=$(echo "$line" | sed -n 's/.* B=\([0-9]*\) .*/\1/p'); g=$(echo "$line" | sed -n 's/.*games=\([0-9]*\).*/\1/p')
  if grep -q "A=$A B=$B " $out; then continue; fi
  glog=runs/sgo_ko0_n${n}_p3_ed_tot_${A}v${B}.games; elog=runs/sgo_ko0_n${n}_p3_ed_tot_${A}v${B}.log
  SGO_PLACE=3 SGO_KOFLAG=0 SGO_EYEDEF=1 SGO_DIVLOG=1 SGO_LOG=$glog SGO_STRIDE=0/2 ./sgo match sgo 0 $A $B $g $seed 0 $cap $pd 2>>$elog > runs/tmp_aug$n.0 &
  SGO_PLACE=3 SGO_KOFLAG=0 SGO_EYEDEF=1 SGO_DIVLOG=1 SGO_LOG=$glog SGO_STRIDE=1/2 ./sgo match sgo 0 $A $B $g $seed 0 $cap $pd 2>>$elog > runs/tmp_aug$n.1 &
  wait
  cat runs/tmp_aug$n.0 runs/tmp_aug$n.1 | grep RESULT | tail -1 >> $out
done
echo DONE >> $out
