#!/usr/bin/env python3
"""Paired comparison of two ladders replayed with the same seeds (identical games up to the first divergent
conflict): per rung, the two gaps, the number of games whose outcome differs, and the paired difference of the gaps
with a bootstrap standard error over game numbers; then the height difference.
usage: pairs.py <n> <tagA> <tagB>   e.g. pairs.py 13 p4_ed p3_ed  (runs/sgo_ko0_n13_<tag>_tot.txt and its .games logs)"""
import sys, re, os, math, random
n, tA, tB = sys.argv[1], sys.argv[2], sys.argv[3]
def rungs(tag):
    out = []
    for line in open(f"runs/sgo_ko0_n{n}_{tag}_tot.txt"):
        if line.startswith("RESULT"):
            kv = dict(re.findall(r"(?<![\w-])(\w+)=(\S+)", line)); out.append((int(kv["A"]), int(kv["B"]), int(kv["games"])))
    return out
def games(tag, A, B):
    d = {}
    for line in open(f"runs/sgo_ko0_n{n}_{tag}_tot_{A}v{B}.games"):
        p = line.split()
        if len(p) >= 4 and p[0] == "G": d[int(p[1])] = (float(p[2]), int(p[3]))
    return d
def elo(s):
    s = min(max(s, 0.005), 0.995); return 400 * math.log10(s / (1 - s))
def scoreB(margins, gnums):
    # the log margin is Black's area margin; A plays Black on even game numbers (colors alternate): B's score
    tot = 0.0
    for g in gnums:
        m = margins[g][0]; aBlack = (g % 2 == 0)
        sA = 0.5 if m == 0 else ((1.0 if m > 0 else 0.0) if aBlack else (1.0 if m < 0 else 0.0))
        tot += 1 - sA
    return tot / len(gnums)
random.seed(1)
tot_diff = 0.0; tot_var = 0.0
print(f"{'rung':>12} {'games':>5} {'differ':>6} {'gap '+tA:>10} {'gap '+tB:>10} {'diff':>6} {'se':>5}")
for A, B, g in rungs(tA):
    if not os.path.exists(f"runs/sgo_ko0_n{n}_{tB}_tot_{A}v{B}.games"): continue
    da, db = games(tA, A, B), games(tB, A, B); common = sorted(set(da) & set(db))
    if len(common) < g: print(f"{A:>5}v{B:<6} partial: {len(common)}/{g} games in both logs"); continue
    differ = sum(1 for k in common if da[k] != db[k])
    ga, gb = elo(scoreB(da, common)), elo(scoreB(db, common)); diff = ga - gb
    boots = []
    for _ in range(2000):
        sample = [random.choice(common) for _ in common]
        boots.append(elo(scoreB(da, sample)) - elo(scoreB(db, sample)))
    se = (sum((x - sum(boots) / len(boots)) ** 2 for x in boots) / (len(boots) - 1)) ** 0.5
    tot_diff += diff; tot_var += se * se
    print(f"{A:>5}v{B:<6} {len(common):>5} {differ:>6} {ga:>+10.0f} {gb:>+10.0f} {diff:>+6.0f} {se:>5.0f}")
print(f"height difference {tA} - {tB}: {tot_diff:+.0f} +- {math.sqrt(tot_var):.0f}")
