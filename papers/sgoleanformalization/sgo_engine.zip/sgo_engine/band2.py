#!/usr/bin/env python3
# usage: band2.py <match games log> <ngames>  -> "n sA gap halfband" over the games numbered below ngames
# (log lines "G gi margin aBlack turns ended c0 c1 c2 c3"; gap = Elo of A over B)
import sys, math
path, N = sys.argv[1], int(sys.argv[2])
seen = {}
try:
    for line in open(path):
        f = line.split()
        if len(f) >= 10 and f[0] == "G":
            g = int(f[1])
            if g < N and g not in seen:
                m = int(f[2]); ab = int(f[3]); seen[g] = 0.5 if m == 0 else (1.0 if (m > 0) == (ab == 1) else 0.0)
except FileNotFoundError:
    pass
n = len(seen)
if n == 0: print("0 0 0 999"); sys.exit()
sA = sum(seen.values()) / n
def elo(s):
    s = min(max(s, 0.005), 0.995); return 400 * math.log10(s / (1 - s))
se = math.sqrt(max(sA * (1 - sA), 1e-2) / n)
half = (elo(sA + se) - elo(sA - se)) / 2
print(f"{n} {sA:.3f} {elo(sA):+.0f} {half:.0f}")
