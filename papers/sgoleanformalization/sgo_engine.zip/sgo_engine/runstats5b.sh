#!/bin/bash
# branch reduce (2026-11-14): the cycle count of Section 7.2 (the Go playout convention read literally, without the
# eye defense) under Condition (4) of def_captured.
out=runs/stats5b.txt; : > $out
run() { echo "## $*" >> $out; env "$@" 2>/dev/null >> $out; }
run SGO_ORPHAN=1 SGO_PLACE=4 ./sgo eqplay 1000 16 5 400
echo DONE >> $out
