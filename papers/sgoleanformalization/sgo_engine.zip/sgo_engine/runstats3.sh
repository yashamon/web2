#!/bin/bash
out=runs/stats3.txt; : > $out
run() { echo "## $*" >> $out; env "$@" 2>/dev/null >> $out; }
run ./sgo greedygo 1000 6 12 5 800
run SGO_KO=1 ./sgo greedygo 1000 6 12 5 800
run SGO_PLACE=3 ./sgo eqplay 1000 16 5 400
run SGO_KO=1 SGO_PLACE=3 ./sgo eqplay 1000 16 5 400
run ./sgo eqplay 1000 16 5 400
run SGO_PLACE=3 ./sgo table sgo 1000 40
run SGO_PLACE=3 ./sgo table sgo 1000 0
run ./sgo table go 1000 40
run SGO_N=19 SGO_PLACE=3 ./sgo table sgo 1000 0
run SGO_N=19 ./sgo table go 200 1500
run SGO_NOCAP=1 SGO_PLACE=3 ./sgo table sgo 500 40
run SGO_NOCAP=1 ./sgo table sgo 500 40
run ./sgo table sgo 1000 40
run SGO_N=19 ./sgo table sgo 1000 0
echo DONE >> $out
