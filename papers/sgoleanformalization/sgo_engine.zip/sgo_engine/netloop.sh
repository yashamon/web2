#!/bin/bash
# the self-play training loop: generation k = self-play with nets/g$k.bin (two processes), training on the last three
# generations -> nets/g$((k+1)).bin, evaluation against the Monte Carlo agent; resumable (a partial generation's
# data is discarded and redone).  usage: netloop.sh <first_gen> <last_gen> [games_per_process=150] [sims=100]
cd /home/claude/eng
k=$1; last=$2; G=${3:-150}; S=${4:-100}
while [ $k -le $last ]; do
  if [ ! -f nets/g$k.bin ]; then echo "no nets/g$k.bin"; exit 1; fi
  if [ ! -f data/g${k}.done ]; then
    ./sgonet selfplay nets/g$k.bin $G $S data/g${k}_a.dat $((1000+k)) 2>runs/net_selfplay_g${k}_a.log > runs/tmp_sp_a.txt &
    ./sgonet selfplay nets/g$k.bin $G $S data/g${k}_b.dat $((2000+k)) 2>runs/net_selfplay_g${k}_b.log > runs/tmp_sp_b.txt &
    wait
    { echo "## generation $k"; cat runs/tmp_sp_a.txt runs/tmp_sp_b.txt; } >> runs/net_selfplay.txt
    touch data/g${k}.done
  fi
  if [ ! -f nets/g$((k+1)).bin ]; then
    files=""; for j in $k $((k-1)) $((k-2)); do [ $j -ge 0 ] && files="$files data/g${j}_a.dat data/g${j}_b.dat"; done
    lr=0.001; [ $k -ge 10 ] && lr=0.0003; [ $k -ge 20 ] && lr=0.0001
    { echo "## generation $k -> $((k+1))"; ./sgonet train nets/g$k.bin nets/g$((k+1)).bin 2 $lr $files; } >> runs/net_train.txt 2>&1
  fi
  if [ ! -f runs/net_eval_g$((k+1)).txt ]; then
    ./sgonet eval nets/g$((k+1)).bin $S 205 30 $((3000+k)) 2>/dev/null > runs/net_eval_g$((k+1)).txt
    { echo -n "g$((k+1)): "; cat runs/net_eval_g$((k+1)).txt; } >> runs/net_eval.txt
  fi
  k=$((k+1))
done
