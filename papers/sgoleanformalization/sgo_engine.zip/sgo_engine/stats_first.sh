#!/bin/bash
# the cheap statistics first, at normal priority
cd /home/claude/eng; grep -q '^DONE' runs/stats5.txt 2>/dev/null || ./runstats5.sh
