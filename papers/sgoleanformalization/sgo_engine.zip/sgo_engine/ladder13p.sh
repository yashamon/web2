#!/bin/bash
# ladder13a.sh with two processes per rung (SGO_STRIDE 0/2 and 1/2 share one game log): 13x13, adaptive samples
# until the 68% band half-width is <= BAND Elo (min MIN, max MAX games), rungs to 1638v3277 regardless of saturation.
# usage: ladder13p.sh <sgo|go> <cap> <pdepth> [BAND=40] [MIN=100] [MAX=600]; honors SGO_N (default 13), SGO_PLACE,
# SGO_SUPERKO (_sk tag), SGO_KOFLAG (fiat ko flag, default 1), SGO_EYEDEF (_ed tag: own-eye defense in the policy),
# SGO_KOMI (komi for Go, default 0; _komi<k> tag)
game=$1; cap=$2; pd=$3; band=${4:-40}; min=${5:-100}; max=${6:-600}; n=${SGO_N:-13}; export SGO_N=$n; ko=${SGO_KOFLAG:-1}; komi=${SGO_KOMI:-0}
tag="_n${n}${SGO_SIMP:+_simp}${SGO_PLACE:+_p$SGO_PLACE}${SGO_SUPERKO:+_sk}${SGO_EYEDEF:+_ed}${SGO_KOMI:+_komi$SGO_KOMI}_tot"; out=runs/${game}_ko${ko}${tag}.txt; touch $out
budgets="0 3 26 205 410 819 1638 3277"
prev=""; seed=900
for b in $budgets; do
  if [ -n "$prev" ]; then
    seed=$((seed+1)); glog=runs/${game}_ko${ko}${tag}_${prev}v${b}.games; elog=runs/${game}_ko${ko}${tag}_${prev}v${b}.log
    line=$(grep "A=$prev B=$b " $out | tail -1)
    if [ -z "$line" ]; then
      g=$min
      while :; do
        res=runs/tmp_${game}${tag}
        SGO_LOG=$glog SGO_STRIDE=0/2 ./sgo match $game $ko $prev $b $g $seed $komi $cap $pd 2>>$elog > $res.0 &
        SGO_LOG=$glog SGO_STRIDE=1/2 ./sgo match $game $ko $prev $b $g $seed $komi $cap $pd 2>>$elog > $res.1 &
        wait
        read cnt sB gap half < <(python3 band.py $glog $g)
        echo "rung $prev v $b: $cnt games, B score $sB, gap $gap, band ±$half" >> $elog
        if [ "$half" -le "$band" ] || [ "$g" -ge "$max" ]; then break; fi
        g=$(python3 -c "import math; print(min($max, max($g+50, int(math.ceil($g*($half/$band)**2/50.0))*50)))")
      done
      cat $res.0 $res.1 | grep RESULT | tail -1 >> $out
    fi
  fi
  prev=$b
done
echo DONE >> $out
