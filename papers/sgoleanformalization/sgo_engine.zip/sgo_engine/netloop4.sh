#!/bin/bash
# the self-play training loop, one instance per placement rule:
#   netloop4.sh dec <first_gen> <last_gen> [games_per_process=150] [sims=100]   December wording (SGO_PLACE=4), nets/ data/
#   netloop4.sh aug <first_gen> <last_gen> [games_per_process=150] [sims=100]   August wording (SGO_PLACE=3), nets_aug/ data_aug/
#   netloop4.sh simple <first_gen> <last_gen> [games_per_process=150] [sims=100]   one-tier rule (SGO_PLACE=1), nets_simple/ data_simple/
# Generation k: self-play with <nets>/g$k.bin (two processes, seeds 1000+k and 2000+k), training on the last three
# generations -> <nets>/g$((k+1)).bin, then a 30-game match of the new net against the fork base nets/g13.bin (both at
# <sims> simulations, under the loop's rules) as the progress measure.  The August loop was forked from the December
# loop at g13 (nets_aug/g13.bin = nets/g13.bin); generations before the fork are read from the December data, so the
# two loops are paired: same seeds, games and simulations, differing only in the rule.  Resumable at every step.
cd /home/claude/eng
tag=$1; k=$2; last=$3; G=${4:-150}; S=${5:-100}
if [ "$tag" = dec ]; then export SGO_PLACE=4; nets=nets; data=data; sfx=""; elif [ "$tag" = aug ]; then export SGO_PLACE=3; nets=nets_aug; data=data_aug; sfx="_aug"; elif [ "$tag" = simple ]; then export SGO_PLACE=1; nets=nets_simple; data=data_simple; sfx="_simple"; else echo "tag dec|aug|simple"; exit 1; fi
REF=nets/g13.bin
while [ $k -le $last ]; do
  if [ ! -f $nets/g$k.bin ]; then echo "no $nets/g$k.bin"; exit 1; fi
  if [ ! -f $data/g${k}.done ]; then
    ./sgonet selfplay $nets/g$k.bin $G $S $data/g${k}_a.dat $((1000+k)) 2>>runs/net_selfplay${sfx}_g${k}_a.log > runs/tmp_sp${sfx}_a.txt &
    ./sgonet selfplay $nets/g$k.bin $G $S $data/g${k}_b.dat $((2000+k)) 2>>runs/net_selfplay${sfx}_g${k}_b.log > runs/tmp_sp${sfx}_b.txt &
    wait
    { echo "## generation $k"; cat runs/tmp_sp${sfx}_a.txt runs/tmp_sp${sfx}_b.txt; } >> runs/net_selfplay${sfx}.txt
    touch $data/g${k}.done
  fi
  if [ ! -f $nets/g$((k+1)).bin ]; then
    files=""; for j in $k $((k-1)) $((k-2)); do
      if [ $j -ge 0 ]; then if [ -f $data/g${j}_a.dat ]; then files="$files $data/g${j}_a.dat $data/g${j}_b.dat"; else files="$files data/g${j}_a.dat data/g${j}_b.dat"; fi; fi; done
    lr=0.001; [ $k -ge 10 ] && lr=0.0003; [ $k -ge 20 ] && lr=0.0001
    { echo "## generation $k -> $((k+1))"; ./sgonet train $nets/g$k.bin $nets/g$((k+1)).bin 2 $lr $files; } >> runs/net_train${sfx}.txt 2>&1
  fi
  if [ ! -f runs/net_ref${sfx}_g$((k+1)).txt ]; then
    ./sgonet match $nets/g$((k+1)).bin $S $REF $S 30 $((4000+k)) 200 runs/net_ref${sfx}_g$((k+1)).games 2>/dev/null > runs/net_ref${sfx}_g$((k+1)).tmp \
      && mv runs/net_ref${sfx}_g$((k+1)).tmp runs/net_ref${sfx}_g$((k+1)).txt
    { echo -n "g$((k+1)): "; cat runs/net_ref${sfx}_g$((k+1)).txt; } >> runs/net_ref${sfx}.txt
  fi
  k=$((k+1))
done
