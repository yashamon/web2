#!/bin/bash
# the statistics of sgo.tex §2.2 / §7.1 / §7.2, recomputed with the fast engine; SGo with the three-tier placement
# (and, for comparison, the minimal rule).  Output: runs/stats.txt
out=runs/stats2.txt; : > $out
run() { echo "## $*" >> $out; env "$@" 2>/dev/null >> $out; }
run SGO_PLACE=3 ./sgo table sgo 1000 40
run SGO_PLACE=3 ./sgo table sgo 1000 0
run ./sgo table sgo 1000 40
run ./sgo table go 1000 40
run SGO_N=19 SGO_PLACE=3 ./sgo table sgo 1000 0
run SGO_N=19 ./sgo table sgo 1000 0
run SGO_N=19 ./sgo table go 200 1500
run SGO_NOCAP=1 SGO_PLACE=3 ./sgo table sgo 500 40
run SGO_NOCAP=1 ./sgo table sgo 500 40
run SGO_PLACE=3 ./sgo eqplay 1000 16 5 400
run SGO_KO=1 SGO_PLACE=3 ./sgo eqplay 1000 16 5 400
run ./sgo eqplay 1000 16 5 400
run ./sgo greedygo 1000 6 12 5 800
run SGO_KO=1 ./sgo greedygo 1000 6 12 5 800
echo DONE >> $out
