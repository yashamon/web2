#!/bin/bash
# usage: ladder.sh <sgo|go> <ko> ; writes runs/<game>_ko<ko>.txt
game=$1; ko=$2; tag=${SGO_SIMP:+_simp}; out=runs/${game}_ko${ko}${tag}.txt; : > $out
pairs="0:16:100 16:128:100 128:1024:100 1024:2048:100 2048:4096:60"
seed=100
for p in $pairs; do a=${p%%:*}; rest=${p#*:}; b=${rest%%:*}; g=${rest#*:}; seed=$((seed+1))
  ./sgo match $game $ko $a $b $g $seed 2>runs/${game}_ko${ko}${tag}_${a}v${b}.log | tee -a $out
done
echo DONE >> $out
