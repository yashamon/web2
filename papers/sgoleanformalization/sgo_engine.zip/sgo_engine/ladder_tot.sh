#!/bin/bash
# total-budget rungs (16/128/1024/2048/4096 playouts per turn ≈ 3/26/205/410/819 per candidate), resumable.
# usage: ladder_tot.sh <sgo|go> <ko> <cap> ; honors SGO_N, SGO_SIMP, SGO_PLACE; writes runs/<game>_ko<ko>_n<N><_simp>_tot.txt
game=$1; ko=$2; cap=$3; n=${SGO_N:-5}; tag="_n${n}${SGO_SIMP:+_simp}${SGO_PLACE:+_p$SGO_PLACE}_tot"; out=runs/${game}_ko${ko}${tag}.txt; touch $out
pairs="0:3:100 3:26:100 26:205:100 205:410:100 410:819:60"
seed=300
for p in $pairs; do a=${p%%:*}; rest=${p#*:}; b=${rest%%:*}; g=${rest#*:}; seed=$((seed+1))
  grep -q "A=$a B=$b " $out && continue
  ./sgo match $game $ko $a $b $g $seed 0 $cap 2>runs/${game}_ko${ko}${tag}_${a}v${b}.log | tee -a $out
done
echo DONE >> $out
