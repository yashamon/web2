// sgonet.cpp — AlphaZero-style self-play training for SGo on a small board, CPU only, no dependencies.
// Builds on the engine (sgo.cpp, included below): the printed rules of the December text (SGO_PLACE=4), no ko rule.
//   net: 8 input planes -> conv3x3(C) -> NB residual blocks (conv3x3, ReLU, conv3x3, add, ReLU) -> policy head
//        (1x1 conv to 2, FC 162 -> 82 for Black and for White) and value head (1x1 conv to 1, FC 81 -> 64 -> 1, tanh);
//        value = Black's result, policies = each player's move distribution; plain biases, no normalization.
//   search: decoupled PUCT for simultaneous moves — each player keeps prior/visit/value statistics over its own
//        actions at a node, selects independently, the joint action indexes the child; backup v for Black, -v for White.
//   self-play: S simulations per turn, Dirichlet noise at the root, moves sampled from the visit counts (tau=1 for the
//        first 20 turns, then the maximum); the result z = sign(area margin); samples = (planes, visit policies, z).
//   training: manual backpropagation, Adam, dihedral augmentation; weights and optimizer state in one binary file.
// usage:
//   sgonet init <weights> [seed]                         random weights
//   sgonet selfplay <weights> <games> <sims> <out.dat> <seed> [cap]   self-play, data + a line per game on stderr
//   sgonet train <weights_in> <weights_out> <epochs> <lr> <file1.dat> [file2.dat ...]
//   sgonet eval <weights> <sims> <budget> <games> <seed>   the net (tau=0) against the Monte Carlo agent of the paper
//   sgonet census <weights> <games> <sims> <seed>          self-play conflict census only
//   sgonet match <wA> <simsA> <wB> <simsB> <games> <seed> <cap> <log>   net A against net B (both tau=0), colors
//        alternating, a line per game appended to <log> (resumable), conflict census of the games
//   sgonet arena <specA> <specB> <games> <seed> <cap> <log>   any two agents: mc<budget> or net:<weights>@<sims>
//   sgonet goselfplay <weights> <games> <sims> <out.dat> <seed> [cap plies]   9x9 Go (positional superko, komi SGO_KOMI=7.5)
//   sgonet goarena <specA> <specB> <games> <seed> <cap plies> <log>           two Go agents (mc<budget> | net:<weights>@<sims>)
//   (train is shared: SGO_GO=1 selects the Go color-swap augmentation)
//   env: SGO_PLACE (placement rule: 1 one-tier, 3 August, 4 December = default), SGO_MIX (leaf blend, default 0.5),
//        SGO_TAU (match/eval move choice: 0 = most visited, default; t > 0 samples from visits^(1/t)), SGO_STRIDE=k/m (match)
#define main engine_main
#include "sgo.cpp"
#undef main
#include <cmath>
#include <cstring>
#include <string>
#include <vector>
#include <unordered_map>
#include <unordered_set>
#include <random>
#include <algorithm>
#include <fstream>
#include <chrono>
#include <array>

static const int BN_ = 9, NN = 81, NA = 82, NP = 8, CF = 32, NBLK = 4, PH = 2, VH = 64;

// ---------- the net ----------
struct Tensor { std::vector<float> w, g, m, v; void init(size_t n) { w.assign(n, 0); g.assign(n, 0); m.assign(n, 0); v.assign(n, 0); } };
struct Net {
  Tensor cin_w, cin_b;                       // [CF][NP][9], [CF]
  Tensor b1w[NBLK], b1b[NBLK], b2w[NBLK], b2b[NBLK];  // [CF][CF][9], [CF]
  Tensor pc_w, pc_b;                         // [PH][CF], [PH]
  Tensor pfB_w, pfB_b, pfW_w, pfW_b;         // [NA][PH*NN], [NA]
  Tensor vc_w, vc_b;                         // [1][CF], [1]
  Tensor vf1_w, vf1_b, vf2_w, vf2_b;         // [VH][NN], [VH], [1][VH], [1]
  long step = 0;
  std::vector<Tensor*> all() {
    std::vector<Tensor*> t = {&cin_w, &cin_b};
    for (int k = 0; k < NBLK; k++) { t.push_back(&b1w[k]); t.push_back(&b1b[k]); t.push_back(&b2w[k]); t.push_back(&b2b[k]); }
    for (Tensor* x : {&pc_w, &pc_b, &pfB_w, &pfB_b, &pfW_w, &pfW_b, &vc_w, &vc_b, &vf1_w, &vf1_b, &vf2_w, &vf2_b}) t.push_back(x);
    return t;
  }
  void alloc() {
    cin_w.init((size_t)CF * NP * 9); cin_b.init(CF);
    for (int k = 0; k < NBLK; k++) { b1w[k].init((size_t)CF * CF * 9); b1b[k].init(CF); b2w[k].init((size_t)CF * CF * 9); b2b[k].init(CF); }
    pc_w.init(PH * CF); pc_b.init(PH); pfB_w.init((size_t)NA * PH * NN); pfB_b.init(NA); pfW_w.init((size_t)NA * PH * NN); pfW_b.init(NA);
    vc_w.init(CF); vc_b.init(1); vf1_w.init((size_t)VH * NN); vf1_b.init(VH); vf2_w.init(VH); vf2_b.init(1);
  }
  void randomize(uint64_t seed) {
    std::mt19937_64 r(seed); std::normal_distribution<float> nd(0, 1);
    auto he = [&](Tensor& t, int fanin, float scale) { for (auto& x : t.w) x = nd(r) * scale / std::sqrt((float)fanin); };
    he(cin_w, NP * 9, std::sqrt(2.0f));
    for (int k = 0; k < NBLK; k++) { he(b1w[k], CF * 9, std::sqrt(2.0f)); he(b2w[k], CF * 9, 0.5f); }
    he(pc_w, CF, std::sqrt(2.0f)); he(pfB_w, PH * NN, 0.3f); he(pfW_w, PH * NN, 0.3f); he(vc_w, CF, std::sqrt(2.0f)); he(vf1_w, NN, std::sqrt(2.0f)); he(vf2_w, VH, 0.3f);
  }
  bool save(const char* path) {
    FILE* f = fopen(path, "wb"); if (!f) return false; const char magic[4] = {'S', 'G', 'N', '2'}; fwrite(magic, 1, 4, f);
    int hdr[6] = {NP, CF, NBLK, NN, NA, (int)step}; fwrite(hdr, sizeof(int), 6, f);
    for (Tensor* t : all()) { fwrite(t->w.data(), sizeof(float), t->w.size(), f); fwrite(t->m.data(), sizeof(float), t->m.size(), f); fwrite(t->v.data(), sizeof(float), t->v.size(), f); }
    fclose(f); return true;
  }
  bool load(const char* path) {
    FILE* f = fopen(path, "rb"); if (!f) return false; char magic[4]; if (fread(magic, 1, 4, f) != 4 || memcmp(magic, "SGN2", 4)) { fclose(f); return false; }
    int hdr[6]; if (fread(hdr, sizeof(int), 6, f) != 6 || hdr[0] != NP || hdr[1] != CF || hdr[2] != NBLK || hdr[3] != NN || hdr[4] != NA) { fclose(f); return false; }
    step = hdr[5];
    for (Tensor* t : all()) { if (fread(t->w.data(), sizeof(float), t->w.size(), f) != t->w.size()) { fclose(f); return false; }
      if (fread(t->m.data(), sizeof(float), t->m.size(), f) != t->m.size() || fread(t->v.data(), sizeof(float), t->v.size(), f) != t->v.size()) { fclose(f); return false; } }
    fclose(f); return true;
  }
  void zeroGrad() { for (Tensor* t : all()) std::fill(t->g.begin(), t->g.end(), 0.0f); }
  void adam(float lr, float wd, int batch) {
    step++; float b1 = 0.9f, b2 = 0.999f, eps = 1e-8f; float c1 = 1 - std::pow(b1, (float)step), c2 = 1 - std::pow(b2, (float)step);
    for (Tensor* t : all()) { bool isW = t->w.size() > 256; // decay the matrices, not the biases
      for (size_t i = 0; i < t->w.size(); i++) { float g = t->g[i] / batch + (isW ? wd * t->w[i] : 0.0f);
        t->m[i] = b1 * t->m[i] + (1 - b1) * g; t->v[i] = b2 * t->v[i] + (1 - b2) * g * g;
        t->w[i] -= lr * (t->m[i] / c1) / (std::sqrt(t->v[i] / c2) + eps); } }
  }
};

// geometry of the 3x3 convolution on the 9x9 board with zero padding
static int NBR9[NN][9]; // neighbour index for each of the 9 offsets, -1 off board
static void geomInit() { for (int y = 0; y < BN_; y++) for (int x = 0; x < BN_; x++) for (int dy = -1; dy <= 1; dy++) for (int dx = -1; dx <= 1; dx++) {
  int yy = y + dy, xx = x + dx; NBR9[y * BN_ + x][(dy + 1) * 3 + (dx + 1)] = (yy >= 0 && yy < BN_ && xx >= 0 && xx < BN_) ? yy * BN_ + xx : -1; } }
// out[co][p] = b[co] + sum_{ci,k} w[co][ci][k] * in[ci][nbr(p,k)]
static void conv3_ref(const float* in, int cin, const float* w, const float* b, int cout, float* out) {
  for (int co = 0; co < cout; co++) { float* o = out + co * NN; for (int p = 0; p < NN; p++) o[p] = b[co];
    for (int ci = 0; ci < cin; ci++) { const float* wk = w + ((size_t)co * cin + ci) * 9; const float* ip = in + ci * NN;
      for (int k = 0; k < 9; k++) { float wv = wk[k]; if (wv == 0) continue; for (int p = 0; p < NN; p++) { int q = NBR9[p][k]; if (q >= 0) o[p] += wv * ip[q]; } } } }
}
// gradients: din (accumulated), dw, db from dout
static void conv3Back_ref(const float* in, int cin, const float* w, int cout, const float* dout, float* din, float* dw, float* db) {
  for (int co = 0; co < cout; co++) { const float* d = dout + co * NN; for (int p = 0; p < NN; p++) db[co] += d[p];
    for (int ci = 0; ci < cin; ci++) { float* dwk = dw + ((size_t)co * cin + ci) * 9; const float* wk = w + ((size_t)co * cin + ci) * 9; const float* ip = in + ci * NN; float* dip = din ? din + ci * NN : nullptr;
      for (int k = 0; k < 9; k++) { float s = 0, wv = wk[k]; for (int p = 0; p < NN; p++) { int q = NBR9[p][k]; if (q >= 0) { s += d[p] * ip[q]; if (dip) dip[q] += d[p] * wv; } } dwk[k] += s; } } }
}
// The same two maps as matrix products (2026-11-13, about 5x faster; the sums run in another order, so the results
// agree with the _ref versions up to float rounding — `sgonet convtest` measures it): col[ci*9+k][p] = in[ci][nbr(p,k)],
// out = W col with W = w as a [cout][cin*9] matrix; dW = dout col^T, dcol = W^T dout, din = col2im(dcol).
static bool g_refconv = false; // SGO_REFCONV=1: the original loops
static void im2col(const float* in, int cin, float* col) {
  for (int ci = 0; ci < cin; ci++) { const float* ip = in + ci * NN;
    for (int k = 0; k < 9; k++) { float* c = col + (size_t)(ci * 9 + k) * NN; for (int p = 0; p < NN; p++) { int q = NBR9[p][k]; c[p] = q >= 0 ? ip[q] : 0.0f; } } }
}
static void conv3(const float* in, int cin, const float* w, const float* b, int cout, float* out) {
  if (g_refconv) { conv3_ref(in, cin, w, b, cout, out); return; }
  alignas(64) static float col[CF * 9 * NN]; im2col(in, cin, col); const int J = cin * 9;
  int co = 0;
  for (; co + 4 <= cout; co += 4) { // a 4 x 16 block of outputs in registers; the last position (p = 80) separately
    const float* w0 = w + (size_t)co * J; const float* w1 = w0 + J; const float* w2 = w1 + J; const float* w3 = w2 + J;
    for (int p0 = 0; p0 + 16 <= NN; p0 += 16) {
      float r0[16], r1[16], r2[16], r3[16];
      for (int q = 0; q < 16; q++) { r0[q] = b[co]; r1[q] = b[co + 1]; r2[q] = b[co + 2]; r3[q] = b[co + 3]; }
      for (int j = 0; j < J; j++) { const float a0 = w0[j], a1 = w1[j], a2 = w2[j], a3 = w3[j]; const float* __restrict c = col + (size_t)j * NN + p0;
#pragma omp simd
        for (int q = 0; q < 16; q++) { float cv = c[q]; r0[q] += a0 * cv; r1[q] += a1 * cv; r2[q] += a2 * cv; r3[q] += a3 * cv; } }
      for (int q = 0; q < 16; q++) { out[co * NN + p0 + q] = r0[q]; out[(co + 1) * NN + p0 + q] = r1[q]; out[(co + 2) * NN + p0 + q] = r2[q]; out[(co + 3) * NN + p0 + q] = r3[q]; } }
    for (int p = NN - NN % 16; p < NN; p++) { float s0 = b[co], s1 = b[co + 1], s2 = b[co + 2], s3 = b[co + 3];
      for (int j = 0; j < J; j++) { float cv = col[(size_t)j * NN + p]; s0 += w0[j] * cv; s1 += w1[j] * cv; s2 += w2[j] * cv; s3 += w3[j] * cv; }
      out[co * NN + p] = s0; out[(co + 1) * NN + p] = s1; out[(co + 2) * NN + p] = s2; out[(co + 3) * NN + p] = s3; } }
  for (; co < cout; co++) { float* __restrict o = out + co * NN; for (int p = 0; p < NN; p++) o[p] = b[co];
    const float* wr = w + (size_t)co * J;
    for (int j = 0; j < J; j++) { const float a = wr[j]; const float* __restrict c = col + (size_t)j * NN;
#pragma omp simd
      for (int p = 0; p < NN; p++) o[p] += a * c[p]; } }
}
static void conv3Back(const float* in, int cin, const float* w, int cout, const float* dout, float* din, float* dw, float* db) {
  if (g_refconv) { conv3Back_ref(in, cin, w, cout, dout, din, dw, db); return; }
  alignas(64) static float col[CF * 9 * NN], dcol[CF * 9 * NN]; im2col(in, cin, col); const int J = cin * 9;
  for (int co = 0; co < cout; co++) { const float* __restrict d = dout + co * NN; float s = 0;
#pragma omp simd reduction(+:s)
    for (int p = 0; p < NN; p++) s += d[p];
    db[co] += s; float* dwr = dw + (size_t)co * J;
    for (int j = 0; j < J; j++) { const float* __restrict c = col + (size_t)j * NN; float t = 0;
#pragma omp simd reduction(+:t)
      for (int p = 0; p < NN; p++) t += d[p] * c[p];
      dwr[j] += t; } }
  if (!din) return;
  std::fill(dcol, dcol + (size_t)J * NN, 0.0f);
  for (int co = 0; co < cout; co++) { const float* __restrict d = dout + co * NN; const float* wr = w + (size_t)co * J;
    for (int j = 0; j < J; j++) { const float a = wr[j]; float* __restrict dc = dcol + (size_t)j * NN;
#pragma omp simd
      for (int p = 0; p < NN; p++) dc[p] += a * d[p]; } }
  for (int ci = 0; ci < cin; ci++) { float* dip = din + ci * NN;
    for (int k = 0; k < 9; k++) { const float* dc = dcol + (size_t)(ci * 9 + k) * NN; for (int p = 0; p < NN; p++) { int q = NBR9[p][k]; if (q >= 0) dip[q] += dc[p]; } } }
}
struct Act { // the activations of one forward pass, kept for the backward pass
  float x[NP * NN]; float h0[CF * NN]; float a[NBLK][CF * NN]; float c[NBLK][CF * NN]; float h[NBLK][CF * NN];
  float ph[PH * NN]; float pB[NA], pW[NA]; float vh[NN]; float v1[VH]; float v;
};
static void forward(const Net& n, const float* planes, Act& A) {
  memcpy(A.x, planes, sizeof(float) * NP * NN);
  conv3(A.x, NP, n.cin_w.w.data(), n.cin_b.w.data(), CF, A.h0); for (int i = 0; i < CF * NN; i++) if (A.h0[i] < 0) A.h0[i] = 0;
  const float* hin = A.h0;
  for (int k = 0; k < NBLK; k++) {
    conv3(hin, CF, n.b1w[k].w.data(), n.b1b[k].w.data(), CF, A.a[k]); for (int i = 0; i < CF * NN; i++) if (A.a[k][i] < 0) A.a[k][i] = 0;
    conv3(A.a[k], CF, n.b2w[k].w.data(), n.b2b[k].w.data(), CF, A.c[k]);
    for (int i = 0; i < CF * NN; i++) { float s = A.c[k][i] + hin[i]; A.h[k][i] = s > 0 ? s : 0; }
    hin = A.h[k];
  }
  // policy head
  for (int j = 0; j < PH; j++) for (int p = 0; p < NN; p++) { float s = n.pc_b.w[j]; for (int ci = 0; ci < CF; ci++) s += n.pc_w.w[j * CF + ci] * hin[ci * NN + p]; A.ph[j * NN + p] = s > 0 ? s : 0; }
  for (int a = 0; a < NA; a++) { float sB = n.pfB_b.w[a], sW = n.pfW_b.w[a]; const float* wB = n.pfB_w.w.data() + (size_t)a * PH * NN; const float* wW = n.pfW_w.w.data() + (size_t)a * PH * NN;
    for (int i = 0; i < PH * NN; i++) { sB += wB[i] * A.ph[i]; sW += wW[i] * A.ph[i]; } A.pB[a] = sB; A.pW[a] = sW; }
  // value head
  for (int p = 0; p < NN; p++) { float s = n.vc_b.w[0]; for (int ci = 0; ci < CF; ci++) s += n.vc_w.w[ci] * hin[ci * NN + p]; A.vh[p] = s > 0 ? s : 0; }
  for (int j = 0; j < VH; j++) { float s = n.vf1_b.w[j]; const float* w = n.vf1_w.w.data() + (size_t)j * NN; for (int p = 0; p < NN; p++) s += w[p] * A.vh[p]; A.v1[j] = s > 0 ? s : 0; }
  { float s = n.vf2_b.w[0]; for (int j = 0; j < VH; j++) s += n.vf2_w.w[j] * A.v1[j]; A.v = std::tanh(s); }
}
static void softmax(const float* logit, float* out, int n) { float mx = -1e30f; for (int i = 0; i < n; i++) mx = std::max(mx, logit[i]); float s = 0; for (int i = 0; i < n; i++) { out[i] = std::exp(logit[i] - mx); s += out[i]; } for (int i = 0; i < n; i++) out[i] /= s; }
// backward for one sample: targets tB, tW (distributions over NA), z; returns the loss terms
static void backward(Net& n, const Act& A, const float* tB, const float* tW, float z, double* lossP, double* lossV) {
  float sB[NA], sW[NA]; softmax(A.pB, sB, NA); softmax(A.pW, sW, NA);
  double lp = 0; for (int a = 0; a < NA; a++) { if (tB[a] > 0) lp -= tB[a] * std::log(sB[a] + 1e-12f); if (tW[a] > 0) lp -= tW[a] * std::log(sW[a] + 1e-12f); }
  *lossP += lp; *lossV += (A.v - z) * (A.v - z);
  float sumB = 0, sumW = 0; for (int a = 0; a < NA; a++) { sumB += tB[a]; sumW += tW[a]; } // gradient of -sum t log s wrt the logits is s*sum(t) - t: an all-zero target (Go: the head of the player not to move) gets no gradient
  float dlogB[NA], dlogW[NA]; for (int a = 0; a < NA; a++) { dlogB[a] = sB[a] * sumB - tB[a]; dlogW[a] = sW[a] * sumW - tW[a]; }
  const float* hin = NBLK ? A.h[NBLK - 1] : A.h0;
  static float dh[CF * NN], dph[PH * NN], dvh[NN], dv1[VH], da[CF * NN], dc[CF * NN], dhin[CF * NN];
  std::fill(dh, dh + CF * NN, 0.0f);
  // policy FC
  std::fill(dph, dph + PH * NN, 0.0f);
  for (int a = 0; a < NA; a++) { n.pfB_b.g[a] += dlogB[a]; n.pfW_b.g[a] += dlogW[a]; float* gB = n.pfB_w.g.data() + (size_t)a * PH * NN; float* gW = n.pfW_w.g.data() + (size_t)a * PH * NN; const float* wB = n.pfB_w.w.data() + (size_t)a * PH * NN; const float* wW = n.pfW_w.w.data() + (size_t)a * PH * NN;
    for (int i = 0; i < PH * NN; i++) { gB[i] += dlogB[a] * A.ph[i]; gW[i] += dlogW[a] * A.ph[i]; dph[i] += dlogB[a] * wB[i] + dlogW[a] * wW[i]; } }
  for (int j = 0; j < PH; j++) for (int p = 0; p < NN; p++) { float d = A.ph[j * NN + p] > 0 ? dph[j * NN + p] : 0; if (d == 0) continue; n.pc_b.g[j] += d; for (int ci = 0; ci < CF; ci++) { n.pc_w.g[j * CF + ci] += d * hin[ci * NN + p]; dh[ci * NN + p] += d * n.pc_w.w[j * CF + ci]; } }
  // value head: dL/dv = 2 (v - z); through tanh
  float dv = 2 * (A.v - z) * (1 - A.v * A.v);
  n.vf2_b.g[0] += dv; for (int j = 0; j < VH; j++) { n.vf2_w.g[j] += dv * A.v1[j]; dv1[j] = A.v1[j] > 0 ? dv * n.vf2_w.w[j] : 0; }
  std::fill(dvh, dvh + NN, 0.0f);
  for (int j = 0; j < VH; j++) { if (dv1[j] == 0) continue; n.vf1_b.g[j] += dv1[j]; float* g = n.vf1_w.g.data() + (size_t)j * NN; const float* w = n.vf1_w.w.data() + (size_t)j * NN; for (int p = 0; p < NN; p++) { g[p] += dv1[j] * A.vh[p]; dvh[p] += dv1[j] * w[p]; } }
  for (int p = 0; p < NN; p++) { float d = A.vh[p] > 0 ? dvh[p] : 0; if (d == 0) continue; n.vc_b.g[0] += d; for (int ci = 0; ci < CF; ci++) { n.vc_w.g[ci] += d * hin[ci * NN + p]; dh[ci * NN + p] += d * n.vc_w.w[ci]; } }
  // residual tower
  for (int k = NBLK - 1; k >= 0; k--) {
    const float* hprev = k ? A.h[k - 1] : A.h0;
    for (int i = 0; i < CF * NN; i++) dc[i] = A.h[k][i] > 0 ? dh[i] : 0;   // through the final ReLU of the block
    std::fill(da, da + CF * NN, 0.0f);
    conv3Back(A.a[k], CF, n.b2w[k].w.data(), CF, dc, da, n.b2w[k].g.data(), n.b2b[k].g.data());
    for (int i = 0; i < CF * NN; i++) if (A.a[k][i] <= 0) da[i] = 0;
    std::fill(dhin, dhin + CF * NN, 0.0f);
    conv3Back(hprev, CF, n.b1w[k].w.data(), CF, da, dhin, n.b1w[k].g.data(), n.b1b[k].g.data());
    for (int i = 0; i < CF * NN; i++) dh[i] = dhin[i] + dc[i];              // the skip connection
  }
  for (int i = 0; i < CF * NN; i++) if (A.h0[i] <= 0) dh[i] = 0;
  conv3Back(A.x, NP, n.cin_w.w.data(), CF, dh, nullptr, n.cin_w.g.data(), n.cin_b.g.data());
}

// ---------- planes, symmetries ----------
static void planes(const SGoGame& g, float* x) {
  int t = g.next; std::fill(x, x + NP * NN, 0.0f);
  for (int p = 0; p < NN; p++) { int k = g.P.D.kind[p], st = g.P.D.stamp[p];
    if (k == B) x[0 * NN + p] = 1; if (k == W) x[1 * NN + p] = 1; if (k == R) x[2 * NN + p] = 1;
    if (k == B && st == t - 1) x[3 * NN + p] = 1; if (k == W && st == t - 1) x[4 * NN + p] = 1; if (k == R && st == t - 1) x[5 * NN + p] = 1;
    if (k == EMPTY) x[6 * NN + p] = 1; x[7 * NN + p] = 1; }
}
static int symIdx(int s, int p) { int y = p / BN_, x = p % BN_; if (s & 4) std::swap(x, y); if (s & 1) x = BN_ - 1 - x; if (s & 2) y = BN_ - 1 - y; return y * BN_ + x; }
static void symPlanes(int s, const float* in, float* out) { for (int c = 0; c < NP; c++) for (int p = 0; p < NN; p++) out[c * NN + symIdx(s, p)] = in[c * NN + p]; }
static void symPolicy(int s, const float* in, float* out) { for (int p = 0; p < NN; p++) out[symIdx(s, p)] = in[p]; out[NN] = in[NN]; }

// ---------- search (decoupled PUCT) ----------
static float g_mix = 0.5f; // leaf value = (1 - g_mix) * net + g_mix * one random playout (SGO_MIX, default 0.5)
struct Node {
  SGoGame g; bool terminal = false, expanded = false; float value = 0; int turn = 0;
  std::vector<int> legal; float P[2][NA]; float Wsum[2][NA]; int Ncnt[2][NA]; int Ntot = 0;
  std::unordered_map<int, int> child;
};
struct Search {
  const Board& bd; const Opts& o; const Net& net; std::vector<Node> nodes; Rng& rng; int cap; float cpuct = 1.5f; bool noise;
  Search(const Board& b, const Opts& oo, const Net& n, Rng& r, int cap_, bool noise_) : bd(b), o(oo), net(n), rng(r), cap(cap_), noise(noise_) {}
  int newNode(const SGoGame& g) { nodes.emplace_back(); Node& nd = nodes.back(); nd.g = g; nd.turn = g.next; nd.terminal = g.ended || g.next > cap;
    if (nd.terminal) { int m = areaMargin(bd, g.P.D); nd.value = m > 0 ? 1 : (m < 0 ? -1 : 0); } return (int)nodes.size() - 1; }
  void expand(int ni, bool root) {
    Node& nd = nodes[ni]; nd.legal.clear(); for (int p = 0; p < NN; p++) if (nd.g.P.D.kind[p] == EMPTY) nd.legal.push_back(p); nd.legal.push_back(NN); // pass
    float x[NP * NN]; planes(nd.g, x); Act A; forward(net, x, A); nd.value = A.v;
    if (g_mix > 0) { int m = sgoPlayout(bd, o, nd.g, rng); float z = m > 0 ? 1 : (m < 0 ? -1 : 0); nd.value = (1 - g_mix) * A.v + g_mix * z; } // SGO_MIX: blend with a random playout
    float sB[NA], sW[NA]; softmax(A.pB, sB, NA); softmax(A.pW, sW, NA);
    float zB = 0, zW = 0; for (int a : nd.legal) { zB += sB[a]; zW += sW[a]; }
    for (int c = 0; c < 2; c++) for (int a = 0; a < NA; a++) { nd.P[c][a] = 0; nd.Wsum[c][a] = 0; nd.Ncnt[c][a] = 0; }
    for (int a : nd.legal) { nd.P[0][a] = sB[a] / zB; nd.P[1][a] = sW[a] / zW; }
    if (root && noise) { // Dirichlet noise on the root priors, alpha = 10 / |legal|
      float alpha = 10.0f / nd.legal.size(); std::gamma_distribution<float> gd(alpha, 1.0f); std::mt19937_64 r(rng.g());
      for (int c = 0; c < 2; c++) { float s = 0; std::vector<float> dn(nd.legal.size()); for (size_t i = 0; i < dn.size(); i++) { dn[i] = gd(r); s += dn[i]; }
        for (size_t i = 0; i < dn.size(); i++) nd.P[c][nd.legal[i]] = 0.75f * nd.P[c][nd.legal[i]] + 0.25f * dn[i] / s; } }
    nd.expanded = true;
  }
  int select(const Node& nd, int c) {
    float best = -1e30f; int bestA = nd.legal[0]; float sq = std::sqrt((float)nd.Ntot + 1);
    // first-play urgency: an unvisited action starts at the node's running mean value from this player's side
    // (a fixed 0 would favor whichever side the value currently leans against, and the lean would feed itself)
    float fpu; if (nd.Ntot) { float sw = 0; for (int a : nd.legal) sw += nd.Wsum[c][a]; fpu = sw / nd.Ntot; } else fpu = c == 0 ? nd.value : -nd.value;
    for (int a : nd.legal) { float q = nd.Ncnt[c][a] ? nd.Wsum[c][a] / nd.Ncnt[c][a] : fpu; float u = cpuct * nd.P[c][a] * sq / (1 + nd.Ncnt[c][a]); float s = q + u;
      if (s > best) { best = s; bestA = a; } }
    return bestA;
  }
  void simulate(int root) {
    std::vector<std::array<int, 3>> path; int ni = root; float v = 0;
    while (true) {
      if (nodes[ni].terminal) { v = nodes[ni].value; break; }
      if (!nodes[ni].expanded) { expand(ni, ni == root); v = nodes[ni].value; break; }
      int aB = select(nodes[ni], 0), aW = select(nodes[ni], 1); int key = aB * NA + aW;
      path.push_back({ni, aB, aW});
      auto it = nodes[ni].child.find(key);
      if (it == nodes[ni].child.end()) { SGoGame g2 = nodes[ni].g; sgoTurn(bd, o, g2, aB == NN ? -1 : aB, aW == NN ? -1 : aW); int ci = newNode(g2); nodes[ni].child[key] = ci; ni = ci; }
      else ni = it->second;
    }
    for (auto& s : path) { Node& nd = nodes[s[0]]; nd.Ncnt[0][s[1]]++; nd.Wsum[0][s[1]] += v; nd.Ncnt[1][s[2]]++; nd.Wsum[1][s[2]] -= v; nd.Ntot++; }
  }
  // runs sims simulations from the state; fills the visit policies; returns the root index
  int run(const SGoGame& g, int sims, float* polB, float* polW) {
    nodes.clear(); nodes.reserve(sims + 2); int root = newNode(g);
    for (int s = 0; s < sims; s++) simulate(root);
    Node& nd = nodes[root]; for (int a = 0; a < NA; a++) { polB[a] = nd.Ntot ? (float)nd.Ncnt[0][a] / nd.Ntot : 0; polW[a] = nd.Ntot ? (float)nd.Ncnt[1][a] / nd.Ntot : 0; }
    return root;
  }
};
static bool g_dump = false; // SGO_DUMP=1: match mode prints every turn's moves and the display hash (and the final board) to stderr
static bool g_go = false; // SGO_GO=1: the Go modes' data (planes: 0 black, 1 white, 2 side to move, 3 last move, 4 ko point, 6 empty, 7 ones) — the color swap of training flips planes 0/1 and 2
static double g_komi = 7.5; // SGO_KOMI, Go only (area scoring; 7.5 is the common standard)
static float g_tau = 0; // SGO_TAU: move choice in match/eval — 0 = the most visited move (default), t > 0 = sample from visits^(1/t)
static int pickTau(const float* pol, Rng& rng); // below
static int pick(const float* pol, bool greedy, Rng& rng) {
  if (greedy) { float best = -1; int bestA = NN; for (int a = 0; a < NA; a++) if (pol[a] > best + 1e-9f || (std::fabs(pol[a] - best) <= 1e-9f && rng.below(2))) { best = pol[a]; bestA = a; } return bestA; }
  double u = (rng.g() % 1000000) / 1000000.0, acc = 0; for (int a = 0; a < NA; a++) { acc += pol[a]; if (u < acc) return a; } return NN;
}

static int pickTau(const float* pol, Rng& rng) {
  if (g_tau <= 0) return pick(pol, true, rng);
  float q[NA]; double z = 0; for (int a = 0; a < NA; a++) { q[a] = pol[a] > 0 ? std::pow(pol[a], 1.0f / g_tau) : 0; z += q[a]; }
  if (z <= 0) return pick(pol, true, rng);
  for (int a = 0; a < NA; a++) q[a] /= z; return pick(q, false, rng);
}
// ---------- data ----------
struct Sample { uint8_t x[NP * NN]; float pB[NA], pW[NA]; float z; };
static bool writeSamples(const char* path, const std::vector<Sample>& v) { FILE* f = fopen(path, "ab"); if (!f) return false; for (auto& s : v) fwrite(&s, sizeof(Sample), 1, f); fclose(f); return true; }
static void readSamples(const char* path, std::vector<Sample>& v) { FILE* f = fopen(path, "rb"); if (!f) return; Sample s; while (fread(&s, sizeof(Sample), 1, f) == 1) v.push_back(s); fclose(f); }

// ---------- Go (sequential moves): planes, search, agents ----------
// The same network: the head of the player to move gives the priors, the value is Black's.  The legal moves of the
// net are the engine's policy moves plus the pass (see expand).  Positional superko is enforced at the game level (a chosen move that recreates an earlier position of the game is replaced by the next
// most visited legal one); inside the tree only the simple ko of the engine applies.  Komi g_komi.
static void planesGo(const GoGame& g, int last, float* x) {
  std::fill(x, x + NP * NN, 0.0f);
  for (int p = 0; p < NN; p++) { int k = g.P.D.kind[p];
    if (k == B) x[0 * NN + p] = 1; if (k == W) x[1 * NN + p] = 1; if (g.toMove == B) x[2 * NN + p] = 1;
    if (p == last) x[3 * NN + p] = 1; if (p == g.ko) x[4 * NN + p] = 1; if (k == EMPTY) x[6 * NN + p] = 1; x[7 * NN + p] = 1; }
}
struct GNode { GoGame g; int last = -1; bool terminal = false, expanded = false; float value = 0; std::vector<int> legal; float P[NA]; float Wsum[NA]; int Ncnt[NA]; int Ntot = 0; std::unordered_map<int, int> child; };
struct GoSearch {
  const Board& bd; const Opts& o; const Net& net; std::vector<GNode> nodes; Rng& rng; float cpuct = 1.5f; bool noise;
  GoSearch(const Board& b, const Opts& oo, const Net& n, Rng& r, bool noise_) : bd(b), o(oo), net(n), rng(r), noise(noise_) {}
  int newNode(const GoGame& g, int last) { nodes.emplace_back(); GNode& nd = nodes.back(); nd.g = g; nd.last = last; nd.terminal = g.ended;
    if (nd.terminal) { double m = goMarginB(bd, o, g.P.D); nd.value = m > 0 ? 1 : (m < 0 ? -1 : 0); } return (int)nodes.size() - 1; }
  void expand(int ni, bool root) {
    GNode& nd = nodes[ni]; nd.legal.clear(); { int mv[MAXC]; int k = policyMovesF(bd, nd.g.P, nd.g.toMove, nd.g.ko, mv); for (int i = 0; i < k; i++) nd.legal.push_back(mv[i]); } nd.legal.push_back(NN);
    // the net's moves are the engine's policy moves (no suicide, no fill of an own single-point eye unless an own chain has its last liberty there) plus the pass — the move set of the MC agents; with the full set the nets filled and refilled to the ply cap instead of passing
    float x[NP * NN]; planesGo(nd.g, nd.last, x); Act A; forward(net, x, A); nd.value = A.v;
    if (g_mix > 0) { double m = goPlayout(bd, o, nd.g, rng); float z = m > 0 ? 1 : (m < 0 ? -1 : 0); nd.value = (1 - g_mix) * A.v + g_mix * z; }
    float s[NA]; softmax(nd.g.toMove == B ? A.pB : A.pW, s, NA); float zs = 0; for (int a : nd.legal) zs += s[a];
    for (int a = 0; a < NA; a++) { nd.P[a] = 0; nd.Wsum[a] = 0; nd.Ncnt[a] = 0; }
    for (int a : nd.legal) nd.P[a] = s[a] / zs;
    if (root && noise) { float alpha = 10.0f / nd.legal.size(); std::gamma_distribution<float> gd(alpha, 1.0f); std::mt19937_64 r(rng.g());
      float sum = 0; std::vector<float> dn(nd.legal.size()); for (size_t i = 0; i < dn.size(); i++) { dn[i] = gd(r); sum += dn[i]; }
      for (size_t i = 0; i < dn.size(); i++) nd.P[nd.legal[i]] = 0.75f * nd.P[nd.legal[i]] + 0.25f * dn[i] / sum; }
    nd.expanded = true;
  }
  int select(const GNode& nd) {
    float sign = nd.g.toMove == B ? 1.0f : -1.0f; float best = -1e30f; int bestA = nd.legal[0]; float sq = std::sqrt((float)nd.Ntot + 1);
    float fpu; if (nd.Ntot) { float sw = 0; for (int a : nd.legal) sw += nd.Wsum[a]; fpu = sign * sw / nd.Ntot; } else fpu = sign * nd.value;
    for (int a : nd.legal) { float q = nd.Ncnt[a] ? sign * nd.Wsum[a] / nd.Ncnt[a] : fpu; float u = cpuct * nd.P[a] * sq / (1 + nd.Ncnt[a]); if (q + u > best) { best = q + u; bestA = a; } }
    return bestA;
  }
  void simulate(int root) {
    std::vector<std::pair<int, int>> path; int ni = root; float v = 0;
    while (true) {
      if (nodes[ni].terminal) { v = nodes[ni].value; break; }
      if (!nodes[ni].expanded) { expand(ni, ni == root); v = nodes[ni].value; break; }
      int a = select(nodes[ni]); path.push_back({ni, a});
      auto it = nodes[ni].child.find(a);
      if (it == nodes[ni].child.end()) { GoGame g2 = nodes[ni].g; goTurn(bd, o, g2, a == NN ? -1 : a); int ci = newNode(g2, a == NN ? -1 : a); nodes[ni].child[a] = ci; ni = ci; }
      else ni = it->second;
    }
    for (auto& s : path) { GNode& nd = nodes[s.first]; nd.Ncnt[s.second]++; nd.Wsum[s.second] += v; nd.Ntot++; }
  }
  int run(const GoGame& g, int last, int sims, float* pol) {
    nodes.clear(); nodes.reserve(sims + 2); int root = newNode(g, last);
    for (int s = 0; s < sims; s++) simulate(root);
    GNode& nd = nodes[root]; for (int a = 0; a < NA; a++) pol[a] = nd.Ntot ? (float)nd.Ncnt[a] / nd.Ntot : 0; return root;
  }
};
// the move of a Go agent: mc<budget> through the engine's agent (its menu is drawn from superko-legal moves), or the
// net: the visit distribution, greedy or sampled (tau; tau = 1 when sample is set), superko-illegal choices skipped
static int goNetMove(GoSearch& S, const GoGame& g, int last, int sims, const std::unordered_set<uint64_t>& hist, bool sample, Rng& rng, float* polOut) {
  float pol[NA]; S.run(g, last, sims, pol); if (polOut) memcpy(polOut, pol, sizeof pol);
  for (int tries = 0; tries < NA; tries++) {
    int a = sample ? pick(pol, false, rng) : pickTau(pol, rng);
    if (a == NN) return -1;
    GoGame g2 = g; goTurn(S.bd, S.o, g2, a); if (!hist.count(g2.P.hash)) return a;
    pol[a] = 0; float z = 0; for (int b = 0; b < NA; b++) z += pol[b]; if (z <= 0) return -1; for (int b = 0; b < NA; b++) pol[b] /= z; // superko: drop the move, renormalize
  }
  return -1;
}
static Opts goOpts(int cap) { Opts o; o.n = BN_; o.ko = true; o.komi = g_komi; o.cap = cap; o.pdepth = 150; return o; }
// ---------- modes ----------
static Opts gameOpts(int cap) { Opts o; o.n = BN_; o.ko = false; o.cap = cap; return o; }
int main(int argc, char** argv) {
  if (argc < 2) { fprintf(stderr, "usage: see the header of sgonet.cpp\n"); return 2; }
  geomInit(); g_n = BN_; g_place = 4; g_eyedef = true; // the December text; the Monte Carlo opponent uses the paper's move set
  if (const char* e = getenv("SGO_PLACE")) g_place = atoi(e);
  if (const char* e = getenv("SGO_MIX")) g_mix = atof(e);
  if (const char* e = getenv("SGO_TAU")) g_tau = atof(e);
  if (getenv("SGO_GO")) g_go = true;
  if (const char* e = getenv("SGO_KOMI")) g_komi = atof(e);
  if (getenv("SGO_DUMP")) g_dump = true;
  if (getenv("SGO_REFCONV")) g_refconv = true;
  if (const char* e = getenv("SGO_ORPHAN")) g_orphan = (atoi(e) != 0); // the extra capture route (sgo.cpp)
  std::string mode = argv[1];
  if ((mode == "convtest" || mode == "bench") && argc >= 3) {
    // convtest <weights>: the matrix-product convolutions against the original loops on 400 positions of random games
    // (forward outputs and all gradients); bench <weights>: microseconds per forward pass, per playout, per 100-sim search
    Net n; n.alloc(); if (!n.load(argv[2])) { fprintf(stderr, "cannot load %s\n", argv[2]); return 1; }
    Board bd(BN_); Opts o = gameOpts(200); Rng rng(mix64(77));
    if (mode == "bench") {
      SGoGame g; g.init(bd.N); for (int t = 0; t < 30 && !g.ended; t++) sgoTurn(bd, o, g, randomMoveF(bd, g.P, B, g.koB, rng), randomMoveF(bd, g.P, W, g.koW, rng));
      float x[NP * NN]; planes(g, x); static Act A; double v = 0;
      for (int rc = 0; rc < 2; rc++) { g_refconv = rc == 0; auto t0 = std::chrono::steady_clock::now(); int R = rc == 0 ? 300 : 2000;
        for (int i = 0; i < R; i++) { forward(n, x, A); v += A.v; }
        printf("forward (%s): %.1f us\n", rc == 0 ? "original loops" : "matrix products", std::chrono::duration<double, std::micro>(std::chrono::steady_clock::now() - t0).count() / R); }
      for (int rc = 0; rc < 2; rc++) { g_refconv = rc == 0; float tB[NA], tW[NA]; for (int a = 0; a < NA; a++) tB[a] = tW[a] = 1.0f / NA; double lp = 0, lv = 0;
        auto t0 = std::chrono::steady_clock::now(); int R = rc == 0 ? 100 : 500;
        for (int i = 0; i < R; i++) { forward(n, x, A); backward(n, A, tB, tW, 0.0f, &lp, &lv); }
        printf("forward+backward (%s): %.1f us\n", rc == 0 ? "original loops" : "matrix products", std::chrono::duration<double, std::micro>(std::chrono::steady_clock::now() - t0).count() / R); v += lp; }
      g_refconv = false;
      { auto t0 = std::chrono::steady_clock::now(); long s = 0; for (int i = 0; i < 2000; i++) s += sgoPlayout(bd, o, g, rng);
        printf("playout from turn 31: %.1f us\n", std::chrono::duration<double, std::micro>(std::chrono::steady_clock::now() - t0).count() / 2000); v += s; }
      { SGoGame g0; g0.init(bd.N); auto t0 = std::chrono::steady_clock::now(); float pB[NA], pW[NA];
        for (int i = 0; i < 10; i++) { Search S(bd, o, n, rng, 200, true); S.run(g0, 100, pB, pW); }
        printf("search 100 sims, empty board: %.0f us\n", std::chrono::duration<double, std::micro>(std::chrono::steady_clock::now() - t0).count() / 10); }
      fprintf(stderr, "(checksum %g)\n", v); return 0;
    }
    static Act A1, A2; double dp = 0, dv = 0, mp = 0, dg = 0, mg = 0; int pos = 0; std::vector<float> G1;
    for (int gi = 0; pos < 400; gi++) { SGoGame g; g.init(bd.N);
      while (!g.ended && pos < 400) {
        float x[NP * NN]; planes(g, x);
        g_refconv = true; forward(n, x, A1); g_refconv = false; forward(n, x, A2);
        for (int a = 0; a < NA; a++) { dp = std::max(dp, (double)std::fabs(A1.pB[a] - A2.pB[a])); dp = std::max(dp, (double)std::fabs(A1.pW[a] - A2.pW[a])); mp = std::max(mp, (double)std::fabs(A1.pB[a])); }
        dv = std::max(dv, (double)std::fabs(A1.v - A2.v));
        float tB[NA], tW[NA]; for (int a = 0; a < NA; a++) { tB[a] = rng.below(100) / 100.0f; tW[a] = rng.below(100) / 100.0f; } float z = rng.below(3) - 1.0f; double lp = 0, lv = 0;
        n.zeroGrad(); g_refconv = true; backward(n, A1, tB, tW, z, &lp, &lv); G1.clear(); for (Tensor* t : n.all()) G1.insert(G1.end(), t->g.begin(), t->g.end());
        n.zeroGrad(); g_refconv = false; backward(n, A1, tB, tW, z, &lp, &lv); size_t i = 0; // the same activations: the backward maps alone
        for (Tensor* t : n.all()) for (float gv : t->g) { dg = std::max(dg, (double)std::fabs(gv - G1[i])); mg = std::max(mg, (double)std::fabs(G1[i])); i++; }
        pos++; sgoTurn(bd, o, g, randomMoveF(bd, g.P, B, g.koB, rng), randomMoveF(bd, g.P, W, g.koW, rng)); } }
    printf("CONVTEST %d positions: max |dlogit| %.3g (max |logit| %.3g), max |dv| %.3g, max |dgrad| %.3g (max |grad| %.3g)\n", pos, dp, mp, dv, dg, mg);
    return 0;
  }
  if (mode.rfind("go", 0) == 0) g_go = true;
  if (mode == "init" && argc >= 3) { Net n; n.alloc(); n.randomize(argc >= 4 ? strtoull(argv[3], nullptr, 10) : 1); return n.save(argv[2]) ? 0 : 1; }
  if ((mode == "selfplay" || mode == "census") && argc >= 6) {
    bool census = mode == "census"; Net n; n.alloc(); if (!n.load(argv[2])) { fprintf(stderr, "cannot load %s\n", argv[2]); return 1; }
    int games = atoi(argv[3]), sims = atoi(argv[4]); const char* out = census ? nullptr : argv[5]; uint64_t seed = strtoull(argv[census ? 5 : 6], nullptr, 10); int cap = (!census && argc >= 8) ? atoi(argv[7]) : 200;
    Board bd(BN_); Opts o = gameOpts(cap); Rng rng(mix64(seed * 7777ULL + 1)); long conf[4] = {0, 0, 0, 0}; double sumAbs = 0, sumTurns = 0; int own = 0, draws = 0, blackWins = 0;
    auto t0 = std::chrono::steady_clock::now();
    int start = 0; std::string cntPath = out ? std::string(out) + ".count" : ""; // resume: games already written to the data file
    if (out) { FILE* cf = fopen(cntPath.c_str(), "r"); if (cf) { if (fscanf(cf, "%d", &start) != 1) start = 0; fclose(cf); } if (start > 0) fprintf(stderr, "resuming after %d games\n", start); }
    for (int gi = start; gi < games; gi++) {
      SGoGame g; g.init(bd.N); std::vector<Sample> samples; Search S(bd, o, n, rng, cap, true);
      while (!g.ended && g.next <= cap) {
        float pB[NA], pW[NA]; S.run(g, sims, pB, pW);
        Sample s; float x[NP * NN]; planes(g, x); for (int i = 0; i < NP * NN; i++) s.x[i] = (uint8_t)x[i]; memcpy(s.pB, pB, sizeof pB); memcpy(s.pW, pW, sizeof pW); s.z = 0; samples.push_back(s);
        bool greedy = g.next > 20; int aB = pick(pB, greedy, rng), aW = pick(pW, greedy, rng);
        if (aB == aW && aB < NN) conf[conflictClass(g.P.D, aB)]++;
        sgoTurn(bd, o, g, aB == NN ? -1 : aB, aW == NN ? -1 : aW);
      }
      int m = areaMargin(bd, g.P.D); float z = m > 0 ? 1 : (m < 0 ? -1 : 0); for (auto& s : samples) s.z = z;
      if (out) { writeSamples(out, samples); FILE* cf = fopen(cntPath.c_str(), "w"); if (cf) { fprintf(cf, "%d\n", gi + 1); fclose(cf); } }
      sumAbs += std::abs(m); sumTurns += g.next - 1; if (g.ended) own++; if (m == 0) draws++; if (m > 0) blackWins++;
      double el = std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count();
      fprintf(stderr, "game %d/%d turns=%d margin=%+d samples=%zu conflicts %ld/%ld/%ld/%ld  %.0fs\n", gi + 1, games, g.next - 1, m, samples.size(), conf[0], conf[1], conf[2], conf[3], el);
    }
    int played = games - start; if (played <= 0) played = 1; // the statistics are over the games played by this run (a resumed run lost the earlier games' tallies)
    printf("SELFPLAY games=%d sims=%d meanabsmargin=%.1f meanturns=%.1f own=%.1f%% draws=%.1f%% blackwins=%.1f%% conflicts per game: trapping %.2f both_or_none %.2f one_color %.2f divergent %.3f\n",
      played, sims, sumAbs / played, sumTurns / played, 100.0 * own / played, 100.0 * draws / played, 100.0 * blackWins / played, (double)conf[0] / played, (double)conf[1] / played, (double)conf[2] / played, (double)conf[3] / played);
    return 0;
  }
  if (mode == "leagueplay" && argc >= 9) {
    // leagueplay <weights> <games> <sims> <out.dat> <seed> <cap> <pool> (2026-11-13): the even games gi = 0, 2, ... are
    // self-play exactly as in selfplay; each odd game puts the net against an agent of the pool (comma-separated
    // mc<budget>, mc0 = the random policy of the paper's agent), the agents in turn, the net's color alternating every
    // round of the pool.  In those games the net searches every turn as in self-play (root noise, moves sampled from the
    // visits for the first 20 turns) and the sample is the same (planes, both players' visit policies, z = the result);
    // only the opponent's stone comes from the agent.  Resumable like selfplay.
    Net n; n.alloc(); if (!n.load(argv[2])) { fprintf(stderr, "cannot load %s\n", argv[2]); return 1; }
    int games = atoi(argv[3]), sims = atoi(argv[4]); const char* out = argv[5]; uint64_t seed = strtoull(argv[6], nullptr, 10); int cap = atoi(argv[7]);
    std::vector<int> pool; std::vector<std::string> poolName;
    { std::string s = argv[8]; size_t i = 0; while (i < s.size()) { size_t j = s.find(',', i); if (j == std::string::npos) j = s.size(); std::string t = s.substr(i, j - i);
        if (t.size() > 2 && t.compare(0, 2, "mc") == 0) { pool.push_back(atoi(t.c_str() + 2)); poolName.push_back(t); } i = j + 1; } }
    if (pool.empty()) { fprintf(stderr, "bad pool (mc<budget>,mc<budget>,...)\n"); return 1; }
    const int P = (int)pool.size();
    Board bd(BN_); Opts o = gameOpts(cap); Rng rng(mix64(seed * 7777ULL + 1)); long conf[4] = {0, 0, 0, 0};
    double sumAbs = 0, sumTurns = 0; int selfGames = 0, draws = 0, blackWins = 0; std::vector<int> Wn(P, 0), Dn(P, 0), Ln(P, 0); std::vector<double> lgTurns(P, 0);
    auto t0 = std::chrono::steady_clock::now();
    int start = 0; std::string cntPath = std::string(out) + ".count";
    { FILE* cf = fopen(cntPath.c_str(), "r"); if (cf) { if (fscanf(cf, "%d", &start) != 1) start = 0; fclose(cf); } if (start > 0) fprintf(stderr, "resuming after %d games\n", start); }
    for (int gi = start; gi < games; gi++) {
      bool league = gi % 2 == 1; int r = gi / 2, oi = r % P; bool netBlack = (r / P) % 2 == 0;
      SGoGame g; g.init(bd.N); std::vector<Sample> samples; Search S(bd, o, n, rng, cap, true);
      while (!g.ended && g.next <= cap) {
        float pB[NA], pW[NA]; S.run(g, sims, pB, pW);
        Sample s; float x[NP * NN]; planes(g, x); for (int i = 0; i < NP * NN; i++) s.x[i] = (uint8_t)x[i]; memcpy(s.pB, pB, sizeof pB); memcpy(s.pW, pW, sizeof pW); s.z = 0; samples.push_back(s);
        bool greedy = g.next > 20; int aB = pick(pB, greedy, rng), aW = pick(pW, greedy, rng);
        if (league) { int am = sgoAgent(bd, o, g, netBlack ? W : B, pool[oi], rng); if (netBlack) aW = am < 0 ? NN : am; else aB = am < 0 ? NN : am; }
        if (aB == aW && aB < NN) conf[conflictClass(g.P.D, aB)]++;
        sgoTurn(bd, o, g, aB == NN ? -1 : aB, aW == NN ? -1 : aW);
      }
      int m = areaMargin(bd, g.P.D); float z = m > 0 ? 1 : (m < 0 ? -1 : 0); for (auto& s : samples) s.z = z;
      writeSamples(out, samples); { FILE* cf = fopen(cntPath.c_str(), "w"); if (cf) { fprintf(cf, "%d\n", gi + 1); fclose(cf); } }
      if (league) { int sNet = m == 0 ? 0 : ((m > 0) == netBlack ? 1 : -1); if (sNet > 0) Wn[oi]++; else if (sNet < 0) Ln[oi]++; else Dn[oi]++; lgTurns[oi] += g.next - 1; }
      else { selfGames++; sumAbs += std::abs(m); sumTurns += g.next - 1; if (m == 0) draws++; if (m > 0) blackWins++; }
      double el = std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count();
      if (league) fprintf(stderr, "game %d/%d net(%s) vs %s turns=%d margin=%+d samples=%zu  %.0fs\n", gi + 1, games, netBlack ? "B" : "W", poolName[oi].c_str(), g.next - 1, m, samples.size(), el);
      else fprintf(stderr, "game %d/%d self-play turns=%d margin=%+d samples=%zu  %.0fs\n", gi + 1, games, g.next - 1, m, samples.size(), el);
    }
    int sg = selfGames > 0 ? selfGames : 1; // the statistics are over the games played by this run
    printf("LEAGUE games=%d sims=%d selfplay=%d meanabsmargin=%.1f meanturns=%.1f draws=%.1f%% blackwins=%.1f%% | net vs", games - start, sims, selfGames, sumAbs / sg, sumTurns / sg, 100.0 * draws / sg, 100.0 * blackWins / sg);
    for (int i = 0; i < P; i++) printf(" %s %d-%d-%d", poolName[i].c_str(), Wn[i], Dn[i], Ln[i]);
    printf(" | conflicts per game: trapping %.2f both_or_none %.2f one_color %.2f divergent %.3f\n", (double)conf[0] / std::max(1, games - start), (double)conf[1] / std::max(1, games - start), (double)conf[2] / std::max(1, games - start), (double)conf[3] / std::max(1, games - start));
    return 0;
  }
  if (mode == "train" && argc >= 7) {
    Net n; n.alloc(); if (!n.load(argv[2])) { fprintf(stderr, "cannot load %s\n", argv[2]); return 1; }
    int epochs = atoi(argv[4]); float lr = atof(argv[5]); std::vector<Sample> data; for (int i = 6; i < argc; i++) readSamples(argv[i], data);
    if (data.empty()) { fprintf(stderr, "no data\n"); return 1; }
    fprintf(stderr, "training on %zu samples, %d epochs, lr %g\n", data.size(), epochs, lr);
    std::mt19937_64 r(12345 + n.step); const int batch = 128; float wd = 1e-4f;
    for (int ep = 0; ep < epochs; ep++) { std::shuffle(data.begin(), data.end(), r); double lossP = 0, lossV = 0; int cnt = 0; auto t0 = std::chrono::steady_clock::now();
      for (size_t i = 0; i < data.size(); i += batch) { n.zeroGrad(); int bs = std::min((size_t)batch, data.size() - i);
        for (int j = 0; j < bs; j++) { const Sample& s = data[i + j]; int sym = r() % 8; bool flip = r() % 2; float x0[NP * NN], x[NP * NN], tB[NA], tW[NA];
          for (int k = 0; k < NP * NN; k++) x0[k] = s.x[k];
          if (flip) { // color swap: the game is symmetric, so the sample seen from the other color is a sample too
            if (g_go) { for (int k = 0; k < NN; k++) { std::swap(x0[0 * NN + k], x0[1 * NN + k]); x0[2 * NN + k] = 1 - x0[2 * NN + k]; } }
            else for (int k = 0; k < NN; k++) { std::swap(x0[0 * NN + k], x0[1 * NN + k]); std::swap(x0[3 * NN + k], x0[4 * NN + k]); } }
          symPlanes(sym, x0, x); symPolicy(sym, flip ? s.pW : s.pB, tB); symPolicy(sym, flip ? s.pB : s.pW, tW);
          static Act A; forward(n, x, A); backward(n, A, tB, tW, flip ? -s.z : s.z, &lossP, &lossV); }
        n.adam(lr, wd, bs); cnt += bs; }
      double el = std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count();
      printf("TRAIN epoch %d samples %d policy %.4f value %.4f  %.0fs\n", ep + 1, cnt, lossP / cnt, lossV / cnt, el); fflush(stdout); }
    return n.save(argv[3]) ? 0 : 1;
  }
  if (mode == "eval" && argc >= 7) {
    // eval <w> <sims> <budget> <games> <seed> [cap=200] [log]: the net (SGO_TAU) against the Monte Carlo agent of the
    // paper at <budget> playouts per candidate; with a log the run is resumable and SGO_STRIDE=k/m splits the games
    Net n; n.alloc(); if (!n.load(argv[2])) { fprintf(stderr, "cannot load %s\n", argv[2]); return 1; }
    int sims = atoi(argv[3]), budget = atoi(argv[4]), games = atoi(argv[5]); uint64_t seed = strtoull(argv[6], nullptr, 10); int cap = argc >= 8 ? atoi(argv[7]) : 200; const char* logPath = argc >= 9 ? argv[8] : nullptr;
    int sk = 0, sm = 1; if (const char* e = getenv("SGO_STRIDE")) { if (sscanf(e, "%d/%d", &sk, &sm) != 2 || sm < 1) { sk = 0; sm = 1; } }
    Board bd(BN_); Opts o = gameOpts(cap);
    struct Tot { double score = 0; int w = 0, d = 0, l = 0, n = 0, capped = 0, capv = 200; double sumTurns = 0; long conf[4] = {0, 0, 0, 0};
      void add(int m, int nb, int t, const long* c) { double s = m == 0 ? 0.5 : ((m > 0) == (nb == 1) ? 1.0 : 0.0); score += s; if (s == 1) w++; else if (s == 0) l++; else d++; sumTurns += t; n++; if (t >= capv) capped++; for (int i = 0; i < 4; i++) conf[i] += c[i]; } };
    std::vector<char> done(games, 0);
    auto readLog = [&](Tot& T) { std::fill(done.begin(), done.end(), 0); if (!logPath) return; FILE* lf = fopen(logPath, "r"); if (!lf) return; char line[256];
      while (fgets(line, sizeof line, lf)) { int gi, m, nb, t, e; long c[4]; if (sscanf(line, "G %d %d %d %d %d %ld %ld %ld %ld", &gi, &m, &nb, &t, &e, &c[0], &c[1], &c[2], &c[3]) == 9 && gi >= 0 && gi < games && !done[gi]) { done[gi] = 1; T.add(m, nb, t, c); } }
      fclose(lf); };
    Tot T; T.capv = cap; readLog(T); if (T.n > 0) fprintf(stderr, "%d games already in the log\n", T.n);
    for (int gi = 0; gi < games; gi++) { if (done[gi] || gi % sm != sk) continue; bool netBlack = gi % 2 == 0; Rng rng(mix64(seed * 9999ULL + 3 + 101 * gi));
      SGoGame g; g.init(bd.N); Search S(bd, o, n, rng, cap, false); long c[4] = {0, 0, 0, 0};
      std::unordered_set<uint64_t> seen; // displays seen in this game; on a repetition the net samples its move from the visits (as in match mode)
      while (!g.ended && g.next <= cap) { float pB[NA], pW[NA]; S.run(g, sims, pB, pW);
        uint64_t kh = 0x9e3779b97f4a7c15ULL; for (int p = 0; p < NN; p++) kh = (kh ^ (uint64_t)(g.P.D.kind[p] + 1)) * 0x100000001b3ULL; bool rep = !seen.insert(kh).second;
        int aNet = rep ? pick(netBlack ? pB : pW, false, rng) : pickTau(netBlack ? pB : pW, rng); int aMc = sgoAgent(bd, o, g, netBlack ? W : B, budget, rng);
        int mNet = aNet == NN ? -1 : aNet; int black = netBlack ? mNet : aMc, white = netBlack ? aMc : mNet; if (black >= 0 && black == white) c[conflictClass(g.P.D, black)]++;
        sgoTurn(bd, o, g, black, white); }
      int m = areaMargin(bd, g.P.D); T.add(m, netBlack ? 1 : 0, g.next - 1, c);
      if (logPath) { FILE* lf = fopen(logPath, "a"); if (lf) { fprintf(lf, "G %d %d %d %d %d %ld %ld %ld %ld\n", gi, m, netBlack ? 1 : 0, g.next - 1, g.ended ? 1 : 0, c[0], c[1], c[2], c[3]); fclose(lf); } }
      fprintf(stderr, "eval game %d/%d net(%s) margin=%+d turns=%d [W%d D%d L%d]\n", gi + 1, games, netBlack ? "B" : "W", m, g.next - 1, T.w, T.d, T.l); }
    if (logPath) { Tot F; F.capv = cap; readLog(F); T = F; }
    if (T.n == 0) { fprintf(stderr, "no games\n"); return 1; }
    double s = T.score / T.n; double ss = std::min(std::max(s, 0.005), 0.995); double gap = 400 * std::log10(ss / (1 - ss));
    printf("EVAL net=%s sims=%d vs budget=%d games=%d score=%.3f W%d D%d L%d elo=%+.0f capped=%d meanturns=%.1f conflicts per game: trapping %.2f both_or_none %.2f one_color %.2f divergent %.3f\n",
      argv[2], sims, budget, T.n, s, T.w, T.d, T.l, gap, T.capped, T.sumTurns / T.n, (double)T.conf[0] / T.n, (double)T.conf[1] / T.n, (double)T.conf[2] / T.n, (double)T.conf[3] / T.n);
    return 0;
  }
  if (mode == "match" && argc >= 10) {
    // SGO_STRIDE=k/m: this process plays the games gi = k mod m (several processes share one log); games already in
    // the log are skipped; the MATCH line totals the log's games below <games>, so every process prints the same totals
    // once all are done.
    Net nA, nB; nA.alloc(); nB.alloc(); if (!nA.load(argv[2]) || !nB.load(argv[4])) { fprintf(stderr, "cannot load weights\n"); return 1; }
    int simsA = atoi(argv[3]), simsB = atoi(argv[5]), games = atoi(argv[6]); uint64_t seed = strtoull(argv[7], nullptr, 10); int cap = atoi(argv[8]); const char* logPath = argv[9];
    int sk = 0, sm = 1; if (const char* e = getenv("SGO_STRIDE")) { if (sscanf(e, "%d/%d", &sk, &sm) != 2 || sm < 1) { sk = 0; sm = 1; } }
    Board bd(BN_); Opts o = gameOpts(cap);
    struct Tot { double score = 0; int w = 0, d = 0, l = 0, own = 0, n = 0, capped = 0; double sumTurns = 0; long conf[4] = {0, 0, 0, 0}; int capv = 0;
      void add(int m, int nb, int t, int e, const long* c) { double sA = m == 0 ? 0.5 : ((m > 0) == (nb == 1) ? 1.0 : 0.0); score += sA; if (sA == 1) w++; else if (sA == 0) l++; else d++; own += e; sumTurns += t; n++; if (t >= capv) capped++; for (int i = 0; i < 4; i++) conf[i] += c[i]; } };
    auto readLog = [&](std::vector<char>& done, Tot& T) { done.assign(games, 0); FILE* lf = fopen(logPath, "r"); if (!lf) return; char line[256];
      while (fgets(line, sizeof line, lf)) { int gi, m, nb, t, e; long c[4]; if (sscanf(line, "G %d %d %d %d %d %ld %ld %ld %ld", &gi, &m, &nb, &t, &e, &c[0], &c[1], &c[2], &c[3]) == 9 && gi >= 0 && gi < games && !done[gi]) { done[gi] = 1; T.add(m, nb, t, e, c); } } // (a trailing reps field is ignored)
      fclose(lf); };
    std::vector<char> done; Tot T0; T0.capv = cap; readLog(done, T0); if (T0.n > 0) fprintf(stderr, "%d games already in the log\n", T0.n); Tot T = T0;
    for (int gi = 0; gi < games; gi++) { if (done[gi] || gi % sm != sk) continue; bool aBlack = gi % 2 == 0; Rng rng(mix64(seed * 5555ULL + 11 + 101 * gi)); // a seed per game
      SGoGame g; g.init(bd.N); Search SA(bd, o, nA, rng, cap, false), SB(bd, o, nB, rng, cap, false); long c[4] = {0, 0, 0, 0};
      std::unordered_set<uint64_t> seen; int reps = 0; // displays (kinds) seen in this game; on a repetition both players sample from the visits
      while (!g.ended && g.next <= cap) { float pB[NA], pW[NA], qB[NA], qW[NA]; SA.run(g, simsA, pB, pW); SB.run(g, simsB, qB, qW);
        uint64_t kh = 0x9e3779b97f4a7c15ULL; for (int p = 0; p < NN; p++) kh = (kh ^ (uint64_t)(g.P.D.kind[p] + 1)) * 0x100000001b3ULL;
        bool rep = !seen.insert(kh).second; if (rep) reps++;
        int aA = rep ? pick(aBlack ? pB : pW, false, rng) : pickTau(aBlack ? pB : pW, rng), aB = rep ? pick(aBlack ? qW : qB, false, rng) : pickTau(aBlack ? qW : qB, rng); int mA = aA == NN ? -1 : aA, mB = aB == NN ? -1 : aB;
        int black = aBlack ? mA : mB, white = aBlack ? mB : mA; if (black >= 0 && black == white) c[conflictClass(g.P.D, black)]++;
        if (g_dump) { auto nm = [&](int i, char* b) { if (i < 0) snprintf(b, 8, "pass"); else snprintf(b, 8, "%c%d", 'A' + i % BN_, i / BN_ + 1); return b; }; char b1[8], b2[8];
          fprintf(stderr, "t%d %s/%s", g.next, nm(black, b1), nm(white, b2)); }
        sgoTurn(bd, o, g, black, white);
        if (g_dump) { fprintf(stderr, " hash %016llx\n", (unsigned long long)g.P.hash); if (g.ended || g.next > cap) { for (int r = BN_; r >= 1; r--) { fprintf(stderr, "%2d ", r); for (int cc = 0; cc < BN_; cc++) fprintf(stderr, " %c", ".BWQ"[g.P.D.kind[(r - 1) * BN_ + cc]]); fprintf(stderr, "\n"); } } } }
      int m = areaMargin(bd, g.P.D); T.add(m, aBlack ? 1 : 0, g.next - 1, g.ended ? 1 : 0, c);
      FILE* lf = fopen(logPath, "a"); if (lf) { fprintf(lf, "G %d %d %d %d %d %ld %ld %ld %ld %d\n", gi, m, aBlack ? 1 : 0, g.next - 1, g.ended ? 1 : 0, c[0], c[1], c[2], c[3], reps); fclose(lf); }
      fprintf(stderr, "match game %d/%d A(%s) margin=%+d turns=%d reps=%d [W%d D%d L%d] conflicts %ld/%ld/%ld/%ld\n", gi + 1, games, aBlack ? "B" : "W", m, g.next - 1, reps, T.w, T.d, T.l, T.conf[0], T.conf[1], T.conf[2], T.conf[3]); }
    Tot F; F.capv = cap; readLog(done, F); if (F.n == 0) { fprintf(stderr, "no games\n"); return 1; }
    double s = F.score / F.n; double ss = std::min(std::max(s, 0.005), 0.995); double gap = 400 * std::log10(ss / (1 - ss));
    printf("MATCH A=%s sims=%d B=%s sims=%d games=%d scoreA=%.3f W%d D%d L%d eloA-B=%+.0f capped=%d meanturns=%.1f conflicts per game: trapping %.2f both_or_none %.2f one_color %.2f divergent %.3f\n",
      argv[2], simsA, argv[4], simsB, F.n, s, F.w, F.d, F.l, gap, F.capped, F.sumTurns / F.n, (double)F.conf[0] / F.n, (double)F.conf[1] / F.n, (double)F.conf[2] / F.n, (double)F.conf[3] / F.n);
    return 0;
  }
  if (mode == "arena" && argc >= 8) {
    // arena <specA> <specB> <games> <seed> <cap> <log>: any two agents, spec "mc<budget>" (the Monte Carlo agent of the
    // paper, budget playouts per candidate, 0 = its random policy) or "net:<weights>@<sims>" (tau = SGO_TAU, sampling
    // on a repeated display); colors alternate; resumable log (SGO_STRIDE); conflict census; prints an ARENA line
    struct Agent { bool isNet = false; int budget = 0, sims = 0; Net* net = nullptr; std::string name; };
    auto parse = [&](const char* s, Agent& a) -> bool { a.name = s; if (strncmp(s, "mc", 2) == 0) { a.budget = atoi(s + 2); return true; }
      if (strncmp(s, "net:", 4) == 0) { const char* at = strchr(s + 4, '@'); if (!at) return false; std::string path(s + 4, at - (s + 4)); a.sims = atoi(at + 1); a.isNet = true; a.net = new Net(); a.net->alloc(); return a.net->load(path.c_str()); }
      return false; };
    Agent A, Bg; if (!parse(argv[2], A) || !parse(argv[3], Bg)) { fprintf(stderr, "bad agent spec (mc<budget> | net:<weights>@<sims>)\n"); return 1; }
    int games = atoi(argv[4]); uint64_t seed = strtoull(argv[5], nullptr, 10); int cap = atoi(argv[6]); const char* logPath = argv[7];
    int sk = 0, sm = 1; if (const char* e = getenv("SGO_STRIDE")) { if (sscanf(e, "%d/%d", &sk, &sm) != 2 || sm < 1) { sk = 0; sm = 1; } }
    Board bd(BN_); Opts o = gameOpts(cap);
    struct Tot { double score = 0; int w = 0, d = 0, l = 0, n = 0, capped = 0, capv = 200; double sumTurns = 0; long conf[4] = {0, 0, 0, 0};
      void add(int m, int nb, int t, const long* c) { double s = m == 0 ? 0.5 : ((m > 0) == (nb == 1) ? 1.0 : 0.0); score += s; if (s == 1) w++; else if (s == 0) l++; else d++; sumTurns += t; n++; if (t >= capv) capped++; for (int i = 0; i < 4; i++) conf[i] += c[i]; } };
    std::vector<char> done(games, 0);
    auto readLog = [&](Tot& T) { std::fill(done.begin(), done.end(), 0); FILE* lf = fopen(logPath, "r"); if (!lf) return; char line[256];
      while (fgets(line, sizeof line, lf)) { int gi, m, nb, t, e; long c[4]; if (sscanf(line, "G %d %d %d %d %d %ld %ld %ld %ld", &gi, &m, &nb, &t, &e, &c[0], &c[1], &c[2], &c[3]) == 9 && gi >= 0 && gi < games && !done[gi]) { done[gi] = 1; T.add(m, nb, t, c); } }
      fclose(lf); };
    Tot T; T.capv = cap; readLog(T); if (T.n > 0) fprintf(stderr, "%d games already in the log\n", T.n);
    auto move = [&](Agent& ag, const SGoGame& g, int color, Search* S, bool rep, Rng& rng) -> int {
      if (!ag.isNet) return sgoAgent(bd, o, g, color, ag.budget, rng);
      float pB[NA], pW[NA]; S->run(g, ag.sims, pB, pW); const float* pol = color == B ? pB : pW; int a = rep ? pick(pol, false, rng) : pickTau(pol, rng); return a == NN ? -1 : a; };
    for (int gi = 0; gi < games; gi++) { if (done[gi] || gi % sm != sk) continue; bool aBlack = gi % 2 == 0; Rng rng(mix64(seed * 3333ULL + 17 + 101 * gi));
      SGoGame g; g.init(bd.N); long c[4] = {0, 0, 0, 0}; int reps = 0; std::unordered_set<uint64_t> seen;
      Search* SA = A.isNet ? new Search(bd, o, *A.net, rng, cap, false) : nullptr; Search* SB = Bg.isNet ? new Search(bd, o, *Bg.net, rng, cap, false) : nullptr;
      while (!g.ended && g.next <= cap) {
        uint64_t kh = 0x9e3779b97f4a7c15ULL; for (int p = 0; p < NN; p++) kh = (kh ^ (uint64_t)(g.P.D.kind[p] + 1)) * 0x100000001b3ULL; bool rep = !seen.insert(kh).second; if (rep) reps++;
        int mA = move(A, g, aBlack ? B : W, SA, rep, rng), mB = move(Bg, g, aBlack ? W : B, SB, rep, rng);
        int black = aBlack ? mA : mB, white = aBlack ? mB : mA; if (black >= 0 && black == white) c[conflictClass(g.P.D, black)]++;
        sgoTurn(bd, o, g, black, white); }
      delete SA; delete SB;
      int m = areaMargin(bd, g.P.D); T.add(m, aBlack ? 1 : 0, g.next - 1, c);
      FILE* lf = fopen(logPath, "a"); if (lf) { fprintf(lf, "G %d %d %d %d %d %ld %ld %ld %ld %d\n", gi, m, aBlack ? 1 : 0, g.next - 1, g.ended ? 1 : 0, c[0], c[1], c[2], c[3], reps); fclose(lf); }
      fprintf(stderr, "arena game %d/%d A(%s) margin=%+d turns=%d reps=%d [W%d D%d L%d]\n", gi + 1, games, aBlack ? "B" : "W", m, g.next - 1, reps, T.w, T.d, T.l); }
    Tot F; F.capv = cap; readLog(F); if (F.n == 0) { fprintf(stderr, "no games\n"); return 1; }
    double s = F.score / F.n; double ss = std::min(std::max(s, 0.005), 0.995); double gap = 400 * std::log10(ss / (1 - ss));
    printf("ARENA A=%s B=%s games=%d scoreA=%.3f W%d D%d L%d eloA-B=%+.0f capped=%d meanturns=%.1f conflicts per game: trapping %.2f both_or_none %.2f one_color %.2f divergent %.3f\n",
      A.name.c_str(), Bg.name.c_str(), F.n, s, F.w, F.d, F.l, gap, F.capped, F.sumTurns / F.n, (double)F.conf[0] / F.n, (double)F.conf[1] / F.n, (double)F.conf[2] / F.n, (double)F.conf[3] / F.n);
    return 0;
  }
  if (mode == "goselfplay" && argc >= 7) {
    // goselfplay <weights> <games> <sims> <out.dat> <seed> [cap plies=300]: Go self-play (positional superko, komi), resumable
    Net n; n.alloc(); if (!n.load(argv[2])) { fprintf(stderr, "cannot load %s\n", argv[2]); return 1; }
    int games = atoi(argv[3]), sims = atoi(argv[4]); const char* out = argv[5]; uint64_t seed = strtoull(argv[6], nullptr, 10); int cap = argc >= 8 ? atoi(argv[7]) : 300;
    Board bd(BN_); Opts o = goOpts(cap); Rng rng(mix64(seed * 7777ULL + 1)); double sumAbs = 0, sumTurns = 0; int capped = 0, blackWins = 0, draws = 0;
    auto t0 = std::chrono::steady_clock::now();
    int start = 0; std::string cntPath = std::string(out) + ".count"; { FILE* cf = fopen(cntPath.c_str(), "r"); if (cf) { if (fscanf(cf, "%d", &start) != 1) start = 0; fclose(cf); } if (start > 0) fprintf(stderr, "resuming after %d games\n", start); }
    for (int gi = start; gi < games; gi++) {
      GoGame g; g.init(bd.N); int last = -1; std::unordered_set<uint64_t> hist; hist.insert(g.P.hash); std::vector<Sample> samples; GoSearch S(bd, o, n, rng, true);
      while (!g.ended) {
        float pol[NA]; int m = goNetMove(S, g, last, sims, hist, g.turns < 20, rng, pol);
        Sample s; float x[NP * NN]; planesGo(g, last, x); for (int i = 0; i < NP * NN; i++) s.x[i] = (uint8_t)x[i];
        if (g.toMove == B) { memcpy(s.pB, pol, sizeof pol); memset(s.pW, 0, sizeof s.pW); } else { memcpy(s.pW, pol, sizeof pol); memset(s.pB, 0, sizeof s.pB); } s.z = 0; samples.push_back(s);
        goTurn(bd, o, g, m); if (m >= 0) hist.insert(g.P.hash); last = m;
      }
      double mg = goMarginB(bd, o, g.P.D); float z = mg > 0 ? 1 : (mg < 0 ? -1 : 0); for (auto& s : samples) s.z = z;
      writeSamples(out, samples); { FILE* cf = fopen(cntPath.c_str(), "w"); if (cf) { fprintf(cf, "%d\n", gi + 1); fclose(cf); } }
      sumAbs += std::fabs(mg); sumTurns += g.turns; if (g.turns >= cap) capped++; if (mg > 0) blackWins++; if (mg == 0) draws++;
      double el = std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count();
      fprintf(stderr, "game %d/%d plies=%d margin=%+.1f samples=%zu  %.0fs\n", gi + 1, games, g.turns, mg, samples.size(), el);
    }
    int played = games - start; if (played <= 0) played = 1;
    printf("GOSELFPLAY games=%d sims=%d komi=%.1f meanabsmargin=%.1f meanplies=%.1f capped=%d blackwins=%.1f%% draws=%.1f%%\n", played, sims, g_komi, sumAbs / played, sumTurns / played, capped, 100.0 * blackWins / played, 100.0 * draws / played);
    return 0;
  }
  if (mode == "goarena" && argc >= 8) {
    // goarena <specA> <specB> <games> <seed> <cap plies> <log>: two Go agents (mc<budget> | net:<weights>@<sims>), colors alternating,
    // positional superko at the game level, komi g_komi; resumable log (SGO_STRIDE); prints a GOARENA line
    struct Agent { bool isNet = false; int budget = 0, sims = 0; Net* net = nullptr; std::string name; };
    auto parse = [&](const char* s, Agent& a) -> bool { a.name = s; if (strncmp(s, "mc", 2) == 0) { a.budget = atoi(s + 2); return true; }
      if (strncmp(s, "net:", 4) == 0) { const char* at = strchr(s + 4, '@'); if (!at) return false; std::string path(s + 4, at - (s + 4)); a.sims = atoi(at + 1); a.isNet = true; a.net = new Net(); a.net->alloc(); return a.net->load(path.c_str()); }
      return false; };
    Agent A, Bg; if (!parse(argv[2], A) || !parse(argv[3], Bg)) { fprintf(stderr, "bad agent spec (mc<budget> | net:<weights>@<sims>)\n"); return 1; }
    int games = atoi(argv[4]); uint64_t seed = strtoull(argv[5], nullptr, 10); int cap = atoi(argv[6]); const char* logPath = argv[7];
    int sk = 0, sm = 1; if (const char* e = getenv("SGO_STRIDE")) { if (sscanf(e, "%d/%d", &sk, &sm) != 2 || sm < 1) { sk = 0; sm = 1; } }
    Board bd(BN_); Opts o = goOpts(cap);
    struct Tot { double score = 0; int w = 0, d = 0, l = 0, n = 0, capped = 0, capv = 300; double sumTurns = 0;
      void add(double m, int nb, int t) { double s = m == 0 ? 0.5 : ((m > 0) == (nb == 1) ? 1.0 : 0.0); score += s; if (s == 1) w++; else if (s == 0) l++; else d++; sumTurns += t; n++; if (t >= capv) capped++; } };
    std::vector<char> done(games, 0);
    auto readLog = [&](Tot& T) { std::fill(done.begin(), done.end(), 0); FILE* lf = fopen(logPath, "r"); if (!lf) return; char line[256];
      while (fgets(line, sizeof line, lf)) { int gi, nb, t; double m; if (sscanf(line, "G %d %lf %d %d", &gi, &m, &nb, &t) == 4 && gi >= 0 && gi < games && !done[gi]) { done[gi] = 1; T.add(m, nb, t); } } fclose(lf); };
    Tot T; T.capv = cap; readLog(T); if (T.n > 0) fprintf(stderr, "%d games already in the log\n", T.n);
    for (int gi = 0; gi < games; gi++) { if (done[gi] || gi % sm != sk) continue; bool aBlack = gi % 2 == 0; Rng rng(mix64(seed * 3333ULL + 17 + 101 * gi));
      GoGame g; g.init(bd.N); int last = -1; std::unordered_set<uint64_t> hist; hist.insert(g.P.hash);
      GoSearch* SA = A.isNet ? new GoSearch(bd, o, *A.net, rng, false) : nullptr; GoSearch* SB = Bg.isNet ? new GoSearch(bd, o, *Bg.net, rng, false) : nullptr;
      while (!g.ended) { bool aMoves = (g.toMove == B) == aBlack; Agent& ag = aMoves ? A : Bg; GoSearch* S = aMoves ? SA : SB;
        int m = ag.isNet ? goNetMove(*S, g, last, ag.sims, hist, false, rng, nullptr) : goAgent(bd, o, g, ag.budget, rng, &hist);
        goTurn(bd, o, g, m); if (m >= 0) { if (hist.count(g.P.hash)) { fprintf(stderr, "SUPERKO VIOLATED\n"); return 3; } hist.insert(g.P.hash); } last = m; }
      delete SA; delete SB;
      double mg = goMarginB(bd, o, g.P.D); T.add(mg, aBlack ? 1 : 0, g.turns);
      FILE* lf = fopen(logPath, "a"); if (lf) { fprintf(lf, "G %d %.1f %d %d\n", gi, mg, aBlack ? 1 : 0, g.turns); fclose(lf); }
      fprintf(stderr, "goarena game %d/%d A(%s) margin=%+.1f plies=%d [W%d D%d L%d]\n", gi + 1, games, aBlack ? "B" : "W", mg, g.turns, T.w, T.d, T.l); }
    Tot F; F.capv = cap; readLog(F); if (F.n == 0) { fprintf(stderr, "no games\n"); return 1; }
    double s = F.score / F.n; double ss = std::min(std::max(s, 0.005), 0.995); double gap = 400 * std::log10(ss / (1 - ss));
    printf("GOARENA A=%s B=%s games=%d komi=%.1f scoreA=%.3f W%d D%d L%d eloA-B=%+.0f capped=%d meanplies=%.1f\n", A.name.c_str(), Bg.name.c_str(), F.n, g_komi, s, F.w, F.d, F.l, gap, F.capped, F.sumTurns / F.n);
    return 0;
  }
  if (mode == "jsvec" && argc >= 6) {
    // jsvec <weights> <games> <seed> <out_prefix>: test vectors for a JavaScript port — games (half uniform random over
    // the empties and the pass, half random policy moves) with the policy move lists before each turn and the display,
    // end flag and area margin after it; the net's outputs on positions from those games; the weights as raw float32.
    Net n; n.alloc(); if (!n.load(argv[2])) { fprintf(stderr, "cannot load %s\n", argv[2]); return 1; }
    int games = atoi(argv[3]); uint64_t seed = strtoull(argv[4], nullptr, 10); std::string pre = argv[5];
    Board bd(BN_); Opts o = gameOpts(200); Rng rng(mix64(seed * 4242ULL + 5));
    FILE* fg = fopen((pre + "_games.jsonl").c_str(), "w"); FILE* fn = fopen((pre + "_net.jsonl").c_str(), "w");
    { FILE* fw = fopen((pre + "_weights.f32").c_str(), "wb"); for (Tensor* t : n.all()) fwrite(t->w.data(), sizeof(float), t->w.size(), fw); fclose(fw); }
    int netCount = 0;
    for (int gi = 0; gi < games; gi++) {
      bool uniform = gi % 2 == 0; SGoGame g; g.init(bd.N);
      fprintf(fg, "{\"mode\":\"%s\",\"turns\":[", uniform ? "uniform" : "policy");
      bool first = true;
      while (!g.ended) {
        int mvB[MAXC], mvW[MAXC]; int kB = policyMovesF(bd, g.P, B, -1, mvB), kW = policyMovesF(bd, g.P, W, -1, mvW);
        int m0, m1;
        if (uniform) { int emp[MAXC], k = 0; for (int i = 0; i < bd.N; i++) if (g.P.D.kind[i] == EMPTY) emp[k++] = i;
          int r0 = rng.below(k + 1), r1 = rng.below(k + 1); m0 = r0 == k ? -1 : emp[r0]; m1 = r1 == k ? -1 : emp[r1];
          if (rng.below(6) == 0 && k > 0) m1 = m0 >= 0 ? m0 : m1; } // extra collisions
        else { m0 = randomMoveF(bd, g.P, B, -1, rng); m1 = randomMoveF(bd, g.P, W, -1, rng); }
        if (netCount < 120 && rng.below(25) == 0) { // the net's outputs on this position
          float x[NP * NN]; planes(g, x); Act A; forward(n, x, A);
          fprintf(fn, "{\"x\":["); for (int i = 0; i < NP * NN; i++) fprintf(fn, "%s%d", i ? "," : "", (int)x[i]);
          fprintf(fn, "],\"pB\":["); for (int a = 0; a < NA; a++) fprintf(fn, "%s%.6g", a ? "," : "", A.pB[a]);
          fprintf(fn, "],\"pW\":["); for (int a = 0; a < NA; a++) fprintf(fn, "%s%.6g", a ? "," : "", A.pW[a]);
          fprintf(fn, "],\"v\":%.6g}\n", A.v); netCount++; }
        sgoTurn(bd, o, g, m0, m1);
        fprintf(fg, "%s{\"pb\":[", first ? "" : ","); first = false;
        for (int i = 0; i < kB; i++) fprintf(fg, "%s%d", i ? "," : "", mvB[i]);
        fprintf(fg, "],\"pw\":["); for (int i = 0; i < kW; i++) fprintf(fg, "%s%d", i ? "," : "", mvW[i]);
        fprintf(fg, "],\"m\":[%d,%d],\"k\":\"", m0, m1); for (int i = 0; i < bd.N; i++) fputc('0' + g.P.D.kind[i], fg);
        fprintf(fg, "\",\"s\":["); for (int i = 0; i < bd.N; i++) fprintf(fg, "%s%d", i ? "," : "", g.P.D.kind[i] ? g.P.D.stamp[i] : 0);
        fprintf(fg, "],\"e\":%d,\"a\":%d}", g.ended ? 1 : 0, areaMargin(bd, g.P.D));
      }
      fprintf(fg, "]}\n");
    }
    fclose(fg); fclose(fn); fprintf(stderr, "%d games, %d net positions\n", games, netCount);
    return 0;
  }
  if (mode == "replay" && argc >= 3) {
    // replay <file>: a game record of the browser page ("<turn> <black> <white>" per line, columns A-J without I, 'pass'),
    // played through this engine (SGO_PLACE); after each turn the removed stones and the components left without liberties
    Board bd(BN_); Opts o = gameOpts(200); SGoGame g; g.init(bd.N); std::ifstream f(argv[2]); std::string line; const char* cols = "ABCDEFGHJ";
    auto co = [&](const std::string& s) -> int { if (s == "pass") return -1; const char* p = strchr(cols, toupper(s[0])); return p ? (atoi(s.c_str() + 1) - 1) * BN_ + (int)(p - cols) : -2; };
    auto nm = [&](int i, char* b) { if (i < 0) snprintf(b, 8, "pass"); else snprintf(b, 8, "%c%d", cols[i % BN_], i / BN_ + 1); return b; };
    while (std::getline(f, line)) { std::istringstream is(line); int t; std::string sb, sw; if (!(is >> t >> sb >> sw)) continue;
      int m0 = co(sb), m1 = co(sw); Display before = g.P.D; sgoTurn(bd, o, g, m0, m1); char b1[8], b2[8];
      printf("turn %d %s/%s:", t, nm(m0, b1), nm(m1, b2));
      for (int i = 0; i < NN; i++) { if (before.kind[i] && !g.P.D.kind[i]) printf(" -%c%s", ".BWQ"[before.kind[i]], nm(i, b1)); if (before.kind[i] == R && g.P.D.kind[i] && g.P.D.kind[i] != R) printf(" %s:Q->%c", nm(i, b1), ".BWQ"[g.P.D.kind[i]]); }
      std::vector<char> seen(NN, 0); bool first = true;
      for (int p = 0; p < NN; p++) { int k = g.P.D.kind[p]; if (!k || seen[p]) continue; std::vector<int> comp{p}, st{p}; seen[p] = 1; bool lib = false;
        while (!st.empty()) { int u = st.back(); st.pop_back(); for (int d = 0; d < 9; d++) { if (d % 2 == 0) continue; int q = NBR9[u][d]; if (q < 0) continue;
            if (!g.P.D.kind[q]) lib = true; else if (g.P.D.kind[q] == k && !seen[q]) { seen[q] = 1; comp.push_back(q); st.push_back(q); } } }
        if (!lib) { printf("%s %c{", first ? "  NO LIBERTIES:" : "", ".BWQ"[k]); first = false; for (size_t a = 0; a < comp.size(); a++) printf("%s%s", a ? "," : "", nm(comp[a], b1)); printf("}"); } }
      printf("%s\n", g.ended ? "  (ended)" : ""); }
    for (int r = BN_; r >= 1; r--) { printf("%2d ", r); for (int c = 0; c < BN_; c++) printf(" %c", ".BWQ"[g.P.D.kind[(r - 1) * BN_ + c]]); printf("\n"); }
    printf("    A B C D E F G H J\narea margin (black - white) %d\n", areaMargin(bd, g.P.D)); return 0;
  }
  fprintf(stderr, "bad arguments\n"); return 2;
}
