#!/bin/bash
# climbing ladder with adaptive sample sizes: each rung is played until its 68% band half-width is <= BAND Elo
# (min MIN games, max MAX), then the RESULT line is recorded; stops after a rung whose gap is <= STOP Elo.
# usage: ladder11.sh <sgo|go> <cap> <pdepth> [BAND=40] [STOP=40] [MIN=100] [MAX=600]; honors SGO_N (default 11), SGO_PLACE
game=$1; cap=$2; pd=$3; band=${4:-40}; stop=${5:-40}; min=${6:-100}; max=${7:-600}; n=${SGO_N:-11}; export SGO_N=$n
tag="_n${n}${SGO_SIMP:+_simp}${SGO_PLACE:+_p$SGO_PLACE}_tot"; out=runs/${game}_ko1${tag}.txt; touch $out
budgets="0 3 26 205 410 819 1638 3277 6554 13107"
prev=""; seed=500
for b in $budgets; do
  if [ -n "$prev" ]; then
    seed=$((seed+1)); glog=runs/${game}_ko1${tag}_${prev}v${b}.games; elog=runs/${game}_ko1${tag}_${prev}v${b}.log
    line=$(grep "A=$prev B=$b " $out | tail -1)
    if [ -z "$line" ]; then
      g=$min
      while :; do
        SGO_LOG=$glog ./sgo match $game 1 $prev $b $g $seed 0 $cap $pd 2>>$elog > runs/tmp_${game}${tag}.res
        read cnt sB gap half < <(python3 band.py $glog $g)
        echo "rung $prev v $b: $cnt games, B score $sB, gap $gap, band ±$half" >> $elog
        if [ "$half" -le "$band" ] || [ "$g" -ge "$max" ]; then break; fi
        # games needed scale with (half/band)^2; grow in steps of 50, never beyond MAX
        need=$(python3 -c "import math; print(min($max, max($g+50, int(math.ceil($g*($half/$band)**2/50.0))*50)))")
        g=$need
      done
      cat runs/tmp_${game}${tag}.res >> $out
      line=$(grep "A=$prev B=$b " $out | tail -1)
    fi
    gapA=$(echo "$line" | sed -n 's/.*eloA-B=\([-+0-9]*\).*/\1/p')
    if [ -n "$gapA" ] && [ "$gapA" -ge "-$stop" ]; then echo "SATURATED at $prev v $b (gap $gapA)" >> $out; break; fi
  fi
  prev=$b
done
echo DONE >> $out
