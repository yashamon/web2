#!/bin/bash
out=runs/bugsign_probe.txt; : > $out
for pair in "0 3" "3 26" "26 205" "205 410"; do set -- $pair
  ./sgo_pd2 match go 0 $1 $2 100 501 0 80 0 1 2>/dev/null | sed "s/^/bugsign /" | tee -a $out
done
echo DONE >> $out
