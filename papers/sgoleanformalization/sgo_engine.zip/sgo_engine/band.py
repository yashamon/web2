#!/usr/bin/env python3
# usage: band.py <games file> <ngames>  -> prints "n sB gap halfband" over the first ngames games of a rung log
import sys, math
path, N = sys.argv[1], int(sys.argv[2])
seen = {}
for line in open(path):
    f = line.split()
    if len(f) == 4 and f[0] == 'G':
        g = int(f[1]); m = float(f[2])
        if g < N and g not in seen: seen[g] = m
n = len(seen)
if n == 0: print("0 0 0 999"); sys.exit()
sc = 0.0
for g, m in seen.items():
    mA = m if g % 2 == 0 else -m
    sc += 1.0 if mA > 0 else (0.0 if mA < 0 else 0.5)
sA = sc / n; sB = 1 - sA
def elo(s):
    s = min(max(s, 0.005), 0.995); return 400 * math.log10(s / (1 - s))
se = math.sqrt(max(sB * (1 - sB), 1e-4) / n)
half = (elo(sB + se) - elo(sB - se)) / 2
print(f"{n} {sB:.3f} {elo(sB):+.0f} {half:.0f}")
