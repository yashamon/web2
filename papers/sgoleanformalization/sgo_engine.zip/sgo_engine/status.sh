#!/bin/bash
# one-line-per-loop status of the three training loops
cd /home/claude/eng
date -u '+%H:%M'
for t in dec aug simple go; do
  case $t in dec) nets=nets; sfx="";; aug) nets=nets_aug; sfx=_aug;; simple) nets=nets_simple; sfx=_simple;; go) nets=nets_go; sfx=_go;; esac
  k=$(ls $nets/g*.bin | sed 's/.*g\([0-9]*\)\.bin/\1/' | sort -n | tail -1)
  sp=$(tail -1 runs/net_selfplay${sfx}_g${k}_a.log 2>/dev/null | grep -o 'game [0-9]*/[0-9]*')
  tr=$(tail -1 runs/net_train${sfx}.txt 2>/dev/null | grep -o 'TRAIN epoch [0-9]')
  ref=$(tail -1 runs/net_ref${sfx}.txt 2>/dev/null | grep -o '^g[0-9]*:.*eloA-B=[-+0-9]*' | sed 's/MATCH.*games=/g=/; s/GOARENA.*games=/g=/')
  echo "$t: net g$k | selfplay $sp | $tr | last ref: $ref"
done
ps -eo args | grep -c '[.]/sgonet'
