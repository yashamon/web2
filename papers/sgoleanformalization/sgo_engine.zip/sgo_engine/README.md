# sgo.cpp — SGo / Go engine remake, Ko experiment (2026-10-29)

Single-file C++17 engine for SGo (sgo.tex §2: joint placement with
q-stones, the capture conditions 1/2/3a/3b with the component-freshness
clause, Cap_t as the fixpoint of the basic reduction, the stage recursion)
and classical Go, transcribed from the differentially tested Lean engine
(SgoDisplay.lean, SgoSerial.lean, SgoGo.lean; Lean 4.15.0 release 1.4).

Build: `g++ -O2 -std=c++17 sgo.cpp -o sgo`

## Validation

`./sgo test` replays the three Lean test sheets (converted to `tests/`):

    disp tests: 1722 cases, 0 mismatches      (TestsDAll.lean — display resolution, 3×3)
    go tests:   1844 cases, 0 mismatches      (Tests.lean — one classical move, 3×3)
    serial tests: 240 games, 2009 turns, 0 bad (TestSerial.lean — whole SGo games incl. 5×5)

Uniformly random play (`./sgo ustats sgo 1000 40`) reproduces the printed
§2.2 random-play row for SGo 5×5 (13.6 / 4.6% draws / 22.4 turns).  The
printed Go row (12.0 / 5.4% / 39.9) is reproduced at an 80-ply bound
(`./sgo ustats go 1000 80` → 11.5 / 5.3%); at 40 plies 18.3 / 0%, at 120
plies 7.0 / 12.1%.  So the printed random-play rows were computed with a
bound of 40 SGo turns = 80 Go plies.

## Play conventions

* Policy (menu and playouts): uniformly random over the empty intersections
  that are not the mover's own single-point eye and not classical suicide;
  pass only when none remains (the footnote convention of §7.1).
* Agent of budget b: a random menu of at most five policy moves; for each,
  b playouts to the end of the game (the opponent's move this turn drawn at
  random in SGo); the move with the best mean area margin, ties at random.
  Budget 0 = a random menu move.  **b counts playouts per candidate** (so a
  budget-16 agent runs up to 80 playouts a turn).  The second convention
  below reads the printed budgets as totals per turn (3/26/205/410/819 per
  candidate).
* Game end.  SGo: a double pass turn (the formal rule), or the display
  unchanged after two consecutive turns, or a full display, or the cap.
  Go: two consecutive passes or the cap.  Cap 200 (SGo turns / Go plies)
  unless stated.  Komi 0.  Area scoring, an empty region counting for the
  color it alone touches.
* Fiat simple ko (option `ko=1`).  Go: the standard rule — a stone that has
  just captured exactly one stone, stands alone and has that point as its
  only liberty bars the opponent from that point next move.  SGo: the same
  read on the display after the turn's resolution — if exactly one stone of
  a color was removed this turn and the other player's stone of this turn
  stands alone with that point as its only liberty, the removed side may
  not play there next turn (both colors checked, independently).
* Elo gap of a rung = 400·log10(s/(1−s)), s the stronger agent's mean score
  (draw = ½); 100 games per rung (60 at the top), colors alternating.

## Commands

    ./sgo match <sgo|go> <ko 0/1> <budgetA> <budgetB> <games> [seed] [komi] [cap] [pdepth]
    ./sgo stats <sgo|go> <ko> [games]           # policy self-play statistics
    ./sgo ustats <sgo|go> [games] [cap]         # uniformly random play, as in §2.2
    ./sgo trace <sgo|go> <ko>                   # print the end of a capped policy game
    ./ladder.sh <sgo|go> <ko>                   # the five-rung ladder, per-candidate budgets
    ./ladder2.sh <sgo|go> <ko> <cap>            # total-budget rungs (3/26/205/410/819), printed bounds
    python3 summarize.py                        # table of all RESULT files in runs/

`pdepth` bounds the playout length (SGo turns / Go plies; 0 = to the end).

## Results — see runs/*.txt and `python3 summarize.py`

Ko loops.  Without a Ko rule both games cycle under the policy.  Go: the
usual single-ko recapture cycle (`./sgo trace go 0`).  SGo: a double ko —
two ko shapes, each player retaking a different one every turn, display
period 2 (`./sgo trace sgo 0`); the q-stone and the trapping clauses do not
bite because the two recaptures are at different points.  Share of policy
self-play games (budget 0, 1000 games, cap 200) reaching the cap: SGo 8.3%
(ko off) → 1.6% (ko on); Go 23.3% → 2.1%.  The residue under the simple ko
rule is the double ko, legal in Go too.

Ladders (Elo gap of each rung, B over A; heights = sums).  Per-candidate
budgets, cap 200:

    rung         SGo ko off   SGo ko on   Go ko off   Go ko on     printed (§7.3)  SGo   Go
    0 v 16          +512        +552        +676        +798                      +308  +173
    16 v 128        +246        +301        +246        +346                      +330   +89
    128 v 1024       +42         +49        +168        +100                      +215   +63
    1024 v 2048      -17         -35          +7         +14                       +52   -45
    2048 v 4096      +70         +12          --          --                        0    --
    height          ≈850        ≈880       ≈1100       ≈1260                     ≈900  ≈300

Print convention (budgets read as totals per turn: 3/26/205/410/819 per
candidate; bounds 40 SGo turns / 80 Go plies; ko off):

    rung (total)   SGo     Go
    0 v 16         +382   +301
    16 v 128       +241   +338
    128 v 1024     +200   +258
    1024 v 2048     -14    +24
    2048 v 4096       0    +12
    height         ≈810   ≈930

Playouts cut short (print convention, first three rungs): SGo with 5-turn
playouts +191/+147/−53 → ≈390 (2-turn: +225/+78/…); Go with 10-ply
playouts +424/+215/+89 → ≈730.  Short playouts compress SGo, not Go.

Reading.  (1) A fiat simple ko changes neither ladder's shape: both games
saturate at the same rung with and without it; ko on lifts the heights by
≈30 (SGo) and ≈160 (Go), mostly at the bottom rung, where the capped
looping games add noise.  (2) The printed SGo ladder is reproduced in shape
and height (≈850–880 vs ≈900, saturation at 1024–2048).  (3) The printed Go
ladder (≈300, saturating by 1024 with a negative last rung) is NOT
reproduced: under every convention tried here the Go ladder is as high as
SGo's or higher (≈930–1260).  The "three times the height" comparison of
§7.3 and the introduction is not supported by this engine.  The original
engine is lost, so the printed Go figures cannot be audited.

Simplified capture condition (`SGO_SIMP=1`: condition 3(b) without "and is
not a q-stone", the clause Remark rem_suicidalcapture names as the one
precluding Ko loops; condition 2 and "no stone in C is created on this turn"
kept).  118 of the 3806 Lean sheet cases change, all q-stone cases.  Random
play: 74% of games end on their own within 40 turns (printed rule 100%),
mean 27.9 turns (22.4).  Policy self-play capped: 6.9% (ko off), 0.9% (ko on).
Ladder, per-candidate budgets, cap 200:

    rung         simplified, ko off   simplified, ko on   printed rule, ko off / on
    0 v 16             +576                 +604                +512 / +552
    16 v 128           +269                 +230                +246 / +301
    128 v 1024          +56                 +135                 +42 /  +49
    1024 v 2048          --                  -21                 -17 /  -35
    height to 1024     ≈900                 ≈970                ≈800 / ≈900

The ko-off 1024 v 2048 rung was stopped: with the looping games running to
the 200-turn cap inside every playout it costs ≈2 min a game.  Within the
rung bands (±40) the four SGo ladders coincide: neither the simplification
nor the fiat ko changes the depth of SGo as this family measures it.

7×7 versus 5×5, both games with the fiat ko, printed SGo rules, komi 0,
cap 200, budgets as totals per turn (16/128/1024/2048/4096 ≈ 3/26/205/410/
819 per candidate), 100 games a rung (60 at the top).  `SGO_N=7`.

    rung (total)    SGo 7×7   Go 7×7   SGo 5×5   Go 5×5
    0 v 16            +382     +346      +246     +478
    16 v 128          +323     +288      +288     +275
    128 v 1024        +288     +552      +210     +275
    1024 v 2048        +45      +92       +28      +35
    2048 v 4096        +65      +83       -95      +35
    height          ≈1100    ≈1360      ≈680    ≈1100

Mean game length at the middle rung: SGo 7×7 43 turns, Go 7×7 79 plies.

Three-tier placement resolution (`SGO_PLACE=3`; sgo.tex up to 2026-08-25,
§"Stone placement resolution rule": a same-intersection conflict resolves
to a q-stone if either color placed there would be trapping, else to the
color of the only adjacent color, else to a q-stone; everything else as
printed).  Checked on the old §2 example (E7 black, G1 trapping move, no
capture).  362 of the 3806 Lean sheet cases change, all conflict cases.
Random play 5×5: margin 14.8, draws 3.8%, 99% self-end in 40 turns, 22.4
turns (printed rule 13.6 / 4.6% / 100% / 22.4).  Policy self-play capped:
6.8% (ko off), 1.3% (ko on).  Ladders, ko on, total budgets, cap 200:

    rung (total)    SGo 7×7 three-tier   SGo 7×7 printed   SGo 5×5 three-tier   SGo 5×5 printed
    0 v 16                +315                +382                +372               +246
    16 v 128              +424                +323                +295               +288
    128 v 1024            +354                +288                +295               +210
    1024 v 2048            +45                 +45                 -14                +28
    2048 v 4096            +83                 +65                   0                -95
    height              ≈1220               ≈1100                ≈950               ≈680

## Engine rewrite (2026-11-01) and the 13×13 ladders

Fast layer: an incrementally maintained chain table (circular stone lists,
pseudo-liberties with the sum / sum-of-squares atari test), an empties list
and a libertyless-chain list; the capture conditions of def_captured are
evaluated through the table (isCapturedF, clause by clause as isCaptured)
and only for libertyless chains whose stamp bound reaches the stage;
display hash for the end rule; per-turn removal log for the fiat ko.  The
slow functions stay as the oracle: `./sgo test` replays the Lean sheets
through both; `./sgo difftest [games] [seed]` runs lockstep random games
(sizes 3–9) comparing legality cell by cell, displays, chain tables and Go
captures; `SGO_CHECK=1` cross-checks every capture evaluation and the ko
log inside a match.  All zero.  Before the sampler change the fast engine
reproduced the old engine's 13×13 games move for move.  Speed at 13×13:
≈20× (SGo 16.4 s → 0.8 s, Go 18.9 s → 1.0 s for the budget-3 probe).
Matches are resumable per game (`SGO_LOG`), each game seeded on its own.

13×13, ko on, SGo with the three-tier placement rule versus Go, budgets as
totals 16·2^k per turn (per candidate 3, 26, 205, 410, 819, 1638, 3277,
6554), 100 games a rung up to 2048 and 60 beyond; SGo cap 300 turns,
playouts 250 turns; Go cap 600 plies, playouts 400 plies (about a third of
13×13 policy Go games cycle in double kos under the simple ko rule and are
scored at the cap).  Climbing until a rung's gap is at most +40.

    rung (total)        SGo three-tier      Go
    0 v 16                  +363          +315
    16 v 128                +449          +424
    128 v 1024              +449          +552
    1024 v 2048             +168          +151
    2048 v 4096             +191           +70
    4096 v 8192              +95          +108
    8192 v 16384             +47           -70   (Go saturated)
    16384 v 32768         0 (21 games, stopped)
    height to 16384       ≈1760         ≈1550

Height bands ≈ ±115 each.  The two ladders coincide within noise up to
8192; the game lengths differ (SGo ≈150 turns, Go ≈400 plies).

## 11×11 with adaptive samples (2026-11-02)

Each rung played until its 68% band half-width was at most 40 Elo
(ladder11.sh: minimum 100 games, maximum 600, grown in steps of 50;
band.py computes the band from the per-game log).  Ko on, SGo three-tier
(cap 250 turns, playouts 200) versus Go (cap 500 plies, playouts 350).
The stop rule (a rung at or under +40) fired for both at 8192; one
confirmation rung was run for each; the Go 32768 rung was stopped by
request after 62 games at exactly even.

    rung (total)     SGo three-tier (games)   Go (games)
    0 v 16               +390 (250)           +424 (350)
    16 v 128             +398 (250)           +382 (250)
    128 v 1024           +382 (250)           +463 (600)
    1024 v 2048          +108 (100)           +164 (100)
    2048 v 4096          +143 (100)           +119 (100)
    4096 v 8192           +21 (100)             +0 (100)
    8192 v 16384          +14 (100)            +70 (100)
    16384 v 32768          --              0 (62 games, stopped)
    height to 16384     ≈1450                ≈1620

Height bands ≈ ±95 (seven rungs at ≤ ±40 each).  Difference 170, about
1.3σ.  Across sizes, SGo three-tier / Go: 5×5 ≈950 / ≈1100, 7×7 ≈1220 /
≈1360, 11×11 ≈1450 / ≈1620, 13×13 ≈1760 / ≈1550 (13×13 at 60 games a rung,
bands ≈ ±110).

## Reproducing the figures of the paper (branch threetier, patch 0234)

Build: `g++ -O2 -std=c++17 sgo.cpp -o sgo`; validate: `./sgo test` (the Lean
sheets, 0 mismatches expected) and `./sgo difftest 300` (0 differences).  The
paper's SGo is the three-tier placement rule: every SGo command below carries
`SGO_PLACE=3`.  Each game is seeded on its own, so the numbers reproduce exactly
on any machine; runtimes are for one core of the cloud box used here.

Section 2.2, the random play table (seconds each):

    SGO_PLACE=3 ./sgo table sgo 1000 40          # SGo 5x5, bound 40 turns
    SGO_PLACE=3 ./sgo table sgo 1000 0           # SGo 5x5 unbounded ("with the bound lifted")
    ./sgo table go 1000 40                       # Go 5x5, bound 40 turns (80 plies)
    SGO_N=19 SGO_PLACE=3 ./sgo table sgo 1000 0  # SGo 19x19 unbounded
    SGO_N=19 ./sgo table go 200 1500             # Go 19x19, cap 1500 turns
    SGO_NOCAP=1 SGO_PLACE=3 ./sgo table sgo 500 40   # the objective reduction disabled
    SGO_NOCAP=1 ./sgo table sgo 500 40               # the same with a q-stone at every conflict

The TABLE line gives mean |margin|, draws, games ending on their own, mean
length (and the mean over the games that ended), q-stones created and on the
final display, peak recursion depth (stages of a turn that removed a stone;
the per-game peak averaged, and its maximum), peak and final number of
branches of the entanglement.  Go lengths are in move pairs.

Section 7.1 / 7.2, informed play on 5x5 (about three minutes each):

    SGO_PLACE=3 ./sgo eqplay 1000 16 5 400       # equilibrium guided SGo: 16 rollouts per matrix entry,
                                                 # seed 5, games stopped at 400 turns; prints TABLE, LENGTHS, EQ
    SGO_KO=1 SGO_PLACE=3 ./sgo eqplay 1000 16 5 400   # the same with the simple ko imposed
    ./sgo greedygo 1000 6 12 5 800               # greedy rollout Go: 6 candidates + pass, 12 rollouts, cap 800 plies
    SGO_KO=1 ./sgo greedygo 1000 6 12 5 800

The EQ line: turns with menus of size > 1, the share without a pure saddle
point ("mixed"), the mean within-turn spread of the 5x5 matrix, and the same
saddle test at fivefold rollouts on every tenth turn (the control).  The
matrix game is solved exactly (simplex); each player samples the optimal
mixed strategy.  TABLE's signedmargin is Black minus White.

Section 7.3, the 13x13 Elo ladder (about 30 hours on two cores; resumable):

    SGO_N=13 SGO_PLACE=3 ./ladder13.sh sgo 300 250   # SGo: cap 300 turns, playouts 250 turns
    SGO_N=13 ./ladder13.sh go 600 400                # Go: cap 600 plies, playouts 400 plies

ladder13.sh runs the rungs 0/3/26/205/410/819/1638/3277/... playouts per
candidate (16·2^k per turn), 100 games a rung up to 2048 and 60 beyond, with
the fiat ko (`sgo match ... 1 ...`), writing RESULT lines to
runs/<game>_ko1_n13[_p3]_tot.txt and per-game logs (`SGO_LOG`) next to them;
a killed run resumes where it stopped; it stops after a rung whose gap is at
most +40.  `SGO_STRIDE=k/m` lets m processes share one rung's games.  The
smaller boards: `ladder_tot.sh <game> 1 200` with `SGO_N=5|7`, and
`ladder11.sh` (adaptive sample sizes, band ≤ 40) for 11x11.  All RESULT
files and logs of the runs reported in the paper are in runs/; `python3
summarize.py` prints the tables with 68% bands.

The results quoted in the paper are in runs/stats3.txt (tables, informed
play), runs/stats2.txt and runs/stats.txt (earlier passes, same numbers), and
runs/sgo_ko1_n13_p3_tot.txt, runs/go_ko1_n13_tot.txt (the ladder).

## The two wordings of the three-tier rule, 11×11 (2026-11-02)

`SGO_PLACE=4` is the December 2025 wording: rule (2) also requires no
adjacent q-stone.  The two wordings differ only at a conflict adjacent to
a q-stone that is neither trapping nor adjacent to both colors (random play
5×5: 2.2 against 2.1 q-stones created per game).  Same adaptive protocol as
the 11×11 run above (band ≤ 40, stop at ≤ +40, one confirmation rung).

    rung (total)     printed (Aug 2026) wording    December 2025 wording
    0 v 16                 +390 (250 g)                 +413 (300 g)
    16 v 128               +398 (250)                   +406 (250)
    128 v 1024             +382 (250)                   +512 (600)
    1024 v 2048            +108 (100)                    +81 (100)
    2048 v 4096            +143 (100)                    +92 (100)
    4096 v 8192             +21 (100)                    +24 (100)
    8192 v 16384            +14 (100)                    +31 (100)
    height               ≈1450                         ≈1560

Heights ±95 each: a difference of 110 ± 135.  One rung differs by 130 at
about 2.6σ (128 v 1024), the next two go the other way; both saturate at
8192.  Indistinguishable by this yardstick.

## The two wordings, locally: three positions (2026-11-02)

`sgo pos <file> ...` analyses a given position: `show`, `resolve m0 m1`,
`value games R`, `matrix R <m0,..> <m1,..>` (policy playouts) and `matrixeq
games R <m0,..> <m1,..>` (equilibrium guided continuations per entry; Black
rows, White columns, Black's mean final margin; the optimal mixtures x, y).
Position files and matrices are in runs/pos/.  The wordings differ only at a
conflict adjacent to a q-stone and to stones of one color, not trapping:
August gives that color the stone, December a q-stone.  In 200 equilibrium
guided 9×9 games (`SGO_DIVLOG=1`) conflicts per game were 0.71 trapping,
1.19 adjacent to both colors or none, 1.24 one color, 0.025 divergent.

j1 (9×9): B D4, D5; W C3; Q C4 — the 3-3 invasion with a two-stone wall; the
divergent point is the hane C5.  j2: Q E5, E6 (a center collision); B D5;
W F5; divergent D6 (Black's extension) and F6 (White's).  j3: Q E5; B D4,
D6, F5, G4; W C4, C6, E4, E6 — Black's cutting point D5 is adjacent to the
q-stone.  Matrices with 60 (j1) and 100 (j2, j3) continuations per entry,
R = 8; the per-entry standard error is about 2.5 (j1) and 2 points.

    j1 value: August +7.9 (saddle D3/D3), December +8.5 (mixed); the C5/C5
       entry 9.5 → 5.9; White's C5 is not played under either wording.
    j2 value: August +1.3, December −0.7; D6/D6 entry 8.9 → −1.1; White's
       D6 contest is not played under either wording (White plays F6 / F4).
    j3 value: August +9.3, December +5.0 (100 continuations per entry);
       D5/D5 entry +11.8 → −9.1 (the q-cut).  With 300 continuations per
       entry (runs/pos/pos_j3_rule3_300.txt, _rule4_300.txt; standard error
       1.6 per entry): August value +9.8, December +7.0, D5/D5 +13.1 → −7.3;
       White's cut D5 is played with y = 0.69 (August) and 0.82 (December),
       Black never connects at once under either wording (it extends at D3
       or D7), so the wordings differ sharply at the collision and by a few
       points in the value; the 100-continuation pure saddle (D3, D5) under
       December was a sampling artefact.  The D3/D5 entry, whose immediate
       placement is the same under both wordings, is 12.0 (August) vs 7.5
       (December) in the 300-continuation runs and 11.8 vs 5.0 in the
       100-continuation runs: the wordings keep acting in the continuations.

Rectangular boards and an exact solver (2026-11-02, for the 2×3 example).  A
position file may give `h <rows>` (n = columns); `sgo pos <file> solve <depth>`
solves the position exactly to the horizon: every empty point and the pass for
both sides, the matrix of continuation values, memoized on the full state
(display with stamps, previous hash, turn); leaves are scored by area.  pos/y1.txt
is the 2×3 position (file rows 1–2 = the sketch's rows 2–3; blue = B, black = W):
B A2, B2; Q C2; W B1; empties A1, C1.  Exact values (depth 8 = depth 10, the
same for five stamp histories): August +0.085, Blue mixes C1 .915 / A1 .085,
Black C1 .869 / pass .131; December +0.617, Blue C1 .995, Black C1 .945 /
pass .055.  Blue's C1 row: August (0.65, 1.00, 0.00) against pass / A1 / C1,
December (0.65, 1.00, 0.62): under December the move is safe against every
reply, under August Black's own C1 neutralizes it and Blue must mix.

## Go with positional superko, 11×11 (2026-11-03)

`SGO_SUPERKO=1`: in the actual Go games of match mode a move that recreates an
earlier whole-board position of the game is illegal (passes always legal); the
agent's menu of five is drawn from the moves legal under superko; the playouts
keep the simple ko.  ladder11s.sh = ladder11p.sh with the superko, the rungs to
1638v3277 regardless of saturation, seeds from 700; runs/go_ko1_n11_sk_tot.txt.
Without superko 22% of random 11×11 Go games and 29–38% of the earlier ladder's
games reach the 500-ply cap (cycles); with it none of the 1250 ladder games did
(longest game 226 plies in the random sample; mean 156–174 plies against 225–290).

    rung        games  B score   gap   band        turns
    0v3           200   0.880   +346  [+311,+388]  173.9
    3v26          300   0.913   +408  [+375,+447]  173.9
    26v205        350   0.937   +469  [+434,+511]  170.0
    205v410       100   0.680   +131  [ +95,+170]  156.2
    410v819       100   0.630    +92  [ +57,+130]  156.5
    819v1638      100   0.590    +63  [ +28, +99]  155.6
    1638v3277     100   0.500     +0  [ -35, +35]  161.3
    height                      +1510

Heights at 11×11 over the same seven rungs, each about ±95: Go superko 1510,
Go simple ko 1623, SGo December wording 1560, SGo August (printed) 1454.  SGo
with the fiat simple ko still has 8–17% of its games at the 250-turn cap.

## 13×13: SGo December wording without a ko rule vs Go with superko (2026-11-03/04)

ladder13a.sh (adaptive samples to band ≤ 40, 100–600 games per rung, rungs to
1638v3277, one process; SGO_KOFLAG=0 for no ko rule, SGO_SUPERKO=1 for the Go
superko).  SGo: the printed Dec game, no ko rule, cap 300 turns / playouts 250
(runs/sgo_ko0_n13_p4_tot.txt).  Go: positional superko in the games, cap 600
plies / playouts 400 (runs/go_ko1_n13_sk_tot.txt).

    rung        SGo Dec no-ko (games)      Go superko (games)
    0v3         +370 [+337,+409] (250)     +417 [+384,+457] (300)
    3v26        +431 [+397,+473] (300)     +447 [+413,+487] (350)
    26v205      +566 [+532,+608] (600)     +512 [+475,+556] (400)
    205v410     +164 [+127,+205] (100)      +85 [ +50,+122] (100)
    410v819     +131 [ +95,+170] (100)     +131 [ +95,+170] (100)
    819v1638     +56 [ +21, +92] (100)     +182 [+144,+224] (100)
    1638v3277    +45 [ +11, +81] (100)      +21 [ -14, +56] (100)
    height      ≈1765 (±97)                ≈1794 (±99)

Difference −29 ± 139.  Caveat on the SGo side: without a ko rule 48–52% of the
games at the low rungs and 68–76% at the upper rungs run to the 300-turn cap
(loops; 17% with the fiat ko at 11×11), and are scored by area there; no Go
game reached its cap.  The earlier 13×13 ladders (fiat ko on both sides, fixed
100/60 games) gave SGo August ≈1760 and Go simple ko ≈1550 with about half of
the Go games at the cap.

## The eye defense, and the clean 13×13 comparison (2026-11-04)

Tracing a cycling SGo game showed a single ko retaken alternately while the
other side passed.  The SGo defense against a ko — playing the recapture point
in the same turn, so that the conflict yields a q-stone by placement rule (1) —
is a move into one's own single-point eye, which the agents' move set excluded.
The agents could never defend a ko, and at the end of a game the only moves
left were retakes.  `SGO_EYEDEF=1` admits an own eye as a policy move when an
adjacent own chain has that point as its only liberty (the opponent could
capture there).  Dec wording, no ko rule, 13×13: games at the 300-turn cap
196/300 → 0/300 (random), 45/60 → 0/60 (26v26); 9×9 equilibrium-guided play
ends on its own 53% → 100%.  Uniform random play over all empty points (table
mode) is unaffected.  Go is unaffected (an eye fill is never a defense there).

SGo Dec, no ko rule, eye defense (ladder13p.sh = ladder13a.sh with two strided
processes per rung, seeds 900+; runs/sgo_ko0_n13_p4_ed_tot.txt):

    rung        games  B score   gap   band         turns
    0v3           250   0.896   +374  [+341,+413]   114.0
    3v26          500   0.928   +444  [+416,+477]   116.0
    26v205        600   0.963   +566  [+532,+608]   114.7
    205v410       100   0.675   +127  [ +91,+166]   106.6
    410v819       100   0.735   +177  [+140,+219]   103.9
    819v1638      100   0.685   +135  [ +99,+174]   103.9
    1638v3277     100   0.560    +42  [  +7, +77]   103.3
    height                     ≈1865 (±98)

No game of either ladder reached its cap.  Go with positional superko (above):
≈1794 (±99).  Difference +71 ± 139.

## The paper's figures under the December wording (branch Dec, 0235; 2026-11-05)

Conventions of the Dec text: SGo by its printed rules (`SGO_PLACE=4`), no ko
rule (`SGO_KOFLAG=0` in the ladder scripts, the `ko` argument 0 of `match`),
the agents' move set with the eye exception (`SGO_EYEDEF=1`); Go under
positional superko (`SGO_SUPERKO=1`) in the match agents and in the greedy
agent of `greedygo`; komi 0.  runstats4.sh reproduces the tables of Sections
2.2, 7.1 and 7.2 (runs/stats4.txt):

    SGO_SUPERKO=1 ./sgo greedygo 1000 6 12 5 800          # 7.2, Go: 13.8 / 4.9% / 100% / 15.8, Black +2.66
    SGO_PLACE=4 SGO_EYEDEF=1 ./sgo eqplay 1000 16 5 400   # 7.1, SGo: 13.3 / 4.2% / 100% / 18.4 / 2.4 / 1.3 / 1.25 / 4.0 / 2.8;
                                                          #      mixed 66.1% (control 50.6%), spread 15.1
    SGO_PLACE=4 ./sgo table sgo 1000 40                   # 2.2, SGo 5x5: 14.6 / 4.6% / 99.1% / 22.4 / 2.2 / 1.1 / 1.05 / 2.9 / 2.5
    SGO_N=19 SGO_PLACE=4 ./sgo table sgo 1000 0           # 2.2, SGo 19x19: unchanged (no divergent conflict in 1000 games)
    SGO_NOCAP=1 SGO_PLACE=4 ./sgo table sgo 500 40        # 2.2, reduction disabled: 0.3 / 74% draws

Without the eye exception equilibrium guided SGo ends on its own in 90.7% of
the games (9% cycle); greedy Go without any ko rule in 92.6% (7% cycle).
`SGO_DIVLOG=1` now also counts the conflict classes in table mode: at 5x5
random play 0.022 divergent conflicts per game, at 19x19 none in 200 games.

The ladders under these conventions (ladder13p.sh, adaptive samples to band
<= 40, rungs to 1638v3277, no game at a cap); the paper reports the 13x13 row,
the rest is recorded here ("simplest rule" = rule (2) omitted, every conflict a
q-stone, SGO_PLACE unset):

    board   SGo Dec   SGo simplest rule   Go superko
    5x5       893          830               845
    7x7       946         1008              1098
    11x11    1467           --              1510
    13x13    1865           --              1794
    19x19    2235           --               (running: 0v3 +390)

    SGO_N=5  SGO_PLACE=4 SGO_KOFLAG=0 SGO_EYEDEF=1 ./ladder13p.sh sgo 200 0        # runs/sgo_ko0_n5_p4_ed_tot.txt
    SGO_N=5  SGO_KOFLAG=0 SGO_EYEDEF=1 ./ladder13p.sh sgo 200 0                    # runs/sgo_ko0_n5_ed_tot.txt (simplest rule)
    SGO_N=5  SGO_SUPERKO=1 ./ladder13p.sh go 400 0                                 # runs/go_ko1_n5_sk_tot.txt
    SGO_N=7  ... sgo 300 0 / go 600 0;  SGO_N=11 ... sgo 300 250 (Go 11x11: ladder11s.sh)
    SGO_N=13 SGO_PLACE=4 SGO_KOFLAG=0 SGO_EYEDEF=1 ./ladder13p.sh sgo 300 250      # runs/sgo_ko0_n13_p4_ed_tot.txt
    SGO_N=13 SGO_SUPERKO=1 ./ladder13a.sh go 600 400                               # runs/go_ko1_n13_sk_tot.txt

## Is the December wording deeper than the August one? (2026-11-06)

pairedaug.sh replays the 13x13 December ladder (no ko rule, eye defense) under
the August wording (SGO_PLACE=3) with the same seeds and game counts; pairs.py
compares the two game by game (runs/sgo_ko0_n13_p3_ed_tot*).  The games are
identical until a divergent conflict occurs inside a playout, after which the
random streams part, so 1747 of the 1750 game pairs differ: the pairing buys
little, and the comparison is an independent replication.

    rung        Dec    Aug   diff  se      divergent conflicts in the games (Aug run)
    0v3        +374   +336   +38   49      1 in 250 games
    3v26       +444   +434   +10   42      8 in 500
    26v205     +564   +545   +19   52      2 in 600
    205v410    +127   +123    +4   52      0 in 100
    410v819    +177   +186    -9   55      0 in 100
    819v1638   +135   +100   +35   50      0 in 100
    1638v3277   +42    +78   -36   51      1 in 100
    height     1865   1802   +61 +- 133   12 in 1750 (0.7% of the games)

The wordings act differently only at a divergent conflict (one color adjacent,
a q-stone adjacent, not trapping).  At the game level these agents create one
in about 150 games, no more often at the top budget than at the bottom, so the
displays of the two games differ in 0.7% of the games played; even if every
such game were decided by it, a rung could move by about 5 Elo and the ladder
by about 35.  The measured difference, +61 +- 133, is noise.  By this
yardstick the two wordings are equally deep; the yardstick cannot see the
difference because its agents almost never reach the situation, up to 16384
playouts per turn.

## Neural self-play agents (sgonet.cpp, 2026-11-06 onward)

sgonet.cpp includes sgo.cpp and adds an AlphaZero-style trainer for 9x9 SGo,
CPU only, no libraries: a residual network (8 input planes: black, white,
q-stones, the same three for the previous turn, empties, ones; 32 filters,
4 residual blocks; a policy head per player, 82 outputs each; a tanh value
head), decoupled PUCT for the simultaneous move (each player keeps its own
visit and value statistics at a node, selects independently, the joint action
indexes the child; backup v for Black and -v for White), Dirichlet noise at the
root in self-play, moves sampled from the visits for the first 20 turns and the
most visited move after that, the game result z = sign(area margin), training
by hand-written backpropagation with Adam, dihedral and color-swap
augmentation, two epochs over the last three generations.  The leaf value is
0.5 x net + 0.5 x one random playout (SGO_MIX); without the playout the random
net could not get off the ground.  About 4 ms per simulation, 100 simulations
per move.  Build: g++ -O3 -march=native -std=c++17 -o sgonet sgonet.cpp.

    sgonet init <weights> [seed]
    sgonet selfplay <weights> <games> <sims> <out.dat> <seed> [cap]     resumable (<out>.count)
    sgonet train <in> <out> <epochs> <lr> <file.dat> ...
    sgonet eval <weights> <sims> <budget> <games> <seed> [cap] [log]    against the paper's MC agent
    sgonet match <wA> <simsA> <wB> <simsB> <games> <seed> <cap> <log>  net against net
    sgonet arena <specA> <specB> <games> <seed> <cap> <log>             any two agents, spec mc<budget> | net:<weights>@<sims>
    sgonet census <weights> <games> <sims> <seed>                       self-play conflict census only
    env: SGO_PLACE (1 one-tier, 3 August, 4 December = default), SGO_MIX, SGO_TAU (match/eval/arena
    move choice: 0 = most visited, t > 0 samples visits^(1/t)), SGO_STRIDE=k/m (share one log), SGO_DUMP=1

The training loop is netloop4.sh <dec|aug|simple> <first> <last> [games=150
per process] [sims=100]: two self-play processes a generation (seeds 1000+k,
2000+k), training, then a 30-game match of the new net against the fixed base
nets/g13.bin (runs/net_ref*.txt).  Generations 0-13 were trained under the
December wording; at g13 the loop was forked into three, one per placement
rule, with the same seeds and game counts: A = December three-tier (SGO_PLACE=4,
nets/, data/), B = one-tier, every conflict a q-stone (SGO_PLACE=1,
nets_simple/, data_simple/), C = August three-tier (SGO_PLACE=3, nets_aug/,
data_aug/).  relaunch.sh restarts the loops after an interruption.  The data
files are not in this package (they are large); the nets g13 and g17 are.

Strength of the December nets against the MC agent at 205 playouts per
candidate (1024 per turn), 30 games, 100 simulations: g1 0%, g3 37%, g6 68%,
g9 90%, g12 97%, g13 92%.  Against the g13 base, 30 games: A g16 +241, g17
+70; B g16 +191, g17 +95; C g16 +120, g17 +191 (noise +-150).

Two conventions matter for matches between deterministic agents.  (1) Stalls:
with the most visited move always played, a lost side repeats a two-turn
suicide loop (G3/G4 against pass) instead of passing, and a winning net
refuses to pass against an opponent that never passes; 13-23% of such games
ran to the 200-turn cap.  In match, eval and arena both players therefore
sample their move from the visit distribution whenever the display repeats
(field reps in the game logs; capped= in the result lines); the stalled game
of the example then ended at turn 84.  (2) The engine marks a game that
reaches the cap as ended; count turns >= cap for the capped games.

### The simulation ladder of a net is flat

g17 under the December rule, net against itself (runs/netladder_dec_g17*,
runs/diag/): 25 vs 12 simulations +10 (100 games); 50 vs 25 -28 (37 games;
the August net -109); 100 vs 12 simulations +80 +- 57 (40 games); with the
playout blend off (SGO_MIX=0) 50 vs 25 +89 +- 57.  The MC agents gain 400+
Elo per doubling at the bottom of their ladder because they start from
nothing; the net's strength is in its policy, and the search adds little at
these budgets.  Elo per doubling of compute is a property of the agent family,
not of the game, so the net ladders were not pursued as a depth yardstick.

### The three rules, 9x9: MC ladders and the nets above them

The paper's ladder on 9x9 under each rule (ladder13p.sh with SGO_N=9, cap 200,
playouts 150 turns, band <= 40 Elo, 100-600 games a rung, eye defense, no ko
rule; runs/sgo_ko0_n9_p{4,1,3}_ed_tot.txt), then the g17 net of that rule
against the 1638 rung (place9.sh; runs/place_g17_b1638.txt, 100 games, 100
simulations; the capped games were all net wins and are scored as they stood):

    rung          A Dec   B one-tier   C Aug
    0v3            +252      +271      +301
    3v26           +390      +409      +386
    26v205         +408      +411      +402
    205v410        +135       +96       +78
    410v819        +123       +63      +108
    819v1638        +92        +0       +38
    1638v3277       +14       +56       +60
    ladder         1414      1306      1373      (+- about 100 each)
    g17 over 1638  +424      +449      +552      (+-66, +-71, +-97)
    to the net    ~1824     ~1699     ~1865      (+- about 170 each)

No difference is resolvable; the B and C nets started from the December g13
and had four generations to adapt, which if anything handicaps them.  B's g17
beats the g13 base 19-11 under rule B.  Self-play census per game at g13-g17
(trapping / both-or-none / one-color / divergent): A about 2.9/2.1/1.0/0.02,
C about 2.7/2.0/1.0/0.02, B about 3.4/1.9/1.1/0.03 - more trapping conflicts
when every conflict is a q-stone.  Collisions per game: random play 6.5 in 82
turns, the net at 100 simulations 5.3 in 58 turns, at 4-8 simulations 17.

### One tournament, MC agents and nets together (game A, 2026-11-08)

tournament.sh runs a round robin through arena (two strided processes a pair);
bt.py fits Bradley-Terry ratings (draws half, 0.1 virtual wins a pair to keep
all-win players finite, bootstrap over games).  Players: mc0 (the random
policy), mc3, mc26, mc205, mc819, mc3277, and the December nets g1, g4, g7,
g10, g13, g17 at 100 simulations; 16 games a pair, 1056 games
(runs/tour_A17/: matrix.txt, bt.txt, the game logs).

    g17 +1162 +- 89, g13 +979, g10 +963, mc3277 +753, mc819 +726, g7 +704,
    g4 +573, mc205 +555, mc26 +340, g1 +336, mc3 +141, mc0 0.

One Elo scale does not fit the results.  The MC chain alone (1-15, 1-15,
2-1-13, 4-12, 6-10 at the adjacent pairs) sums to about 1500 from random to
mc3277; the joint fit puts mc3277 at +753 because the nets are not transitive
with the MC agents: g7 splits with mc3277 (6-10) and beats mc819 10-6, yet
loses 4-1-11 to the random policy, which mc819 and mc3277 beat 16-0; g1 is
level with mc26 (7-1-8) but random takes 3 of 16 from it and 0 of 16 from
mc26.  The nets beat random by 1 to 19 points (random beat g7 once by 77) and
pass early: play self-play never produced is misjudged.  Among the nets the
chain g1->g17 sums to about 1190 while the direct result is +340 (g1 took two
games from g17 in 33 and 35 turns, by +1 and +5, both ended by passes).  The
largest residuals of the fit: random v g7 observed 0.28, fitted 0.02 (+8 se);
g1 v g17 observed 0.12, fitted 0.01 (+5 se).  The height of a ladder is a
sum of adjacent gaps within one agent family; it compares games under that
family, which is how the paper uses it, and it is not an Elo range in the
transitive sense.

### The same tournament under the one-tier rule (B, 2026-11-10/11)

The B loop (every conflict a q-stone, SGO_PLACE=1), forked from the December
g13, was run to g25 with the same seeds and game counts as A.  Its tournament
(runs/tour_B25/) has the same roster: the six MC agents, the shared nets
g1-g13 (trained under A, playing under B), and B's own g17, g21, g25; 16
games a pair, 1456 games.  Ratings side by side, random = 0 (runs/tour_AB_compare.txt):

    player      A (Dec)     B (one-tier)
    mc3          +141 +-55    +316 +-104
    mc26         +338 +-61    +574 +-100
    mc205        +551 +-65    +880 +-105
    mc819        +718 +-70    +960 +-107
    mc3277       +748 +-70    +985 +-107
    g1           +334 +-69    +628 +-104
    g4           +569 +-73    +921 +-107
    g7           +709 +-78    +932 +-113
    g10          +981 +-73   +1167 +-111
    g13          +994 +-77   +1297 +-113
    g17 / b17   +1161 +-82   +1383 +-114
    g21 / b21   +1239 +-82   +1431 +-116
    g25 / b25   +1280 +-86   +1472 +-116

With the random policy as the zero the B scale is the wider one, by 15-30%.
The stretch sits at the bottom: under B the random policy loses 0-16 to
everything but mc3 (2-14) and g7 (1-15), while under A it took 3, 2 and 4
games of 16 from g1, g4 and g7.  From any other anchor the two games
coincide within the noise: the MC chain mc3 -> mc3277 spans 607 (A) and 669
(B); the nets' climb g1 -> g25 spans 946 and 844; the top net stands 532 and
487 above mc3277 (16-0 and 15-1); the shared nets g1 -> g13 span 660 and
669; the gain after the fork, g13 -> g25, is +286 under A and +175 under B
(+-150).  The hypothesis that the three-tier game is much deeper than the
one-tier game finds no support in any of these numbers; the one-tier game
shows, if anything, the larger span.  The B nets are also the less brittle
ones in this sample: the largest residual of the B fit is +3.8 se (g1 v
g13 observed 0.16), against +8.3 se under A.

The 9x9 MC ladders of the paper's kind (above) said the same: A 1414, B 1306,
each +-100.

### Refined (64 games on every pair within 300 Elo; 2026-11-12/13)

Both tournaments were refined by refine.sh: every pair whose fitted ratings
were within 300 Elo was brought from 16 to 64 games (34 pairs in A, 28 in B;
runs/tour_*/refine_pairs.txt, "R" lines in results.txt).  Ratings anchored at
mc3277 = 0 (runs/tour_A17/bt64_anchor3277.txt, runs/tour_B25/bt64_anchor3277.txt);
the third column is the gap to the next agent down:

    A (Dec three-tier)              B (one-tier)
      g25   +547 +-35   +29           b25   +487 +-37   +50
      g21   +518 +-32   +60           b21   +437 +-33   +65
      g17   +458 +-33  +144           b17   +372 +-33   +70
      g13   +314 +-27   +76           g13   +302 +-29  +128
      g10   +238 +-27  +214           g10   +174 +-25  +161
       g7    +24 +-24   +24            g7    +13 +-25   +13
    mc3277     0       +51         mc3277     0       +31
    mc819    -51 +-23   +80         mc819    -31 +-24   +51
       g4   -131 +-25   +19            g4    -82 +-25   +73
    mc205   -150 +-24  +213         mc205   -155 +-24  +266
     mc26   -363 +-31   +65            g1   -421 +-35    +3
       g1   -428 +-34  +203          mc26   -424 +-37  +288
      mc3   -631 +-42  +210           mc3   -712 +-56  +310
      mc0   -841 +-69                 mc0  -1022 +-112

The shared nets g1-g13 (the same files in both games) and the MC rungs sit
at the same heights under both rules.  The rule-specific climb g13 -> g25 is
+233 under A and +185 under B (+-45 each).  The one difference is at the
bottom: the random policy sits at -841 under A and -1022 under B; random play
is punished harder when every conflict is a q-stone.  The generations gain,
from g7 upward, +214, +76, +144, +60, +29 under A and +161, +128, +70, +65,
+50 under B: a smooth, flattening curve in both games.

## Branch reduce: Condition 4 of the capture rule (2026-11-14)

The `reduce` branch of the paper adds a route to def_captured (Definition
2.2): a trapped component is also captured, on any turn, when Condition 2
holds and no stone of the other color or q-stone adjacent to it is trapped by
the capturing side. "Trapped" here carries no turn: a stone is trapped when
its component has no liberties, and a q-stone is trapped by a side when,
replaced by a stone of the other side, it is. The route removes the leftovers
of standoffs. Under the rule of the Dec text a component left standing
without liberties is examined again only when a stone next to it is placed,
so it can stand for the rest of the game, and count. `SGO_ORPHAN=1` switches
the route on, in both layers of sgo.cpp and in sgonet.cpp; the default stays
the rule of the Dec text.

Validation. The fast layer agrees with the slow oracle under the route
(6,000 lockstep games). The browser engine of the SGo Arena page agrees with
sgo.cpp on 600 games, 40,835 turns. The route changes 5 of the 1,722 display
vectors and 2 of the 240 serial games of the Lean sheets: they were
regenerated with this engine, and `SGO_ORPHAN=1 ./sgo test` reads
tests/disp_or.txt and tests/serial_or.txt (0 mismatches). Lean release 1.5
formalizes the route and passes the same sheets. Every printed example of the
paper resolves as printed, stage by stage. A run prints how many components
the route captured (`[extra route: N chains captured]`).

The tables of Sections 2.2, 7.1 and 7.2 under the route (runstats5.sh →
runs/stats5.txt; runstats5b.sh → runs/stats5b.txt), Dec values in brackets:

    SGO_ORPHAN=1 SGO_PLACE=4 SGO_EYEDEF=1 ./sgo eqplay 1000 16 5 400   # 7.1/7.2: 14.2 / 5.7% / 100% / 18.5 / 2.3 / 1.2 / 1.02 (max 3) / 4.0 / 2.9
                                                                       #   [13.3 / 4.2% / 100% / 18.4 / 2.4 / 1.3 / 1.25 (max 5) / 4.0 / 2.8]
                                                                       #   mixed 65.7% (control 48.8%) [66.1% (50.6%)], spread 15.4 [15.1]
                                                                       #   signed margin -0.56, standard error 0.56 [+0.24]
    SGO_ORPHAN=1 SGO_PLACE=4 ./sgo table sgo 1000 40                   # 2.2, 5x5: 14.8 / 4.5% / 99.1% / 22.5 / 2.2 / 1.1 / 0.99 (max 2) / 2.9 / 2.5
                                                                       #   [14.6 / 4.6% / 99.1% / 22.4 / 2.2 / 1.1 / 1.05 (max 3) / 2.9 / 2.5]
    SGO_ORPHAN=1 SGO_N=19 SGO_PLACE=4 ./sgo table sgo 1000 0           # 2.2, 19x19: 239.8 / 0.3% / 100% / 399.5 / 4.0 / 0.8 / 1.00 (max 2) / 3.7 / 2.4
                                                                       #   [241.0 / 0.3% / 100% / 399.8 / 4.1 / 0.9 / 1.02 (max 2) / 3.6 / 2.2]
    SGO_ORPHAN=1 SGO_PLACE=4 ./sgo eqplay 1000 16 5 400                # without the eye exception: 92.6% end on their own [90.7%]

The peak recursion depth falls: a component freed at a later stage is now
captured by the route at the first stage. The cycling games without the eye
exception are Kos retaken turn after turn; of 8 traced, 6 had one side
retaking while the other passed and 2 were double Kos (`SGO_TRACECAP=1`).

The 13x13 ladder of Section 7.3 under the route (ladder_reduce.sh: the Dec
ladder's seeds and conventions with `SGO_ORPHAN=1`;
runs/sgo_ko0_n13_p4_ed_or_tot.txt), beside the Dec ladder:

    rung (playouts per turn)   reduce (SGO_ORPHAN=1)     Dec
    0 v 16                     +346 ±34 (250 games)      +374
    16 v 128                   +462 ±33 (450 games)      +444
    128 v 1024                 +581 ±40 (600 games)      +564
    1024 v 2048                +191 ±40 (100 games)      +127
    2048 v 4096                 +85 ±36                  +177
    4096 v 8192                 +45 ±35                  +135
    8192 v 16384                +60 ±35                   +42
    height                    ≈1770 ±96                 ≈1863 ±98     (Go superko ≈1795 ±99)

    SGO_N=13 SGO_PLACE=4 SGO_KOFLAG=0 SGO_EYEDEF=1 SGO_ORPHAN=1 ./ladder13p.sh sgo 300 250

No game reached the cap (longest 153 turns). The route lowers the height by
93 ± 137 against the Dec rule, and the reduce ladder stands 25 ± 138 below
Go's: the same height within the noise, as in the Dec text. The middle rungs
moved most (+64, −92, −90), each within two standard errors; the
top rung is +60, so the ladder has not saturated either.

## Rule D in Lean, and the test sheets of release 1.6 (2026-11-14)

The `reduce2` branch of the paper prints def_captured with five numbered
conditions; the rule is that of `reduce` (Condition 4 = `SGO_ORPHAN=1`).
Lean release 1.6 formalizes it together with rule (2) of the placement rule
of Section 2.3 in its December wording (`SGO_PLACE=4`): the Lean game is now
the printed game, rule D.

New modes regenerate the Lean sheets under the rule in force:

    SGO_ORPHAN=1 SGO_PLACE=4 ./sgo dispgen   tests/disp_or.txt   tests/disp_d.txt     # 209 of 1,722 vectors change
    SGO_ORPHAN=1 SGO_PLACE=4 ./sgo serialgen tests/serial_or.txt tests/serial_d.txt   # 170 of 240 games change, 22 cut, 3 probes dropped
    SGO_ORPHAN=1 SGO_PLACE=4 ./sgo deltagen  tests/delta.txt     tests/delta_d.txt    # 299 of 390 games change, 17 cut, 1 probe dropped
    SGO_ORPHAN=1 SGO_PLACE=4 ./sgo test                                               # all four sheets, 0 mismatches

A game is cut before a move that the new rule makes unavailable (a stone of
a color stands where a q-stone used to be resolved away); a probe is dropped
when its moves became available. Every change of the display sheet is
a conflict that rule (2) resolves to a stone.

The decoherent family is new to this engine: `famStep` plays DSGo and
k-DSGo from the printed text (the postprocessing Delta with its re-cut, Pl
the placement rule with no objective reduction, the verdicts ver(D) and their
execution v·D), on the engine's own placement, serialization map and
objective reduction. tests/delta.txt is the original DSGo/k-DSGo sheet of
the Lean project (generated in 2025 by an independent Python reference);
`./sgo deltatest tests/delta.txt` replays it exactly, 390 games and 3,262
turns, under both capture rules. `./sgo test` now runs it too (tests/delta_d.txt
under rule D).
