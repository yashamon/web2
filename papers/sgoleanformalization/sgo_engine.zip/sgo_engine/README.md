# sgo.cpp — SGo / Go engine remake, Ko experiment (2026-10-29)

Single-file C++17 engine for SGo (sgo.tex §2: joint placement with
q-stones, the capture conditions 1/2/3a/3b with the component-freshness
clause, Cap_t as the fixpoint of the basic reduction, the stage recursion)
and classical Go, transcribed from the differentially tested Lean engine
(SgoDisplay.lean, SgoSerial.lean, SgoGo.lean; Lean 4.15.0 release 1.4).

Build: `g++ -O2 -std=c++17 sgo.cpp -o sgo`

## Validation

`./sgo test` replays the three Lean test sheets (converted to `tests/`):

    disp tests: 1722 cases, 0 mismatches      (TestsDAll.lean — display resolution, 3×3)
    go tests:   1844 cases, 0 mismatches      (Tests.lean — one classical move, 3×3)
    serial tests: 240 games, 2009 turns, 0 bad (TestSerial.lean — whole SGo games incl. 5×5)

Uniformly random play (`./sgo ustats sgo 1000 40`) reproduces the printed
§2.2 random-play row for SGo 5×5 (13.6 / 4.6% draws / 22.4 turns).  The
printed Go row (12.0 / 5.4% / 39.9) is reproduced at an 80-ply bound
(`./sgo ustats go 1000 80` → 11.5 / 5.3%); at 40 plies 18.3 / 0%, at 120
plies 7.0 / 12.1%.  So the printed random-play rows were computed with a
bound of 40 SGo turns = 80 Go plies.

## Play conventions

* Policy (menu and playouts): uniformly random over the empty intersections
  that are not the mover's own single-point eye and not classical suicide;
  pass only when none remains (the footnote convention of §7.1).
* Agent of budget b: a random menu of at most five policy moves; for each,
  b playouts to the end of the game (the opponent's move this turn drawn at
  random in SGo); the move with the best mean area margin, ties at random.
  Budget 0 = a random menu move.  **b counts playouts per candidate** (so a
  budget-16 agent runs up to 80 playouts a turn).  The second convention
  below reads the printed budgets as totals per turn (3/26/205/410/819 per
  candidate).
* Game end.  SGo: a double pass turn (the formal rule), or the display
  unchanged after two consecutive turns, or a full display, or the cap.
  Go: two consecutive passes or the cap.  Cap 200 (SGo turns / Go plies)
  unless stated.  Komi 0.  Area scoring, an empty region counting for the
  color it alone touches.
* Fiat simple ko (option `ko=1`).  Go: the standard rule — a stone that has
  just captured exactly one stone, stands alone and has that point as its
  only liberty bars the opponent from that point next move.  SGo: the same
  read on the display after the turn's resolution — if exactly one stone of
  a color was removed this turn and the other player's stone of this turn
  stands alone with that point as its only liberty, the removed side may
  not play there next turn (both colors checked, independently).
* Elo gap of a rung = 400·log10(s/(1−s)), s the stronger agent's mean score
  (draw = ½); 100 games per rung (60 at the top), colors alternating.

## Commands

    ./sgo match <sgo|go> <ko 0/1> <budgetA> <budgetB> <games> [seed] [komi] [cap] [pdepth]
    ./sgo stats <sgo|go> <ko> [games]           # policy self-play statistics
    ./sgo ustats <sgo|go> [games] [cap]         # uniformly random play, as in §2.2
    ./sgo trace <sgo|go> <ko>                   # print the end of a capped policy game
    ./ladder.sh <sgo|go> <ko>                   # the five-rung ladder, per-candidate budgets
    ./ladder2.sh <sgo|go> <ko> <cap>            # total-budget rungs (3/26/205/410/819), printed bounds
    python3 summarize.py                        # table of all RESULT files in runs/

`pdepth` bounds the playout length (SGo turns / Go plies; 0 = to the end).

## Results — see runs/*.txt and `python3 summarize.py`

Ko loops.  Without a Ko rule both games cycle under the policy.  Go: the
usual single-ko recapture cycle (`./sgo trace go 0`).  SGo: a double ko —
two ko shapes, each player retaking a different one every turn, display
period 2 (`./sgo trace sgo 0`); the q-stone and the trapping clauses do not
bite because the two recaptures are at different points.  Share of policy
self-play games (budget 0, 1000 games, cap 200) reaching the cap: SGo 8.3%
(ko off) → 1.6% (ko on); Go 23.3% → 2.1%.  The residue under the simple ko
rule is the double ko, legal in Go too.

Ladders (Elo gap of each rung, B over A; heights = sums).  Per-candidate
budgets, cap 200:

    rung         SGo ko off   SGo ko on   Go ko off   Go ko on     printed (§7.3)  SGo   Go
    0 v 16          +512        +552        +676        +798                      +308  +173
    16 v 128        +246        +301        +246        +346                      +330   +89
    128 v 1024       +42         +49        +168        +100                      +215   +63
    1024 v 2048      -17         -35          +7         +14                       +52   -45
    2048 v 4096      +70         +12          --          --                        0    --
    height          ≈850        ≈880       ≈1100       ≈1260                     ≈900  ≈300

Print convention (budgets read as totals per turn: 3/26/205/410/819 per
candidate; bounds 40 SGo turns / 80 Go plies; ko off):

    rung (total)   SGo     Go
    0 v 16         +382   +301
    16 v 128       +241   +338
    128 v 1024     +200   +258
    1024 v 2048     -14    +24
    2048 v 4096       0    +12
    height         ≈810   ≈930

Playouts cut short (print convention, first three rungs): SGo with 5-turn
playouts +191/+147/−53 → ≈390 (2-turn: +225/+78/…); Go with 10-ply
playouts +424/+215/+89 → ≈730.  Short playouts compress SGo, not Go.

Reading.  (1) A fiat simple ko changes neither ladder's shape: both games
saturate at the same rung with and without it; ko on lifts the heights by
≈30 (SGo) and ≈160 (Go), mostly at the bottom rung, where the capped
looping games add noise.  (2) The printed SGo ladder is reproduced in shape
and height (≈850–880 vs ≈900, saturation at 1024–2048).  (3) The printed Go
ladder (≈300, saturating by 1024 with a negative last rung) is NOT
reproduced: under every convention tried here the Go ladder is as high as
SGo's or higher (≈930–1260).  The "three times the height" comparison of
§7.3 and the introduction is not supported by this engine.  The original
engine is lost, so the printed Go figures cannot be audited.

Simplified capture condition (`SGO_SIMP=1`: condition 3(b) without "and is
not a q-stone", the clause Remark rem_suicidalcapture names as the one
precluding Ko loops; condition 2 and "no stone in C is created on this turn"
kept).  118 of the 3806 Lean sheet cases change, all q-stone cases.  Random
play: 74% of games end on their own within 40 turns (printed rule 100%),
mean 27.9 turns (22.4).  Policy self-play capped: 6.9% (ko off), 0.9% (ko on).
Ladder, per-candidate budgets, cap 200:

    rung         simplified, ko off   simplified, ko on   printed rule, ko off / on
    0 v 16             +576                 +604                +512 / +552
    16 v 128           +269                 +230                +246 / +301
    128 v 1024          +56                 +135                 +42 /  +49
    1024 v 2048          --                  -21                 -17 /  -35
    height to 1024     ≈900                 ≈970                ≈800 / ≈900

The ko-off 1024 v 2048 rung was stopped: with the looping games running to
the 200-turn cap inside every playout it costs ≈2 min a game.  Within the
rung bands (±40) the four SGo ladders coincide: neither the simplification
nor the fiat ko changes the depth of SGo as this family measures it.

7×7 versus 5×5, both games with the fiat ko, printed SGo rules, komi 0,
cap 200, budgets as totals per turn (16/128/1024/2048/4096 ≈ 3/26/205/410/
819 per candidate), 100 games a rung (60 at the top).  `SGO_N=7`.

    rung (total)    SGo 7×7   Go 7×7   SGo 5×5   Go 5×5
    0 v 16            +382     +346      +246     +478
    16 v 128          +323     +288      +288     +275
    128 v 1024        +288     +552      +210     +275
    1024 v 2048        +45      +92       +28      +35
    2048 v 4096        +65      +83       -95      +35
    height          ≈1100    ≈1360      ≈680    ≈1100

Mean game length at the middle rung: SGo 7×7 43 turns, Go 7×7 79 plies.

Three-tier placement resolution (`SGO_PLACE=3`; sgo.tex up to 2026-08-25,
§"Stone placement resolution rule": a same-intersection conflict resolves
to a q-stone if either color placed there would be trapping, else to the
color of the only adjacent color, else to a q-stone; everything else as
printed).  Checked on the old §2 example (E7 black, G1 trapping move, no
capture).  362 of the 3806 Lean sheet cases change, all conflict cases.
Random play 5×5: margin 14.8, draws 3.8%, 99% self-end in 40 turns, 22.4
turns (printed rule 13.6 / 4.6% / 100% / 22.4).  Policy self-play capped:
6.8% (ko off), 1.3% (ko on).  Ladders, ko on, total budgets, cap 200:

    rung (total)    SGo 7×7 three-tier   SGo 7×7 printed   SGo 5×5 three-tier   SGo 5×5 printed
    0 v 16                +315                +382                +372               +246
    16 v 128              +424                +323                +295               +288
    128 v 1024            +354                +288                +295               +210
    1024 v 2048            +45                 +45                 -14                +28
    2048 v 4096            +83                 +65                   0                -95
    height              ≈1220               ≈1100                ≈950               ≈680

## Engine rewrite (2026-11-01) and the 13×13 ladders

Fast layer: an incrementally maintained chain table (circular stone lists,
pseudo-liberties with the sum / sum-of-squares atari test), an empties list
and a libertyless-chain list; the capture conditions of def_captured are
evaluated through the table (isCapturedF, clause by clause as isCaptured)
and only for libertyless chains whose stamp bound reaches the stage;
display hash for the end rule; per-turn removal log for the fiat ko.  The
slow functions stay as the oracle: `./sgo test` replays the Lean sheets
through both; `./sgo difftest [games] [seed]` runs lockstep random games
(sizes 3–9) comparing legality cell by cell, displays, chain tables and Go
captures; `SGO_CHECK=1` cross-checks every capture evaluation and the ko
log inside a match.  All zero.  Before the sampler change the fast engine
reproduced the old engine's 13×13 games move for move.  Speed at 13×13:
≈20× (SGo 16.4 s → 0.8 s, Go 18.9 s → 1.0 s for the budget-3 probe).
Matches are resumable per game (`SGO_LOG`), each game seeded on its own.

13×13, ko on, SGo with the three-tier placement rule versus Go, budgets as
totals 16·2^k per turn (per candidate 3, 26, 205, 410, 819, 1638, 3277,
6554), 100 games a rung up to 2048 and 60 beyond; SGo cap 300 turns,
playouts 250 turns; Go cap 600 plies, playouts 400 plies (about a third of
13×13 policy Go games cycle in double kos under the simple ko rule and are
scored at the cap).  Climbing until a rung's gap is at most +40.

    rung (total)        SGo three-tier      Go
    0 v 16                  +363          +315
    16 v 128                +449          +424
    128 v 1024              +449          +552
    1024 v 2048             +168          +151
    2048 v 4096             +191           +70
    4096 v 8192              +95          +108
    8192 v 16384             +47           -70   (Go saturated)
    16384 v 32768         0 (21 games, stopped)
    height to 16384       ≈1760         ≈1550

Height bands ≈ ±115 each.  The two ladders coincide within noise up to
8192; the game lengths differ (SGo ≈150 turns, Go ≈400 plies).

## 11×11 with adaptive samples (2026-11-02)

Each rung played until its 68% band half-width was at most 40 Elo
(ladder11.sh: minimum 100 games, maximum 600, grown in steps of 50;
band.py computes the band from the per-game log).  Ko on, SGo three-tier
(cap 250 turns, playouts 200) versus Go (cap 500 plies, playouts 350).
The stop rule (a rung at or under +40) fired for both at 8192; one
confirmation rung was run for each; the Go 32768 rung was stopped by
request after 62 games at exactly even.

    rung (total)     SGo three-tier (games)   Go (games)
    0 v 16               +390 (250)           +424 (350)
    16 v 128             +398 (250)           +382 (250)
    128 v 1024           +382 (250)           +463 (600)
    1024 v 2048          +108 (100)           +164 (100)
    2048 v 4096          +143 (100)           +119 (100)
    4096 v 8192           +21 (100)             +0 (100)
    8192 v 16384          +14 (100)            +70 (100)
    16384 v 32768          --              0 (62 games, stopped)
    height to 16384     ≈1450                ≈1620

Height bands ≈ ±95 (seven rungs at ≤ ±40 each).  Difference 170, about
1.3σ.  Across sizes, SGo three-tier / Go: 5×5 ≈950 / ≈1100, 7×7 ≈1220 /
≈1360, 11×11 ≈1450 / ≈1620, 13×13 ≈1760 / ≈1550 (13×13 at 60 games a rung,
bands ≈ ±110).

## Reproducing the figures of the paper (branch threetier, patch 0234)

Build: `g++ -O2 -std=c++17 sgo.cpp -o sgo`; validate: `./sgo test` (the Lean
sheets, 0 mismatches expected) and `./sgo difftest 300` (0 differences).  The
paper's SGo is the three-tier placement rule: every SGo command below carries
`SGO_PLACE=3`.  Each game is seeded on its own, so the numbers reproduce exactly
on any machine; runtimes are for one core of the cloud box used here.

Section 2.2, the random play table (seconds each):

    SGO_PLACE=3 ./sgo table sgo 1000 40          # SGo 5x5, bound 40 turns
    SGO_PLACE=3 ./sgo table sgo 1000 0           # SGo 5x5 unbounded ("with the bound lifted")
    ./sgo table go 1000 40                       # Go 5x5, bound 40 turns (80 plies)
    SGO_N=19 SGO_PLACE=3 ./sgo table sgo 1000 0  # SGo 19x19 unbounded
    SGO_N=19 ./sgo table go 200 1500             # Go 19x19, cap 1500 turns
    SGO_NOCAP=1 SGO_PLACE=3 ./sgo table sgo 500 40   # the objective reduction disabled
    SGO_NOCAP=1 ./sgo table sgo 500 40               # the same with a q-stone at every conflict

The TABLE line gives mean |margin|, draws, games ending on their own, mean
length (and the mean over the games that ended), q-stones created and on the
final display, peak recursion depth (stages of a turn that removed a stone;
the per-game peak averaged, and its maximum), peak and final number of
branches of the entanglement.  Go lengths are in move pairs.

Section 7.1 / 7.2, informed play on 5x5 (about three minutes each):

    SGO_PLACE=3 ./sgo eqplay 1000 16 5 400       # equilibrium guided SGo: 16 rollouts per matrix entry,
                                                 # seed 5, games stopped at 400 turns; prints TABLE, LENGTHS, EQ
    SGO_KO=1 SGO_PLACE=3 ./sgo eqplay 1000 16 5 400   # the same with the simple ko imposed
    ./sgo greedygo 1000 6 12 5 800               # greedy rollout Go: 6 candidates + pass, 12 rollouts, cap 800 plies
    SGO_KO=1 ./sgo greedygo 1000 6 12 5 800

The EQ line: turns with menus of size > 1, the share without a pure saddle
point ("mixed"), the mean within-turn spread of the 5x5 matrix, and the same
saddle test at fivefold rollouts on every tenth turn (the control).  The
matrix game is solved exactly (simplex); each player samples the optimal
mixed strategy.  TABLE's signedmargin is Black minus White.

Section 7.3, the 13x13 Elo ladder (about 30 hours on two cores; resumable):

    SGO_N=13 SGO_PLACE=3 ./ladder13.sh sgo 300 250   # SGo: cap 300 turns, playouts 250 turns
    SGO_N=13 ./ladder13.sh go 600 400                # Go: cap 600 plies, playouts 400 plies

ladder13.sh runs the rungs 0/3/26/205/410/819/1638/3277/... playouts per
candidate (16·2^k per turn), 100 games a rung up to 2048 and 60 beyond, with
the fiat ko (`sgo match ... 1 ...`), writing RESULT lines to
runs/<game>_ko1_n13[_p3]_tot.txt and per-game logs (`SGO_LOG`) next to them;
a killed run resumes where it stopped; it stops after a rung whose gap is at
most +40.  `SGO_STRIDE=k/m` lets m processes share one rung's games.  The
smaller boards: `ladder_tot.sh <game> 1 200` with `SGO_N=5|7`, and
`ladder11.sh` (adaptive sample sizes, band ≤ 40) for 11x11.  All RESULT
files and logs of the runs reported in the paper are in runs/; `python3
summarize.py` prints the tables with 68% bands.

The results quoted in the paper are in runs/stats3.txt (tables, informed
play), runs/stats2.txt and runs/stats.txt (earlier passes, same numbers), and
runs/sgo_ko1_n13_p3_tot.txt, runs/go_ko1_n13_tot.txt (the ladder).

## The two wordings of the three-tier rule, 11×11 (2026-11-02)

`SGO_PLACE=4` is the December 2025 wording: rule (2) also requires no
adjacent q-stone.  The two wordings differ only at a conflict adjacent to
a q-stone that is neither trapping nor adjacent to both colors (random play
5×5: 2.2 against 2.1 q-stones created per game).  Same adaptive protocol as
the 11×11 run above (band ≤ 40, stop at ≤ +40, one confirmation rung).

    rung (total)     printed (Aug 2026) wording    December 2025 wording
    0 v 16                 +390 (250 g)                 +413 (300 g)
    16 v 128               +398 (250)                   +406 (250)
    128 v 1024             +382 (250)                   +512 (600)
    1024 v 2048            +108 (100)                    +81 (100)
    2048 v 4096            +143 (100)                    +92 (100)
    4096 v 8192             +21 (100)                    +24 (100)
    8192 v 16384            +14 (100)                    +31 (100)
    height               ≈1450                         ≈1560

Heights ±95 each: a difference of 110 ± 135.  One rung differs by 130 at
about 2.6σ (128 v 1024), the next two go the other way; both saturate at
8192.  Indistinguishable by this yardstick.

## The two wordings, locally: three positions (2026-11-02)

`sgo pos <file> ...` analyses a given position: `show`, `resolve m0 m1`,
`value games R`, `matrix R <m0,..> <m1,..>` (policy playouts) and `matrixeq
games R <m0,..> <m1,..>` (equilibrium guided continuations per entry; Black
rows, White columns, Black's mean final margin; the optimal mixtures x, y).
Position files and matrices are in runs/pos/.  The wordings differ only at a
conflict adjacent to a q-stone and to stones of one color, not trapping:
August gives that color the stone, December a q-stone.  In 200 equilibrium
guided 9×9 games (`SGO_DIVLOG=1`) conflicts per game were 0.71 trapping,
1.19 adjacent to both colors or none, 1.24 one color, 0.025 divergent.

j1 (9×9): B D4, D5; W C3; Q C4 — the 3-3 invasion with a two-stone wall; the
divergent point is the hane C5.  j2: Q E5, E6 (a center collision); B D5;
W F5; divergent D6 (Black's extension) and F6 (White's).  j3: Q E5; B D4,
D6, F5, G4; W C4, C6, E4, E6 — Black's cutting point D5 is adjacent to the
q-stone.  Matrices with 60 (j1) and 100 (j2, j3) continuations per entry,
R = 8; the per-entry standard error is about 2.5 (j1) and 2 points.

    j1 value: August +7.9 (saddle D3/D3), December +8.5 (mixed); the C5/C5
       entry 9.5 → 5.9; White's C5 is not played under either wording.
    j2 value: August +1.3, December −0.7; D6/D6 entry 8.9 → −1.1; White's
       D6 contest is not played under either wording (White plays F6 / F4).
    j3 value: August +9.3, December +5.0 (100 continuations per entry);
       D5/D5 entry +11.8 → −9.1 (the q-cut).  With 300 continuations per
       entry (runs/pos/pos_j3_rule3_300.txt, _rule4_300.txt; standard error
       1.6 per entry): August value +9.8, December +7.0, D5/D5 +13.1 → −7.3;
       White's cut D5 is played with y = 0.69 (August) and 0.82 (December),
       Black never connects at once under either wording (it extends at D3
       or D7), so the wordings differ sharply at the collision and by a few
       points in the value; the 100-continuation pure saddle (D3, D5) under
       December was a sampling artefact.  The D3/D5 entry, whose immediate
       placement is the same under both wordings, is 12.0 (August) vs 7.5
       (December) in the 300-continuation runs and 11.8 vs 5.0 in the
       100-continuation runs: the wordings keep acting in the continuations.

Rectangular boards and an exact solver (2026-11-02, for the 2×3 example).  A
position file may give `h <rows>` (n = columns); `sgo pos <file> solve <depth>`
solves the position exactly to the horizon: every empty point and the pass for
both sides, the matrix of continuation values, memoized on the full state
(display with stamps, previous hash, turn); leaves are scored by area.  pos/y1.txt
is the 2×3 position (file rows 1–2 = the sketch's rows 2–3; blue = B, black = W):
B A2, B2; Q C2; W B1; empties A1, C1.  Exact values (depth 8 = depth 10, the
same for five stamp histories): August +0.085, Blue mixes C1 .915 / A1 .085,
Black C1 .869 / pass .131; December +0.617, Blue C1 .995, Black C1 .945 /
pass .055.  Blue's C1 row: August (0.65, 1.00, 0.00) against pass / A1 / C1,
December (0.65, 1.00, 0.62): under December the move is safe against every
reply, under August Black's own C1 neutralizes it and Blue must mix.

## Go with positional superko, 11×11 (2026-11-03)

`SGO_SUPERKO=1`: in the actual Go games of match mode a move that recreates an
earlier whole-board position of the game is illegal (passes always legal); the
agent's menu of five is drawn from the moves legal under superko; the playouts
keep the simple ko.  ladder11s.sh = ladder11p.sh with the superko, the rungs to
1638v3277 regardless of saturation, seeds from 700; runs/go_ko1_n11_sk_tot.txt.
Without superko 22% of random 11×11 Go games and 29–38% of the earlier ladder's
games reach the 500-ply cap (cycles); with it none of the 1250 ladder games did
(longest game 226 plies in the random sample; mean 156–174 plies against 225–290).

    rung        games  B score   gap   band        turns
    0v3           200   0.880   +346  [+311,+388]  173.9
    3v26          300   0.913   +408  [+375,+447]  173.9
    26v205        350   0.937   +469  [+434,+511]  170.0
    205v410       100   0.680   +131  [ +95,+170]  156.2
    410v819       100   0.630    +92  [ +57,+130]  156.5
    819v1638      100   0.590    +63  [ +28, +99]  155.6
    1638v3277     100   0.500     +0  [ -35, +35]  161.3
    height                      +1510

Heights at 11×11 over the same seven rungs, each about ±95: Go superko 1510,
Go simple ko 1623, SGo December wording 1560, SGo August (printed) 1454.  SGo
with the fiat simple ko still has 8–17% of its games at the 250-turn cap.
