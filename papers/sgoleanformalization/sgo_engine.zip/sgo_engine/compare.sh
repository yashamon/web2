#!/bin/bash
# the three-rule comparison at generation G: simulation ladders (12 -> 200 sims) of the A (Dec), B (one-tier) and C
# (Aug) nets, then the four cross-play matches.  usage: compare.sh <G> [games=100]; resumable (every piece skips what
# is done).  Results: runs/netladder_{dec,simple,aug}_g<G>.txt, runs/cross_g<G>.txt
cd /home/claude/eng
G=$1; N=${2:-100}
./netladder.sh dec_g$G nets/g$G.bin 4 40 100 300 "12 25 50 100 200" &
./netladder.sh simple_g$G nets_simple/g$G.bin 1 40 100 300 "12 25 50 100 200" &
wait
./netladder.sh aug_g$G nets_aug/g$G.bin 3 40 100 300 "12 25 50 100 200"
out=runs/cross_g$G.txt; touch $out
cross() { # cross <label> <place> <netA> <netB>: 100-game match at 100 sims, two strided processes
  local label=$1 place=$2 a=$3 b=$4; grep -q "^$label " $out && return
  SGO_PLACE=$place SGO_STRIDE=0/2 ./sgonet match $a 100 $b 100 $N 6001 200 runs/cross_g${G}_$label.games 2>>runs/cross_g${G}_$label.log > runs/tmp_cross_$label.0 &
  SGO_PLACE=$place SGO_STRIDE=1/2 ./sgonet match $a 100 $b 100 $N 6001 200 runs/cross_g${G}_$label.games 2>>runs/cross_g${G}_$label.log > runs/tmp_cross_$label.1 &
  wait
  echo "$label $(cat runs/tmp_cross_$label.0 runs/tmp_cross_$label.1 | grep MATCH | tail -1)" >> $out
}
cross ruleA_AvsB 4 nets/g$G.bin nets_simple/g$G.bin
cross ruleB_BvsA 1 nets_simple/g$G.bin nets/g$G.bin
cross ruleA_AvsC 4 nets/g$G.bin nets_aug/g$G.bin
cross ruleC_CvsA 3 nets_aug/g$G.bin nets/g$G.bin
echo DONE >> $out
