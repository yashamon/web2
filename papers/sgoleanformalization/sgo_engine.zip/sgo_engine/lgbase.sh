#!/bin/bash
# Robustness baselines for the MC-partner experiment (2026-11-13): every net of the original lines against mc0 (the random
# policy), 30 games, the same seeds as the league lines' eval0 (netloop6.sh): rule A nets/g1..g25, rule B
# nets_simple/g14..g25.  Runs at the lowest scheduler priority (its own autogroup at nice 19), so it only fills idle time.
cd /home/claude/eng
echo 19 > /proc/$$/autogroup 2>/dev/null
mkdir -p runs/lgbase
for k in $(seq 1 25); do f=runs/lgbase/A_eval0_g$k.txt; [ -f $f ] && continue
  SGO_PLACE=4 ./sgonet eval nets/g$k.bin 100 0 30 $((5000+k-1)) 200 2>/dev/null > $f.tmp && mv $f.tmp $f; done
for k in $(seq 14 25); do f=runs/lgbase/B_eval0_g$k.txt; [ -f $f ] && continue
  SGO_PLACE=1 ./sgonet eval nets_simple/g$k.bin 100 0 30 $((5000+k-1)) 200 2>/dev/null > $f.tmp && mv $f.tmp $f; done
touch runs/lgbase/DONE
