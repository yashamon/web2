#!/bin/bash
# round robin of agents under one rule: every pair plays <games> games (colors alternating) through sgonet arena, two
# strided processes per pair; resumable.  usage: SGO_PLACE=<rule> tournament.sh <name> <games> <spec1> <spec2> ...
#   spec = mc<budget> | net:<weights>@<sims>.  Logs runs/tour_<name>/p<i>_<j>.games, results runs/tour_<name>/results.txt
cd /home/claude/eng
# SGO_GO=1 in the environment selects the Go arena (goarena, cap 300 plies, komi SGO_KOMI); otherwise the SGo arena (cap 200 turns)
if [ -n "$SGO_GO" ]; then MODE=goarena; CAP=300; else MODE=arena; CAP=200; fi
SG=${SGONET:-./sgonet}
name=$1; games=$2; shift 2; players=("$@"); n=${#players[@]}; dir=runs/tour_$name; mkdir -p $dir; res=$dir/results.txt; touch $res
echo "# players: ${players[*]}" > $dir/players.txt
for ((i = 0; i < n; i++)); do for ((j = i + 1; j < n; j++)); do
  grep -q "^P $i $j " $res && continue
  log=$dir/p${i}_${j}.games; seed=$((9000 + 100 * i + j))
  SGO_STRIDE=0/2 $SG $MODE "${players[i]}" "${players[j]}" $games $seed $CAP $log 2>>$dir/p${i}_${j}.log > $dir/tmp.0 &
  SGO_STRIDE=1/2 $SG $MODE "${players[i]}" "${players[j]}" $games $seed $CAP $log 2>>$dir/p${i}_${j}.log > $dir/tmp.1 &
  wait
  echo "P $i $j $(cat $dir/tmp.0 $dir/tmp.1 | grep -E 'ARENA|GOARENA' | tail -1)" >> $res
done; done
echo DONE >> $res
