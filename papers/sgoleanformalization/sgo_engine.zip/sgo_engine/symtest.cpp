#define main engine_main
#include "sgo.cpp"
#undef main
// color symmetry of the rules: swap(resolve(D, m0, m1)) == resolve(swap(D), m1, m0) over random games
static void swapColors(Display& D) { for (int i = 0; i < D.N; i++) { if (D.kind[i] == B) D.kind[i] = W; else if (D.kind[i] == W) D.kind[i] = B; } }
int main(int argc, char** argv) {
  g_n = 9; g_place = 4; Board bd(9); Rng rng(5); long checked = 0, bad = 0; int games = argc > 1 ? atoi(argv[1]) : 200;
  for (int gnum = 0; gnum < games; gnum++) {
    Display D; D.clear(bd.N); int t = 1;
    for (int turn = 0; turn < 120; turn++) {
      int e[MAXC], k = 0; for (int i = 0; i < bd.N; i++) if (D.kind[i] == EMPTY) e[k++] = i; if (k == 0) break;
      int m0 = rng.below(k + 1) == k ? -1 : e[rng.below(k)], m1 = rng.below(k + 1) == k ? -1 : e[rng.below(k)];
      Display D1 = D; resolveTurn(bd, D1, t, m0, m1);
      Display D2 = D; swapColors(D2); resolveTurn(bd, D2, t, m1, m0); swapColors(D2);
      checked++; if (D1 != D2) { bad++; if (bad <= 3) fprintf(stderr, "asymmetry at game %d turn %d moves %d/%d\n", gnum, t, m0, m1); }
      D = D1; t++;
    }
  }
  printf("checked %ld turns, asymmetric %ld\n", checked, bad); return bad ? 1 : 0;
}
