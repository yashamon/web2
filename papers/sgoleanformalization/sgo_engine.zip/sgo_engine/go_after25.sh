#!/bin/bash
# when the Go loop has produced g25 and its progress check, stop the loop and run the Go tournament (same roster as
# A and B: the six MC agents and the nets g1 g4 g7 g10 g13 g17 g21 g25), then refine it to 64 games within 300 Elo.
# Resumable: tournament.sh and refine.sh skip what is done.
cd /home/claude/eng
while [ ! -f runs/net_ref_go_g25.txt ]; do sleep 120; done
for p in $(pgrep -f 'netloop5.sh go'); do kill $p; done; sleep 1
for p in $(pgrep -f 'goselfplay nets_go/g25'); do kill $p; done; sleep 1
rm -f data_go/g25_a.dat data_go/g25_b.dat data_go/g25_a.dat.count data_go/g25_b.dat.count
sed -i 's/^tags=${\*:-go}/tags=${*:-}/' relaunch.sh   # no loop restarts from here on
export SGO_GO=1
./tournament.sh G25 16 mc0 mc3 mc26 mc205 mc819 mc3277 net:nets_go/g1.bin@100 net:nets_go/g4.bin@100 net:nets_go/g7.bin@100 net:nets_go/g10.bin@100 net:nets_go/g13.bin@100 net:nets_go/g17.bin@100 net:nets_go/g21.bin@100 net:nets_go/g25.bin@100
grep -q '^REFINED 64' runs/tour_G25/results.txt || { python3 bt.py runs/tour_G25 0 100 0.1 > runs/tour_G25/bt.txt; ./refine.sh G25 64 300; }
touch runs/tour_G25/ALLDONE
