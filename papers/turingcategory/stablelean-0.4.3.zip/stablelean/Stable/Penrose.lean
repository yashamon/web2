import Stable.ReadingsTranslations
import Stable.PropCalc

/-!
# Appendix A: the Penrose property (Theorem A.2)

In Appendix A the idealized mathematician stably asserts a set `𝓗` of sentences of set theory, which
is deductively closed and contains `ZFC` (axiom (1)).  `δ` is a formula of `𝓩`, thought of as a
definition of `𝓗`.  For a machine `T`, `ε_T ∈ 𝓩` is the sentence "`T` stably enumerates `𝓗`",
written in terms of `δ`.  For a sentence `ε ∈ 𝓩`, `δ + ε` is the formula saying: `x` is the code of
some `b ∈ 𝓑₂`, and `δ` holds of the code of `ε → b*`.  The Penrose property (axiom (3)) says that
`ε_T → Con₁ (δ + ε_T)` is in `𝓗`, for every `T`.

The proof of Theorem A.2 applies Corollary 5.17 to `T₀` and the relation `R' := {(z, ε → z)}`, for
`ε := ε_{T₀}`.  The reading of the corollary is `R = {(a, ε → a*)}`, and its machine is
`Sh_R (T₀)`.  Here it is `Tplus … T₀`, written `T₀⁺`, with
`(T₀⁺)^s = {b ∈ 𝓑₂ | (ε → b*) ∈ T₀^s}`.  The theory `H` of the corollary is `{z | (ε → z) ∈ 𝓗}`,
the deductive closure of `𝓗 ∪ {ε}`.

* `penrose_conditional`: the deduction from Theorem 1.4, for any machine `Tp` with
  `Tp^s = {b ∈ 𝓑₂ | 𝓗 ∪ {ε} ⊢ b*}`.
* `isReadingOn_graph`: the graph of a map computable on `P` is a reading with `IsReadingOn P`.
* `Tplus`, `Tplus_Ts`, `Tplus_Ts_closed`: the machine `T₀⁺` and the description of `(T₀⁺)^s`.
* `penrose_two_way_delta`: Theorem A.2, first part, as in the manuscript: if `T₀` stably enumerates
  `𝓗`, then `{b ∈ 𝓑₂ | 𝓗 ∪ {ε_{T₀}} ⊢ b*}` is not `1`-consistent.  It applies Corollary 5.17
  (`reading_second_corollary`), as the manuscript does.
* `penrose_two_way`: the same conclusion, from the sentence `ε → Con₁ (T₀⁺)*` in place of the
  sentence of axiom (3).  This was axiom (3) in an earlier version of the manuscript.  Given axiom
  (1) the two sentences are equivalent, as `ZFC` proves `ε → (Con₁ (δ + ε) ↔ Con₁ (T₀⁺)*)`.

As everywhere, (5.11) is a hypothesis (`hcon`), for an arbitrary sentence `con` in place of
`Con₁ (T₀⁺)*`, and `ε` is an arbitrary sentence of `𝓩`.  In `penrose_two_way_delta` the two claims
of `ZFC`-provability in the proof are hypotheses as well, for arbitrary sentences `enum` and `conδ`
in place of `Enum (T₀⁺, δ + ε)` and `Con₁ (δ + ε)`: `henum` (`ZFC` proves that `ε` implies `enum`)
and `hδ` (as in Corollary 1.5).  The last part of Theorem A.2 (a sound `𝓗` satisfying axioms
(1)–(3) is not stably c.e.) uses truth in an `ω`-model `𝒰` of set theory, which Appendix A fixes,
and axiom (2): `δ` defines `𝓗` in `𝒰`.  It is not formalized.
-/

namespace Stable

open Classical

variable {M : TuringModel} {A : Arith M} {Z : Language M}

/-- Theorem A.2, the deduction from Theorem 1.4.  `Hm` contains `ZFC`.  `eps ∈ 𝓩` stands for the
sentence `ε_{T₀}`.  `Tp` is a machine with `Tp^s = {b ∈ 𝓑₂ | Hm ∪ {eps} ⊢ b*}`.
`con` satisfies (5.11) for `Tp`, and `Hm ∪ {eps} ⊢ con`, with `con = Con₁ (Tp)*`.  Then `Tp^s` is
not `1`-consistent. -/
theorem penrose_conditional (iAZ : Translation A.toLanguage Z) (ZFC Hm : Z.Sent → Prop)
    (hZFC : ∀ β, ZFC β → Hm β) (eps : Z.Sent) (Tp : M.Code)
    (hTp : ∀ b, Ts (M := M) A.Sent Tp b ↔
      (A.BoolComb 2 b ∧ Z.Deriv (Z.ext Hm eps) (iAZ.i b)))
    (con : Z.Sent)
    (hcon : Z.Deriv (fun β => ZFC β ∨ β = con) (iAZ.i (G₀ A Tp)))
    (h3 : Z.Deriv (Z.ext Hm eps) con) :
    ¬ A.OneConsistent (Ts (M := M) A.Sent Tp) := by
  intro h1
  -- Theorem 1.4 for `Tp` and the deductive closure of `Hm ∪ {eps}`
  refine second_incompleteness_H iAZ ZFC (Z.closure (Z.ext Hm eps)) (Z.closed_closure _)
    (fun β hβ => Z.deriv_of_mem (Or.inl (hZFC β hβ))) Tp h1 (fun b hb hH => ?_) con hcon h3
  exact A.deriv_of_mem ((hTp b).2 ⟨hb, hH⟩)

/-- The graph of a map `f : 𝓐 → 𝓛` whose restriction to a computable `P` is computable is a reading
whose part on `P` is computable, hence `Σ⁰₂`. -/
theorem isReadingOn_graph {L : Language M} (f : A.Sent → L.Sent) {P : A.Sent → Prop}
    (hP : CompSet M P)
    (hf : @CompT M {α // P α} L.Sent (Enc.restrict P hP) L.enc (fun σ => f σ.1)) :
    IsReadingOn (M := M) P (fun (a : A.Sent) (α : L.Sent) => f a = α) := by
  have hg : CompT M (fun b : A.Sent => if P b then some (f b) else none) := by
    refine CompT.ofComp (Comp.ofRestrict hP (f := f) hf) ?_
    exact hP.congr fun b => by by_cases h : P b <;> simp [h]
  have hEq : CompSet M (fun p : A.Sent × L.Sent =>
      (if P p.1 then some (f p.1) else none) = some p.2) :=
    compSet_eq (hg.comp compT_fst) (compT_some.comp compT_snd)
  refine IsSigma2Set.of_compSet (hEq.congr fun p => ?_)
  by_cases h : P p.1 <;> simp [h]

section Paper

variable (iAZ : Translation A.toLanguage Z) (hB2 : CompSet M (A.BoolComb 2)) (eps : Z.Sent)
  (hf : @CompT M {b // A.BoolComb 2 b} Z.Sent (Enc.restrict (A.BoolComb 2) hB2) Z.enc
    (fun σ => Z.imp eps (iAZ.i σ.1)))

/-- The machine `T⁺ = Sh_R (T)` of the proof of Theorem A.2, for the reading `R = {(a, ε → a*)}`.
The hypothesis `hf` says that `a ↦ (ε → a*)` is computable on `𝓑₂`. -/
noncomputable def Tplus : M.Code → M.Code :=
  Shadow hB2 (isReadingOn_graph (fun a => Z.imp eps (iAZ.i a)) hB2 hf)

/-- `(T⁺)^s = {b ∈ 𝓑₂ | (ε → b*) ∈ T^s}`. -/
theorem Tplus_Ts (T : M.Code) (b : A.Sent) :
    Ts (M := M) A.Sent (Tplus iAZ hB2 eps hf T) b ↔
      A.BoolComb 2 b ∧ Ts (M := M) Z.Sent T (Z.imp eps (iAZ.i b)) := by
  unfold Tplus
  rw [Shadow_Ts]
  constructor
  · rintro ⟨hb, α, hα, rfl⟩
    exact ⟨hb, hα⟩
  · rintro ⟨hb, h⟩
    exact ⟨hb, _, h, rfl⟩

/-- Theorem A.2 (`theorem_penrose`), first part, with `Con₁ (T₀⁺)*` in axiom (3).  `T₀` stably
enumerates `𝓗 = T₀^s`, which is deductively closed and contains `ZFC` (axiom (1)).  `con` satisfies
(5.11) for `T₀⁺`, and `ε → con` is in `𝓗`, with `con = Con₁ (T₀⁺)*`.  Then
`(T₀⁺)^s = {b ∈ 𝓑₂ | 𝓗 ∪ {ε} ⊢ b*}` is not `1`-consistent.  For axiom (3) as in the manuscript see
`penrose_two_way_delta`. -/
theorem penrose_two_way (ZFC : Z.Sent → Prop) (T₀ : M.Code)
    (hcl : Z.Closed (Ts (M := M) Z.Sent T₀)) (hZFC : ∀ β, ZFC β → Ts (M := M) Z.Sent T₀ β)
    (con : Z.Sent)
    (hcon : Z.Deriv (fun β => ZFC β ∨ β = con) (iAZ.i (G₀ A (Tplus iAZ hB2 eps hf T₀))))
    (h3 : Ts (M := M) Z.Sent T₀ (Z.imp eps con)) :
    ¬ A.OneConsistent (Ts (M := M) A.Sent (Tplus iAZ hB2 eps hf T₀)) := by
  refine penrose_conditional iAZ ZFC (Ts (M := M) Z.Sent T₀) hZFC eps _ (fun b => ?_) con hcon
    (Z.deriv_ext_of_imp (Z.deriv_of_mem h3))
  rw [Tplus_Ts]
  constructor
  · rintro ⟨hb, h⟩
    exact ⟨hb, Z.deriv_ext_of_imp (Z.deriv_of_mem h)⟩
  · rintro ⟨hb, h⟩
    exact ⟨hb, hcl _ (Z.deriv_imp_intro h)⟩

/-- The set `{b ∈ 𝓑₂ | 𝓗 ∪ {ε} ⊢ b*}` of the statement of Theorem A.2 is `(T₀⁺)^s`. -/
theorem Tplus_Ts_closed (T₀ : M.Code) (hcl : Z.Closed (Ts (M := M) Z.Sent T₀)) (b : A.Sent) :
    Ts (M := M) A.Sent (Tplus iAZ hB2 eps hf T₀) b ↔
      A.BoolComb 2 b ∧ Z.Deriv (Z.ext (Ts (M := M) Z.Sent T₀) eps) (iAZ.i b) := by
  rw [Tplus_Ts]
  constructor
  · rintro ⟨hb, h⟩
    exact ⟨hb, Z.deriv_ext_of_imp (Z.deriv_of_mem h)⟩
  · rintro ⟨hb, h⟩
    exact ⟨hb, hcl _ (Z.deriv_imp_intro h)⟩

/-- Theorem A.2 (`theorem_penrose`), first part, as in the manuscript.  `T₀` stably enumerates
`𝓗 = T₀^s`, which is deductively closed and contains `ZFC` (axiom (1)).  `enum`, `conδ ∈ 𝓩` stand
for the sentences `Enum (T₀⁺, δ + ε)` and `Con₁ (δ + ε)`, where `δ + ε` says: `x` is the code of
some `b ∈ 𝓑₂`, and `δ` holds of the code of `ε → b*`.  `henum`: `ZFC ∪ {ε} ⊢ enum`.  `hδ`:
`ZFC ∪ {enum, conδ} ⊢ con`, as in Corollary 1.5, with `con = Con₁ (T₀⁺)*`.  `h3`: `ε → conδ` is in
`𝓗`; this is axiom (3) for `T₀`.  Then `(T₀⁺)^s = {b ∈ 𝓑₂ | 𝓗 ∪ {ε} ⊢ b*}` is not `1`-consistent.
The proof applies Corollary 5.17 to `T₀` and `R' = {(z, ε → z)}`, as in the manuscript.  The
theory `H` of the corollary is `{z | (ε → z) ∈ 𝓗}`, the deductive closure of `𝓗 ∪ {ε}`. -/
theorem penrose_two_way_delta (ZFC : Z.Sent → Prop) (T₀ : M.Code)
    (hcl : Z.Closed (Ts (M := M) Z.Sent T₀)) (hZFC : ∀ β, ZFC β → Ts (M := M) Z.Sent T₀ β)
    (con enum conδ : Z.Sent)
    (hcon : Z.Deriv (fun β => ZFC β ∨ β = con) (iAZ.i (G₀ A (Tplus iAZ hB2 eps hf T₀))))
    (henum : Z.Deriv (Z.ext ZFC eps) enum)
    (hδ : Z.Deriv (fun β => ZFC β ∨ β = enum ∨ β = conδ) con)
    (h3 : Ts (M := M) Z.Sent T₀ (Z.imp eps conδ)) :
    ¬ A.OneConsistent (Ts (M := M) A.Sent (Tplus iAZ hB2 eps hf T₀)) := by
  intro h1
  -- the theory `H` of Corollary 5.17, for `R' = {(z, ε → z)}` and `F₀ = 𝓗`
  have hH : ∀ z, Asserted (fun (z α : Z.Sent) => Z.imp eps z = α) (Ts (M := M) Z.Sent T₀) z ↔
      Ts (M := M) Z.Sent T₀ (Z.imp eps z) := by
    intro z
    constructor
    · rintro ⟨α, hα, rfl⟩
      exact hα
    · exact fun h => ⟨_, h, rfl⟩
  refine reading_second_corollary (R' := fun (z α : Z.Sent) => Z.imp eps z = α)
    (F₀ := Ts (M := M) Z.Sent T₀) (P := A.BoolComb 2) (T := Tplus iAZ hB2 eps hf T₀) iAZ ZFC
    (fun _ hb => hb) (fun b => Shadow_Ts hB2 _ T₀ b) (fun z hz => ?_) (fun β hβ => ?_) h1
    con enum conδ hcon hδ ⟨?_, ?_⟩
  · -- `H` is deductively closed: it is the deductive closure of `𝓗 ∪ {ε}`
    refine (hH z).2 (hcl _ (Z.deriv_imp_intro (Z.deriv_cut (fun β hβ => ?_) hz)))
    exact Z.deriv_ext_of_imp (Z.deriv_of_mem ((hH β).1 hβ))
  · -- `H` contains `ZFC`, by axiom (1)
    exact (hH β).2 (hcl _ (Z.deriv_imp_intro (Z.deriv_of_mem (Or.inl (hZFC β hβ)))))
  · -- `enum ∈ H`, as `ZFC ⊂ 𝓗`
    refine (hH enum).2 (hcl _ (Z.deriv_imp_intro (Z.deriv_mono (fun β hβ => ?_) henum)))
    rcases hβ with hβ | rfl
    · exact Or.inl (hZFC β hβ)
    · exact Or.inr rfl
  · -- `conδ ∈ H`, by axiom (3)
    exact (hH conδ).2 h3

end Paper

end Stable
