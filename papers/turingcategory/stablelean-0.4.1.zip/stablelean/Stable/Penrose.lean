import Stable.ReadingsTranslations
import Stable.PropCalc

/-!
# Appendix A: the Penrose property (Theorem A.2)

In Appendix A the idealized mathematician stably asserts a set `𝓗` of sentences of set theory, which
is deductively closed and contains `ZFC` (axiom (1)).  For a machine `T`, `ε_T ∈ 𝓩` is the sentence
"`T` stably enumerates `δ`", and `T⁺ := Sh_{R_T} (T)` for the reading `R_T := {(a, ε_T → a*)}`, so
that `(T⁺)^s = {b ∈ 𝓑₂ | (ε_T → b*) ∈ T^s}`.  The Penrose property (axiom (3)) says that
`ε_T → Con₁ (T⁺)*` is in `𝓗`, for every `T`.

* `penrose_conditional`: the deduction of Theorem A.2 from Theorem 1.4, for any machine `Tp` with
  `Tp^s = {b ∈ 𝓑₂ | 𝓗 ∪ {ε} ⊢ b*}`.
* `isReadingOn_graph`: the graph of a map computable on `P` is a reading with `IsReadingOn P`.
* `Tplus`, `Tplus_Ts`: the machine `T⁺` and the description of `(T⁺)^s`.
* `penrose_two_way`: Theorem A.2, first part: if `T₀` stably enumerates `𝓗`, then
  `(T₀⁺)^s = {b ∈ 𝓑₂ | 𝓗 ∪ {ε_{T₀}} ⊢ b*}` is not `1`-consistent.

As everywhere, (5.11) is a hypothesis (`hcon`), for an arbitrary sentence `con` in place of
`Con₁ (T₀⁺)*`, and `ε` is an arbitrary sentence of `𝓩`.  The last part of Theorem A.2 (a sound `𝓗`
satisfying axioms (1)–(3) is not stably c.e.) uses truth in the intended interpretation of `𝓩`.  It
is not formalized.
-/

namespace Stable

open Classical

variable {M : TuringModel} {A : Arith M} {Z : Language M}

/-- Theorem A.2, the deduction from Theorem 1.4.  `Hm` contains `ZFC`.  `eps ∈ 𝓩` stands for the
sentence "`T₀` stably enumerates `δ`".  `Tp` is a machine with `Tp^s = {b ∈ 𝓑₂ | Hm ∪ {eps} ⊢ b*}`.
`con` satisfies (5.11) for `Tp`, and `Hm ∪ {eps} ⊢ con`: this is axiom (3) for `T₀`, with
`con = Con₁ (Tp)*`.  Then `Tp^s` is not `1`-consistent. -/
theorem penrose_conditional (iAZ : Translation A.toLanguage Z) (ZFC Hm : Z.Sent → Prop)
    (hZFC : ∀ β, ZFC β → Hm β) (eps : Z.Sent) (Tp : M.Code)
    (hTp : ∀ b, Ts (M := M) A.Sent Tp b ↔
      (A.BoolComb 2 b ∧ Z.Deriv (Z.ext Hm eps) (iAZ.i b)))
    (con : Z.Sent)
    (hcon : Z.Deriv (fun β => ZFC β ∨ β = con) (iAZ.i (G₀ A Tp)))
    (h3 : Z.Deriv (Z.ext Hm eps) con) :
    ¬ A.OneConsistent (Ts (M := M) A.Sent Tp) := by
  intro h1
  -- Theorem 1.4 for `Tp` and the deductive closure of `Hm ∪ {eps}`
  refine second_incompleteness_H iAZ ZFC (Z.closure (Z.ext Hm eps)) (Z.closed_closure _)
    (fun β hβ => Z.deriv_of_mem (Or.inl (hZFC β hβ))) Tp h1 (fun b hb hH => ?_) con hcon h3
  exact A.deriv_of_mem ((hTp b).2 ⟨hb, hH⟩)

/-- The graph of a map `f : 𝓐 → 𝓛` whose restriction to a computable `P` is computable is a reading
whose part on `P` is computable, hence `Σ⁰₂`. -/
theorem isReadingOn_graph {L : Language M} (f : A.Sent → L.Sent) {P : A.Sent → Prop}
    (hP : CompSet M P)
    (hf : @CompT M {α // P α} L.Sent (Enc.restrict P hP) L.enc (fun σ => f σ.1)) :
    IsReadingOn (M := M) P (fun (a : A.Sent) (α : L.Sent) => f a = α) := by
  have hg : CompT M (fun b : A.Sent => if P b then some (f b) else none) := by
    refine CompT.ofComp (Comp.ofRestrict hP (f := f) hf) ?_
    exact hP.congr fun b => by by_cases h : P b <;> simp [h]
  have hEq : CompSet M (fun p : A.Sent × L.Sent =>
      (if P p.1 then some (f p.1) else none) = some p.2) :=
    compSet_eq (hg.comp compT_fst) (compT_some.comp compT_snd)
  refine IsSigma2Set.of_compSet (hEq.congr fun p => ?_)
  by_cases h : P p.1 <;> simp [h]

section Paper

variable (iAZ : Translation A.toLanguage Z) (hB2 : CompSet M (A.BoolComb 2)) (eps : Z.Sent)
  (hf : @CompT M {b // A.BoolComb 2 b} Z.Sent (Enc.restrict (A.BoolComb 2) hB2) Z.enc
    (fun σ => Z.imp eps (iAZ.i σ.1)))

/-- The machine `T⁺ = Sh_{R_T} (T)` of Appendix A, for the reading `R_T = {(a, ε → a*)}`.  The
hypothesis `hf` says that `a ↦ (ε → a*)` is computable on `𝓑₂`. -/
noncomputable def Tplus : M.Code → M.Code :=
  Shadow hB2 (isReadingOn_graph (fun a => Z.imp eps (iAZ.i a)) hB2 hf)

/-- `(T⁺)^s = {b ∈ 𝓑₂ | (ε → b*) ∈ T^s}`. -/
theorem Tplus_Ts (T : M.Code) (b : A.Sent) :
    Ts (M := M) A.Sent (Tplus iAZ hB2 eps hf T) b ↔
      A.BoolComb 2 b ∧ Ts (M := M) Z.Sent T (Z.imp eps (iAZ.i b)) := by
  unfold Tplus
  rw [Shadow_Ts]
  constructor
  · rintro ⟨hb, α, hα, rfl⟩
    exact ⟨hb, hα⟩
  · rintro ⟨hb, h⟩
    exact ⟨hb, _, h, rfl⟩

/-- Theorem A.2 (`theorem_penrose`), first part.  `T₀` stably enumerates `𝓗 = T₀^s`, which is
deductively closed and contains `ZFC` (axiom (1)).  `con` satisfies (5.11) for `T₀⁺`, and
`ε → con` is in `𝓗`: this is axiom (3) for `T₀`, with `con = Con₁ (T₀⁺)*`.  Then
`(T₀⁺)^s = {b ∈ 𝓑₂ | 𝓗 ∪ {ε} ⊢ b*}` is not `1`-consistent. -/
theorem penrose_two_way (ZFC : Z.Sent → Prop) (T₀ : M.Code)
    (hcl : Z.Closed (Ts (M := M) Z.Sent T₀)) (hZFC : ∀ β, ZFC β → Ts (M := M) Z.Sent T₀ β)
    (con : Z.Sent)
    (hcon : Z.Deriv (fun β => ZFC β ∨ β = con) (iAZ.i (G₀ A (Tplus iAZ hB2 eps hf T₀))))
    (h3 : Ts (M := M) Z.Sent T₀ (Z.imp eps con)) :
    ¬ A.OneConsistent (Ts (M := M) A.Sent (Tplus iAZ hB2 eps hf T₀)) := by
  refine penrose_conditional iAZ ZFC (Ts (M := M) Z.Sent T₀) hZFC eps _ (fun b => ?_) con hcon
    (Z.deriv_ext_of_imp (Z.deriv_of_mem h3))
  rw [Tplus_Ts]
  constructor
  · rintro ⟨hb, h⟩
    exact ⟨hb, Z.deriv_ext_of_imp (Z.deriv_of_mem h)⟩
  · rintro ⟨hb, h⟩
    exact ⟨hb, hcl _ (Z.deriv_imp_intro h)⟩

/-- The set `{b ∈ 𝓑₂ | 𝓗 ∪ {ε} ⊢ b*}` of the statement of Theorem A.2 is `(T₀⁺)^s`. -/
theorem Tplus_Ts_closed (T₀ : M.Code) (hcl : Z.Closed (Ts (M := M) Z.Sent T₀)) (b : A.Sent) :
    Ts (M := M) A.Sent (Tplus iAZ hB2 eps hf T₀) b ↔
      A.BoolComb 2 b ∧ Z.Deriv (Z.ext (Ts (M := M) Z.Sent T₀) eps) (iAZ.i b) := by
  rw [Tplus_Ts]
  constructor
  · rintro ⟨hb, h⟩
    exact ⟨hb, Z.deriv_ext_of_imp (Z.deriv_of_mem h)⟩
  · rintro ⟨hb, h⟩
    exact ⟨hb, hcl _ (Z.deriv_imp_intro h)⟩

end Paper

end Stable
